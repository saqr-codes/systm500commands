const fs = require('fs');
const path = require('path');
const { Client, GatewayIntentBits, Partials, Events } = require('discord.js');
const config = require('./config');
const handler = require('./src/core/handler');

if (!config.token) {
    console.error('ضع توكن البوت في ملف .env بهذا الشكل: TOKEN=توكنك');
    process.exit(1);
}

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildModeration,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.GuildInvites,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.GuildPresences,
        GatewayIntentBits.MessageContent
    ],
    partials: [Partials.Message, Partials.Channel, Partials.Reaction, Partials.GuildMember, Partials.User]
});

handler.load(client);

// الميزات الإضافية (ألعاب، موسيقى، قيف أواي، دعوات، سجن، ستاربورد، اقتراحات...)
require('./src/ext/utils/emojiReplacer');
const ext = require('./src/ext/bridge');
const extCount = ext.load(client);
console.log(`[ext] تم تحميل ${extCount} أمر من الميزات الإضافية`);
if (process.env.LAVALINK_NODES) {
    try { require('./src/ext/utils/music').setupMusic(client); }
    catch (err) { console.error('[ext] تعذر تشغيل نظام الموسيقى:', err.message); }
} else {
    console.log('[ext] الموسيقى معطلة: أضف LAVALINK_NODES في .env لتفعيلها');
}
require('./src/ext/events').install(client);
client.once(Events.ClientReady, () => require('./src/core/slash').deploy(client));

const eventsDir = path.join(__dirname, 'src', 'events');
for (const file of fs.readdirSync(eventsDir).filter(f => f.endsWith('.js'))) {
    const mod = require(path.join(eventsDir, file));
    for (const event of [].concat(mod)) {
        const listener = (...args) => Promise.resolve(event.run(client, ...args)).catch(err => console.error(`خطأ في الحدث ${event.name}:`, err));
        if (event.once) client.once(event.name, listener);
        else client.on(event.name, listener);
    }
}

process.on('unhandledRejection', err => console.error('خطأ غير معالج:', err));
process.on('uncaughtException', err => console.error('خطأ غير متوقع:', err));

client.login(config.token);
