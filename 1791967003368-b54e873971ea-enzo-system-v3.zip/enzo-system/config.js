require('dotenv').config();

const list = v => (v || '').split(',').map(s => s.trim()).filter(Boolean);

module.exports = {
    token: process.env.TOKEN,
    prefix: process.env.PREFIX ?? '-',
    owners: list(process.env.OWNERS),
    // حالة البوت (اتركها فاضية لإخفاء الحالة). تقدر تحط أكثر من نص مفصولين بفاصلة وتتبدل كل 20 ثانية
    status: {
        names: process.env.STATUS === undefined ? ['اكتب -اوامر'] : list(process.env.STATUS),
        interval: 20000
    },
    // نص الفوتر في الامبدات (اتركه فاضي لإخفائه)
    footer: process.env.FOOTER || '',
    coin: '🪙'
};
