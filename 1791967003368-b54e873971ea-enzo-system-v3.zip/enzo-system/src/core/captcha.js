// التحقق: زر -> كود -> نافذة إدخال -> إعطاء رتبة التوثيق وسحب رتبة غير الموثق
const {
    ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, MessageFlags, EmbedBuilder
} = require('discord.js');
const crypto = require('crypto');
const db = require('../utils/db');
const e = require('../utils/embeds');

const eph = { flags: MessageFlags.Ephemeral };
const codes = new Map();
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

setInterval(() => {
    const now = Date.now();
    for (const [k, v] of codes) if (now - v.at > 5 * 60000) codes.delete(k);
}, 60000).unref();

const makeCode = () => Array.from(crypto.randomBytes(5), b => ALPHABET[b % ALPHABET.length]).join('');

const panel = guild => {
    const c = db.guild(guild.id).captcha;
    return {
        embeds: [new EmbedBuilder().setColor(0x57f287).setTitle(c.title.slice(0, 256)).setDescription(c.description.slice(0, 4000))],
        components: [new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('captcha:start').setLabel(c.button.slice(0, 80)).setEmoji('✅').setStyle(ButtonStyle.Success)
        )]
    };
};

const handle = async i => {
    const id = i.customId;
    if (!id || !id.startsWith('captcha:')) return false;
    const c = db.guild(i.guild.id).captcha;
    const key = `${i.guild.id}:${i.user.id}`;

    if (!c.enabled || !c.verified) {
        await i.reply({ embeds: [e.err('نظام التحقق غير مفعل.')], ...eph });
        return true;
    }

    if (i.isButton() && id === 'captcha:start') {
        if (i.member.roles.cache.has(c.verified)) {
            await i.reply({ embeds: [e.ok('أنت موثق بالفعل ✅')], ...eph });
            return true;
        }
        const code = makeCode();
        codes.set(key, { code, at: Date.now() });
        await i.reply({
            embeds: [e.info('🔐 التحقق', `اكتب هذا الكود في النافذة:\n# \`${code}\``)],
            components: [new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('captcha:enter').setLabel('إدخال الكود').setEmoji('⌨️').setStyle(ButtonStyle.Primary)
            )],
            ...eph
        });
        return true;
    }

    if (i.isButton() && id === 'captcha:enter') {
        if (!codes.has(key)) {
            await i.reply({ embeds: [e.err('انتهت صلاحية الكود، اضغط زر التحقق من جديد.')], ...eph });
            return true;
        }
        const modal = new ModalBuilder().setCustomId('captcha:submit').setTitle('التحقق').addComponents(
            new ActionRowBuilder().addComponents(
                new TextInputBuilder().setCustomId('code').setLabel('اكتب الكود').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(10)
            )
        );
        await i.showModal(modal);
        return true;
    }

    if (i.isModalSubmit() && id === 'captcha:submit') {
        const entry = codes.get(key);
        codes.delete(key);
        const typed = i.fields.getTextInputValue('code').trim().toUpperCase();
        if (!entry || entry.code !== typed) {
            await i.reply({ embeds: [e.err('الكود غلط أو انتهت صلاحيته، اضغط زر التحقق وجرب مرة ثانية.')], ...eph });
            return true;
        }
        const ok = await i.member.roles.add(c.verified).then(() => true).catch(() => false);
        if (c.unverified) await i.member.roles.remove(c.unverified).catch(() => {});
        await i.reply({ embeds: [ok ? e.ok('تم التحقق منك بنجاح 🎉') : e.err('ما قدرت أعطيك رتبة التوثيق، بلغ الإدارة.')], ...eph });
        return true;
    }
    return false;
};

module.exports = { handle, panel };
