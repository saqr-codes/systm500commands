// نماذج التقديم: زر -> نافذة أسئلة (حتى 5) -> إرسال للإدارة مع قبول/رفض
const {
    ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle,
    PermissionFlagsBits: P, MessageFlags, EmbedBuilder
} = require('discord.js');
const db = require('../utils/db');
const e = require('../utils/embeds');

const eph = { flags: MessageFlags.Ephemeral };
const colorOf = hex => parseInt(String(hex || '#5865F2').replace('#', ''), 16) || 0x5865f2;
const cooldown = new Map();

const panel = guild => {
    const f = db.guild(guild.id).forms;
    return {
        embeds: [new EmbedBuilder().setColor(colorOf(f.color)).setTitle(f.title.slice(0, 256)).setDescription(f.description.slice(0, 4000))],
        components: [new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('form:apply').setLabel('قدّم الآن').setEmoji('📝').setStyle(ButtonStyle.Primary)
        )]
    };
};

const handle = async i => {
    const id = i.customId;
    if (!id || !id.startsWith('form:')) return false;
    const f = db.guild(i.guild.id).forms;

    if (i.isButton() && id === 'form:apply') {
        if (!f.questions.length || !f.logChannel) {
            await i.reply({ embeds: [e.err('نظام التقديم غير مجهز بعد.')], ...eph });
            return true;
        }
        const last = cooldown.get(i.user.id) || 0;
        if (Date.now() - last < 5 * 60000) {
            await i.reply({ embeds: [e.err('قدمت قبل شوي، انتظر 5 دقائق.')], ...eph });
            return true;
        }
        const modal = new ModalBuilder().setCustomId('form:submit').setTitle(f.title.slice(0, 45));
        f.questions.slice(0, 5).forEach((q, n) => modal.addComponents(new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId(`q${n}`).setLabel(q.slice(0, 45)).setStyle(TextInputStyle.Paragraph).setRequired(true).setMaxLength(1000)
        )));
        await i.showModal(modal);
        return true;
    }

    if (i.isModalSubmit() && id === 'form:submit') {
        const channel = f.logChannel && i.guild.channels.cache.get(f.logChannel);
        if (!channel) {
            await i.reply({ embeds: [e.err('روم استقبال التقديمات غير موجود.')], ...eph });
            return true;
        }
        const embed = new EmbedBuilder().setColor(colorOf(f.color)).setTitle(`📝 ${f.title}`.slice(0, 256))
            .setAuthor({ name: i.user.tag, iconURL: i.user.displayAvatarURL() })
            .setDescription(`المتقدم: ${i.user} (\`${i.user.id}\`)`).setTimestamp();
        f.questions.slice(0, 5).forEach((q, n) => embed.addFields({ name: q.slice(0, 256), value: (i.fields.getTextInputValue(`q${n}`) || '-').slice(0, 1000) }));
        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId(`form:accept:${i.user.id}`).setLabel('قبول').setEmoji('✅').setStyle(ButtonStyle.Success),
            new ButtonBuilder().setCustomId(`form:reject:${i.user.id}`).setLabel('رفض').setEmoji('❌').setStyle(ButtonStyle.Danger)
        );
        const sent = await channel.send({ embeds: [embed], components: [row] }).catch(() => null);
        if (!sent) {
            await i.reply({ embeds: [e.err('ما قدرت أرسل طلبك للإدارة.')], ...eph });
            return true;
        }
        cooldown.set(i.user.id, Date.now());
        await i.reply({ embeds: [e.ok('تم إرسال طلبك للإدارة 📨')], ...eph });
        return true;
    }

    if (i.isButton() && (id.startsWith('form:accept:') || id.startsWith('form:reject:'))) {
        if (!i.member.permissions.has(P.ManageMessages)) {
            await i.reply({ embeds: [e.err('هذا الزر للإدارة فقط.')], ...eph });
            return true;
        }
        const accept = id.startsWith('form:accept:');
        const userId = id.split(':')[2];
        const embed = EmbedBuilder.from(i.message.embeds[0]).setColor(accept ? 0x2ecc71 : 0xe74c3c)
            .addFields({ name: accept ? '✅ تم القبول' : '❌ تم الرفض', value: `بواسطة ${i.user}` });
        await i.update({ embeds: [embed], components: [] });
        const member = await i.guild.members.fetch(userId).catch(() => null);
        if (accept && f.role && member) await member.roles.add(f.role).catch(() => {});
        const user = member?.user || await i.client.users.fetch(userId).catch(() => null);
        if (user) {
            user.send({ embeds: [e.base(accept ? e.colors.ok : e.colors.err).setTitle(accept ? '✅ تم قبول طلبك' : '❌ تم رفض طلبك').setDescription(`السيرفر: **${i.guild.name}**`)] }).catch(() => {});
        }
        return true;
    }
    return false;
};

module.exports = { handle, panel };
