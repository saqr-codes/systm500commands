const db = require('../utils/db');
const e = require('../utils/embeds');
const t = require('../utils/time');

const fill = (template, member) => template
    .replace(/{user}/g, `${member}`)
    .replace(/{name}/g, member.displayName)
    .replace(/{server}/g, member.guild.name)
    .replace(/{count}/g, String(member.guild.memberCount));

const joinEmbed = member => {
    const g = db.guild(member.guild.id);
    return e.base(e.colors.ok)
        .setTitle('🌟 عضو جديد')
        .setThumbnail(member.displayAvatarURL({ size: 256 }))
        .setDescription(fill(g.welcome.message, member))
        .addFields(
            { name: '📅 عمر الحساب', value: t.stamp(member.user.createdAt, 'R'), inline: true },
            { name: '👥 رقم العضو', value: `#${member.guild.memberCount}`, inline: true }
        );
};

const leaveEmbed = member => e.base(e.colors.err)
    .setTitle('👋 غادر السيرفر')
    .setThumbnail(member.displayAvatarURL({ size: 256 }))
    .setDescription(`**${member.user.tag}** غادر ${member.guild.name}\nعدد الأعضاء الآن **${member.guild.memberCount}**`);

module.exports = { joinEmbed, leaveEmbed };
