const fs = require('fs');
const path = require('path');
const config = require('../../config');
const db = require('../utils/db');
const e = require('../utils/embeds');
const { norm } = require('../utils/text');
const { permNames } = require('../utils/mod');

const order = ['dashboard', 'moderation', 'protection', 'tickets', 'settings', 'automation', 'utility', 'economy', 'levels', 'fun', 'voice', 'admin', 'backup', 'help'];

const load = client => {
    client.commands = new Map();
    client.categories = new Map();
    const dir = path.join(__dirname, '..', 'commands');
    const files = fs.readdirSync(dir).filter(f => f.endsWith('.js')).map(f => f.slice(0, -3));
    files.sort((a, b) => ((order.indexOf(a) + 100) % 100) - ((order.indexOf(b) + 100) % 100));

    for (const file of files) {
        const mod = require(path.join(dir, file));
        const list = [];
        for (const cmd of mod.commands) {
            cmd.category = mod.category;
            cmd.module = file;
            for (const key of [cmd.name, ...(cmd.aliases || [])].map(norm)) {
                if (client.commands.has(key)) throw new Error(`اسم أمر مكرر: ${key}`);
                client.commands.set(key, cmd);
            }
            list.push(cmd);
        }
        client.categories.set(mod.category, { icon: mod.icon, commands: list });
    }
};

const cooldowns = new Map();

setInterval(() => {
    const now = Date.now();
    for (const [id, at] of cooldowns) if (now - at > 10000) cooldowns.delete(id);
}, 600000).unref();

// فحص الصلاحيات والانتظار (مشترك بين البريفكس والسلاش). يرجع false إذا انرفض الأمر
const gate = async (cmd, message) => {
    const isOwner = config.owners.includes(message.author.id);
    if (cmd.perms && cmd.perms.length && !isOwner && !message.member.permissions.has(cmd.perms)) {
        const names = cmd.perms.map(p => permNames[p] || p).join(' • ');
        await e.reply(message, e.err(`ما عندك الصلاحية لاستخدام هذا الأمر.\nالصلاحية المطلوبة: **${names}**`));
        return false;
    }
    const now = Date.now();
    if (now - (cooldowns.get(message.author.id) || 0) < 1500) return false;
    cooldowns.set(message.author.id, now);
    return true;
};

const run = async (client, cmd, message, args, used, prefix) => {
    try {
        await cmd.run(message, args, { used, prefix, client });
    } catch (error) {
        console.error(`خطأ في الأمر ${cmd.name}:`, error);
        const text = error.code === 50013 || error.code === 50001
            ? 'ما عندي صلاحيات كافية لتنفيذ هذا الأمر، تأكد من صلاحياتي ورتبتي.'
            : 'صار خطأ غير متوقع أثناء تنفيذ الأمر.';
        e.reply(message, e.err(text)).catch(() => {});
    }
};

const execute = async (client, message) => {
    const g = db.guild(message.guild.id);
    const prefix = g.prefix ?? config.prefix;
    if (prefix && !message.content.startsWith(prefix)) return false;

    const body = message.content.slice(prefix.length).trim();
    if (!body) return false;

    let args = body.split(/\s+/);
    const used = args.shift().toLowerCase();
    let cmd = client.commands.get(norm(used));

    if (!cmd) {
        // اختصارات السيرفر (اختصار -> أمر) ثم الأوامر المخصصة
        const target = g.aliases[norm(used)];
        if (target) {
            const parts = target.split(/\s+/);
            cmd = client.commands.get(norm(parts[0]));
            if (cmd) args = [...parts.slice(1), ...args];
        }
    }
    if (!cmd) {
        const custom = g.customCmds.find(c => norm(c.name) === norm(used));
        if (!custom) return false;
        const text = custom.response.replace(/{user}/g, `${message.author}`).replace(/{server}/g, message.guild.name);
        message.reply({ content: text, allowedMentions: { users: [message.author.id], repliedUser: false } }).catch(() => {});
        return true;
    }

    if (!(await gate(cmd, message))) return true;
    await run(client, cmd, message, args, used, prefix);
    return true;
};

module.exports = { load, execute, gate, run };
