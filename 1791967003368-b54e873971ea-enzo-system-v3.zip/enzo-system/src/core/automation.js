// الأتمتة: ضريبة تلقائية، روم صور، روم يوتيوب، تفاعل تلقائي، روم مشاعر، شكر البوست
const { PermissionFlagsBits: P, MessageType } = require('discord.js');
const db = require('../utils/db');
const e = require('../utils/embeds');
const t = require('../utils/time');

const youtubeRegex = /(https?:\/\/)?(www\.|m\.|music\.)?(youtube\.com|youtu\.be)\/\S+/i;
const imageLink = /https?:\/\/\S+\.(png|jpe?g|gif|webp)(\?\S*)?/i;
const boostTypes = new Set([
    MessageType.UserPremiumGuildSubscription,
    MessageType.UserPremiumGuildSubscriptionTier1,
    MessageType.UserPremiumGuildSubscriptionTier2,
    MessageType.UserPremiumGuildSubscriptionTier3
]);

// يقرأ مبلغ مثل 5000 أو 2.5k أو 1m أو 3b أو ١٠٠٠ (ويرجع null لو النص مو مبلغ)
const parseAmount = raw => {
    const m = t.digits(String(raw || '')).toLowerCase().trim().replace(/,/g, '').match(/^(\d+(?:\.\d+)?)\s*(k|m|b|ك|م)?$/);
    if (!m) return null;
    const mult = { k: 1e3, 'ك': 1e3, m: 1e6, 'م': 1e6, b: 1e9 }[m[2]] || 1;
    const value = Number(m[1]) * mult;
    return Number.isFinite(value) && value > 0 && value <= 1e15 ? value : null;
};

// الضريبة: المبلغ اللي لازم يتحول عشان يوصل المستلم المبلغ كامل (بعد خصم 5%)
const withTax = amount => Math.floor(amount * (20 / 19) + 1);

const exempt = message => message.member.permissions.has(P.ManageMessages) || message.member.permissions.has(P.Administrator);

const warnTemp = async (message, text) => {
    const sent = await message.channel.send({ content: `${message.author} ${text}`, allowedMentions: { users: [message.author.id] } }).catch(() => null);
    if (sent) setTimeout(() => sent.delete().catch(() => {}), 5000);
};

// رسالة شكر البوست (رسائل النظام)
const boost = async message => {
    if (!boostTypes.has(message.type) || !message.guild) return false;
    const b = db.guild(message.guild.id).automation.boost;
    const channel = b.channel && message.guild.channels.cache.get(b.channel);
    if (!channel || !b.message) return true;
    const text = b.message.replace(/{user}/g, `${message.author}`).replace(/{server}/g, message.guild.name);
    const payload = b.embed
        ? { embeds: [e.base(0xff73e1).setDescription(text)], allowedMentions: { users: [message.author.id] } }
        : { content: text, allowedMentions: { users: [message.author.id] } };
    channel.send(payload).catch(() => {});
    return true;
};

// يرجع true إذا الرسالة انحذفت أو انعالجت بالكامل
const message = async msg => {
    const a = db.guild(msg.guild.id).automation;
    const id = msg.channel.id;

    if (a.react[id]?.length) {
        for (const emoji of a.react[id]) msg.react(emoji).catch(() => {});
    }

    if (a.feelings.channel === id) {
        const image = msg.attachments.find(x => x.contentType?.startsWith('image/'));
        if (!msg.content && !image) return false;
        const embed = e.base(0x5865f2).setDescription(msg.content || null);
        if (image) embed.setImage(image.url);
        if (!a.feelings.anonymous) embed.setAuthor({ name: msg.member.displayName, iconURL: msg.author.displayAvatarURL() });
        await msg.delete().catch(() => {});
        await msg.channel.send({ embeds: [embed], allowedMentions: { parse: [] } }).catch(() => {});
        return true;
    }

    if (a.images.includes(id) && !exempt(msg)) {
        const hasImage = msg.attachments.some(x => x.contentType?.startsWith('image/')) || imageLink.test(msg.content);
        if (!hasImage) {
            await msg.delete().catch(() => {});
            await warnTemp(msg, 'هذا الروم للصور فقط 🖼️');
            return true;
        }
    }

    if (a.youtube.includes(id) && !exempt(msg)) {
        if (!youtubeRegex.test(msg.content)) {
            await msg.delete().catch(() => {});
            await warnTemp(msg, 'هذا الروم لروابط يوتيوب فقط ▶️');
            return true;
        }
    }

    if (a.tax.includes(id)) {
        const amount = parseAmount(msg.content);
        if (amount) {
            msg.reply({ content: `💳 **${withTax(amount)}**`, allowedMentions: { parse: [], repliedUser: false } }).catch(() => {});
            if (a.taxLine) setTimeout(() => msg.channel.send({ content: a.taxLine }).catch(() => {}), 500);
        }
    }

    return false;
};

module.exports = { message, boost, parseAmount, withTax };
