const { ChannelType, PermissionFlagsBits: P } = require('discord.js');
const db = require('../utils/db');

const sessions = new Map();

const key = (guildId, userId) => `${guildId}:${userId}`;

const credit = (guildId, userId, since) => {
    const seconds = Math.floor((Date.now() - since) / 1000);
    if (seconds > 0) db.user(guildId, userId).voice += seconds;
};

const begin = (guildId, userId) => sessions.set(key(guildId, userId), Date.now());

const end = (guildId, userId) => {
    const since = sessions.get(key(guildId, userId));
    if (!since) return;
    credit(guildId, userId, since);
    sessions.delete(key(guildId, userId));
    db.save();
};

let clientRef = null;

const seed = client => {
    clientRef = client;
    for (const guild of client.guilds.cache.values()) {
        for (const state of guild.voiceStates.cache.values()) {
            if (state.channelId && state.member && !state.member.user.bot) begin(guild.id, state.id);
        }
    }

    setInterval(() => {
        for (const [k, since] of sessions) {
            const [guildId, userId] = k.split(':');
            credit(guildId, userId, since);
            sessions.set(k, Date.now());
            try { require('../utils/xp').voiceTick(clientRef, guildId, userId); } catch {}
        }
        db.save();
    }, 60000);
};

const temp = async (oldState, newState) => {
    const guild = newState.guild;
    const tv = db.guild(guild.id).tempVoice;
    const member = newState.member;

    if (tv.creator && newState.channelId === tv.creator && member && !member.user.bot) {
        const source = newState.channel;
        const room = await guild.channels.create({
            name: `🔊 ${member.displayName}`.slice(0, 90),
            type: ChannelType.GuildVoice,
            parent: source.parentId,
            permissionOverwrites: [
                { id: member.id, allow: [P.ManageChannels, P.Connect, P.MoveMembers] }
            ]
        }).catch(() => null);
        if (room) {
            tv.rooms[room.id] = member.id;
            db.save();
            await member.voice.setChannel(room).catch(async () => {
                delete tv.rooms[room.id];
                await room.delete().catch(() => {});
            });
        }
    }

    if (oldState.channelId && tv.rooms[oldState.channelId]) {
        const room = oldState.guild.channels.cache.get(oldState.channelId);
        if (!room) {
            delete tv.rooms[oldState.channelId];
        } else if (room.members.size === 0) {
            delete tv.rooms[room.id];
            await room.delete().catch(() => {});
        }
        db.save();
    }
};

module.exports = { seed, begin, end, temp };
