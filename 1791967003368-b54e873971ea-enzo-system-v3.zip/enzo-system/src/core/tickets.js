const {
    ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, PermissionFlagsBits: P,
    ModalBuilder, TextInputBuilder, TextInputStyle, AttachmentBuilder, MessageFlags
} = require('discord.js');
const db = require('../utils/db');
const e = require('../utils/embeds');
const t = require('../utils/time');

const panelRow = () => new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('tk:open').setLabel('فتح تذكرة').setEmoji('🎫').setStyle(ButtonStyle.Primary)
);

const controlRow = claimed => new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('tk:claim').setLabel(claimed ? 'تم الاستلام' : 'استلام').setEmoji('✋').setStyle(ButtonStyle.Success).setDisabled(claimed),
    new ButtonBuilder().setCustomId('tk:close').setLabel('إغلاق').setEmoji('🔒').setStyle(ButtonStyle.Danger)
);

const panel = () => e.base()
    .setTitle('🎫 الدعم الفني')
    .setDescription('تحتاج مساعدة أو عندك استفسار؟\nاضغط على الزر بالأسفل لفتح تذكرة وراح يرد عليك فريق الإدارة بأسرع وقت.\n\n> لا تفتح أكثر من تذكرة بنفس الوقت.');

const modal = () => new ModalBuilder()
    .setCustomId('tk:modal')
    .setTitle('فتح تذكرة جديدة')
    .addComponents(new ActionRowBuilder().addComponents(
        new TextInputBuilder()
            .setCustomId('reason')
            .setLabel('سبب فتح التذكرة')
            .setStyle(TextInputStyle.Paragraph)
            .setMinLength(5)
            .setMaxLength(500)
            .setPlaceholder('اشرح مشكلتك أو طلبك باختصار')
            .setRequired(true)
    ));

const isTicket = channel => Boolean(db.guild(channel.guild.id).tickets.open[channel.id]);

const open = async (interaction, reason) => {
    const guild = interaction.guild;
    const g = db.guild(guild.id);
    const existing = Object.entries(g.tickets.open).find(([id, tk]) => tk.owner === interaction.user.id && guild.channels.cache.has(id));
    if (existing) {
        return interaction.reply({ embeds: [e.err(`عندك تذكرة مفتوحة بالفعل: <#${existing[0]}>`)], flags: MessageFlags.Ephemeral });
    }

    g.tickets.counter += 1;
    const number = String(g.tickets.counter).padStart(4, '0');
    const overwrites = [
        { id: guild.id, deny: [P.ViewChannel] },
        { id: interaction.user.id, allow: [P.ViewChannel, P.SendMessages, P.ReadMessageHistory, P.AttachFiles] },
        { id: guild.members.me.id, allow: [P.ViewChannel, P.SendMessages, P.ManageChannels, P.ReadMessageHistory] }
    ];
    if (g.tickets.role) overwrites.push({ id: g.tickets.role, allow: [P.ViewChannel, P.SendMessages, P.ReadMessageHistory, P.AttachFiles] });

    const channel = await guild.channels.create({
        name: `تذكرة-${number}`,
        type: ChannelType.GuildText,
        parent: g.tickets.category || null,
        topic: `تذكرة ${interaction.user.tag} • ${interaction.user.id}`,
        permissionOverwrites: overwrites
    }).catch(() => null);

    if (!channel) {
        return interaction.reply({ embeds: [e.err('ما قدرت أنشئ التذكرة، تأكد من صلاحياتي.')], flags: MessageFlags.Ephemeral });
    }

    g.tickets.open[channel.id] = { owner: interaction.user.id, claimed: null, number, at: Date.now(), reason };
    db.save();

    const embed = e.base()
        .setTitle(`🎫 تذكرة رقم ${number}`)
        .setThumbnail(interaction.user.displayAvatarURL({ size: 256 }))
        .setDescription(`أهلاً ${interaction.user}، تم فتح تذكرتك وراح يتواصل معك أحد من الإدارة قريباً.`)
        .addFields(
            { name: '📝 السبب', value: reason, inline: false },
            { name: '👤 صاحب التذكرة', value: `${interaction.user}`, inline: true },
            { name: '🕐 وقت الفتح', value: t.stamp(Date.now()), inline: true }
        );

    await channel.send({
        content: g.tickets.role ? `${interaction.user} | <@&${g.tickets.role}>` : `${interaction.user}`,
        embeds: [embed],
        components: [controlRow(false)],
        allowedMentions: { users: [interaction.user.id], roles: g.tickets.role ? [g.tickets.role] : [] }
    });

    return interaction.reply({ embeds: [e.ok(`تم فتح تذكرتك: ${channel}`)], flags: MessageFlags.Ephemeral });
};

const transcript = async channel => {
    const all = [];
    let before;
    for (let i = 0; i < 10; i++) {
        const batch = await channel.messages.fetch({ limit: 100, before }).catch(() => null);
        if (!batch || !batch.size) break;
        all.push(...batch.values());
        before = batch.last().id;
        if (batch.size < 100) break;
    }
    all.reverse();
    const lines = all.map(m => {
        const time = new Date(m.createdTimestamp).toISOString().replace('T', ' ').slice(0, 19);
        const files = m.attachments.size ? ` [${m.attachments.map(a => a.url).join(' , ')}]` : '';
        return `[${time}] ${m.author.tag}: ${m.content || (m.embeds.length ? '(إمبد)' : '')}${files}`;
    });
    return new AttachmentBuilder(Buffer.from(lines.join('\n') || 'لا توجد رسائل', 'utf8'), { name: `${channel.name}.txt` });
};

const close = async (channel, closer, replyFn) => {
    const g = db.guild(channel.guild.id);
    const ticket = g.tickets.open[channel.id];
    if (!ticket) return null;

    await replyFn({ embeds: [e.warn('سيتم إغلاق التذكرة وحذف الروم بعد 5 ثواني 🔒', '🔒 إغلاق التذكرة')] });

    const file = await transcript(channel);
    const embed = e.base(e.colors.err)
        .setTitle(`🔒 تم إغلاق تذكرة ${ticket.number}`)
        .addFields(
            { name: '👤 صاحبها', value: `<@${ticket.owner}>`, inline: true },
            { name: '🔒 أغلقها', value: `${closer}`, inline: true },
            { name: '✋ المستلم', value: ticket.claimed ? `<@${ticket.claimed}>` : 'لا أحد', inline: true },
            { name: '📝 السبب', value: ticket.reason || 'غير محدد', inline: false }
        );

    const logChannel = g.tickets.logs && channel.guild.channels.cache.get(g.tickets.logs);
    if (logChannel) await logChannel.send({ embeds: [embed], files: [file] }).catch(() => {});

    const owner = await channel.client.users.fetch(ticket.owner).catch(() => null);
    if (owner) await owner.send({ embeds: [embed], files: [await transcript(channel)] }).catch(() => {});

    delete g.tickets.open[channel.id];
    db.save();
    setTimeout(() => channel.delete().catch(() => {}), 5000);
    return true;
};

const claim = async (channel, member) => {
    const g = db.guild(channel.guild.id);
    const ticket = g.tickets.open[channel.id];
    if (!ticket) return false;
    ticket.claimed = member.id;
    db.save();
    return true;
};

module.exports = { panelRow, controlRow, panel, modal, isTicket, open, close, claim, transcript };
