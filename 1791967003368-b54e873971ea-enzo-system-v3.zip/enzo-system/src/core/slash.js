// سلاش لكل أوامر البوت العادية: كل قسم = أمر سلاش فيه أوامره كأوامر فرعية
// (ديسكورد يحدد 100 أمر سلاش فقط، فالتجميع حسب القسم يخلي كل الأوامر متاحة)
const config = require('../../config');
const db = require('../utils/db');
const e = require('../utils/embeds');
const { gate, run } = require('./handler');

const TYPE = { sub: 1, string: 3, boolean: 5, user: 6, channel: 7, role: 8, attachment: 11 };

// اسم أمر السلاش لكل ملف أوامر. المصفوفة = تقسيم القسم لأكثر من أمر (من، إلى)
const groups = {
    dashboard: { single: true },
    help: { single: true },
    moderation: [['عقوبات', 0, 10], ['تحكم', 10, 99]],
    protection: 'حماية',
    tickets: 'تذاكر',
    settings: 'ضبط',
    automation: 'اتمتة',
    utility: 'ادوات',
    economy: 'اقتصاد',
    levels: 'مستويات',
    fun: 'ترفيه',
    voice: 'صوت',
    admin: 'ادارة',
    backup: 'نسخ'
};

// أوامر شكل استخدامها ما ينقرأ تلقائياً من usage
const overrides = {
    'استثناء': [
        { name: 'العضو', type: 'user', required: false, desc: 'العضو المستثنى' },
        { name: 'الرتبة', type: 'role', required: false, desc: 'أو الرتبة المستثناة' }
    ],
    'حجر': [{ name: 'اختيارك', type: 'string', required: true, desc: 'حجر أو ورقة أو مقص', choices: ['حجر', 'ورقة', 'مقص'] }],
    'اختر': [{ name: 'الخيارات', type: 'string', required: true, desc: 'افصل بين الخيارات بالرمز |' }],
    'حاسبة': [{ name: 'العملية', type: 'string', required: true, desc: 'مثال: 5*(3+2)' }],
    'بوست_اعداد': [
        { name: 'الروم', type: 'channel', required: true, desc: 'روم رسالة الشكر' },
        { name: 'امبد', type: 'boolean', required: false, desc: 'إرسالها كامبد' },
        { name: 'الرسالة', type: 'string', required: true, desc: 'النص ({user} {server})' }
    ],
    'استعادة': [{ name: 'الملف', type: 'attachment', required: true, desc: 'ملف النسخة الاحتياطية (.json.gz)' }]
};

// أوامر تفصل بين خياراتها النصية بالرمز | (مثل الصيغة العادية)
const pipeJoined = new Set(['رد_اضافة', 'امبد']);

const clean = (text, max) => String(text).replace(/\s+/g, ' ').trim().slice(0, max);

const optionName = (text, type, used) => {
    let base;
    if (type === 'user') base = 'العضو';
    else if (type === 'role') base = 'الرتبة';
    else if (type === 'channel') base = 'الروم';
    else {
        const words = text.split('|')[0].replace(/[^\p{L}\p{N}\s_]/gu, ' ').trim().split(/\s+/).filter(Boolean);
        base = words[0] || 'نص';
        if (base.length <= 4 && words[1] && base.length + words[1].length < 20) base = `${base}_${words[1]}`;
    }
    base = base.toLowerCase().slice(0, 28);
    let name = base;
    for (let n = 2; used.has(name); n++) name = `${base}_${n}`;
    used.add(name);
    return name;
};

const makeSpec = (text, required, used) => {
    let type = 'string';
    let choices = null;
    let forced = null;
    if (text.includes('العضو')) type = 'user';
    else if (text.includes('الرتبة')) type = 'role';
    else if (/الروم|التصنيف/.test(text)) type = 'channel';

    const alts = text.split('|').map(x => x.trim());
    if (type === 'string' && alts.length === 2) {
        const joined = alts.join('|');
        if (joined === 'تشغيل|ايقاف') choices = alts;
        else if (joined === 'صورة|كتابة') { choices = alts; forced = 'النوع'; }
    }
    const name = forced || optionName(text, type, used);
    return { name, type, required, choices, desc: clean(text.replace(/^[@#]/, ''), 100) || name };
};

const specsOf = cmd => {
    if (overrides[cmd.name]) return overrides[cmd.name];
    const usage = (cmd.usage || '').trim();
    const rest = usage.startsWith(cmd.name) ? usage.slice(cmd.name.length) : usage;
    const used = new Set();
    const specs = [];
    const re = /<([^>]+)>|\[([^\]]+)\]|([@#][^\s<[]+(?:\s+الصوتي)?)/g;
    let m;
    while ((m = re.exec(rest))) {
        const required = m[1] !== undefined || m[3] !== undefined;
        specs.push(makeSpec((m[1] ?? m[2] ?? m[3]).trim(), required, used));
    }
    return specs;
};

const toOption = spec => {
    const opt = { type: TYPE[spec.type], name: spec.name, description: spec.desc.slice(0, 100), required: spec.required };
    if (spec.choices) opt.choices = spec.choices.map(c => ({ name: c, value: c }));
    return opt;
};

// الخيارات المطلوبة لازم تجي قبل الاختيارية في تعريف السلاش (الترتيب الفعلي للقيم يبقى حسب specs)
const optionList = specs => [...specs.filter(s => s.required), ...specs.filter(s => !s.required)].map(toOption);

const subOf = cmd => {
    const specs = specsOf(cmd);
    return { type: TYPE.sub, name: cmd.name, description: clean(cmd.desc || cmd.name, 100), options: optionList(specs), specs };
};

// يبني تعريفات السلاش لكل أوامر البوت العادية ويحفظ جدول التنفيذ في client.slashCore
const build = client => {
    client.slashCore = new Map();
    const body = [];
    const seen = new Set();

    for (const [module, def] of Object.entries(groups)) {
        const category = [...client.categories.values()].find(c => c.commands[0]?.module === module);
        if (!category) continue;
        const cmds = category.commands;
        const icon = category.icon || '';
        const catName = [...client.categories.entries()].find(([, v]) => v === category)[0];

        if (def.single) {
            const cmd = cmds[0];
            const sub = subOf(cmd);
            body.push({ name: cmd.name, description: sub.description, options: sub.options, dm_permission: false });
            client.slashCore.set(cmd.name, { single: true, cmd, specs: sub.specs });
            seen.add(cmd.name);
            continue;
        }

        const chunks = Array.isArray(def)
            ? def.map(([name, from, to]) => ({ name, list: cmds.slice(from, to) }))
            : [{ name: def, list: cmds }];

        for (const chunk of chunks) {
            if (!chunk.list.length) continue;
            const subs = new Map();
            const options = [];
            for (const cmd of chunk.list) {
                const sub = subOf(cmd);
                subs.set(cmd.name, { cmd, specs: sub.specs });
                options.push({ type: sub.type, name: sub.name, description: sub.description, options: sub.options });
            }
            body.push({ name: chunk.name, description: clean(`${icon} ${catName}`, 100), options, dm_permission: false });
            client.slashCore.set(chunk.name, { single: false, subs });
            seen.add(chunk.name);
        }
    }
    return body;
};

// ───────── التنفيذ: تحويل تفاعل السلاش إلى "رسالة" يفهمها كود الأوامر ─────────
const makeMessage = (interaction, channel, attachment) => {
    const state = { replied: false, closed: false };
    const attachments = new Map();
    if (attachment) attachments.set(attachment.id, attachment);
    attachments.first = () => attachment || undefined;

    const normalize = payload => {
        const body = typeof payload === 'string' ? { content: payload } : { ...payload };
        delete body.failIfNotExists;
        delete body.reply;
        return body;
    };

    const message = {
        id: interaction.id,
        content: '',
        author: interaction.user,
        member: interaction.member,
        guild: interaction.guild,
        channel,
        client: interaction.client,
        createdTimestamp: interaction.createdTimestamp,
        attachments,
        reference: null,
        embeds: [],
        type: 0,
        interaction,
        state,
        async reply(payload) {
            const body = normalize(payload);
            if (state.closed) return channel.send(body);
            if (!state.replied) {
                state.replied = true;
                delete body.flags;
                return interaction.editReply(body);
            }
            return interaction.followUp(body);
        },
        delete: async () => {},
        react: async () => {}
    };
    return message;
};

const argsOf = (cmd, specs, interaction) => {
    const args = [];
    let strings = 0;
    for (const spec of specs) {
        const opt = interaction.options.get(spec.name);
        if (!opt || opt.value === undefined || opt.value === null) continue;
        if (spec.type === 'user') args.push(`<@${opt.user?.id || opt.value}>`);
        else if (spec.type === 'role') args.push(`<@&${opt.role?.id || opt.value}>`);
        else if (spec.type === 'channel') args.push(`<#${opt.channel?.id || opt.value}>`);
        else if (spec.type === 'boolean') { if (opt.value) args.push(spec.name); }
        else if (spec.type === 'attachment') continue;
        else {
            if (pipeJoined.has(cmd.name) && strings > 0) args.push('|');
            strings += 1;
            args.push(...String(opt.value).trim().split(/\s+/).filter(Boolean));
        }
    }
    return args;
};

const handle = async (client, interaction) => {
    if (!interaction.isChatInputCommand() || !client.slashCore) return false;
    const entry = client.slashCore.get(interaction.commandName);
    if (!entry) return false;

    let cmd;
    let specs;
    if (entry.single) ({ cmd, specs } = entry);
    else {
        const target = entry.subs.get(interaction.options.getSubcommand(false));
        if (!target) return true;
        ({ cmd, specs } = target);
    }

    await interaction.deferReply().catch(() => {});
    const channel = interaction.channel || await interaction.guild.channels.fetch(interaction.channelId).catch(() => null);
    if (!channel) {
        await interaction.editReply({ embeds: [e.err('ما قدرت أوصل لهذا الروم.')] }).catch(() => {});
        return true;
    }

    const attachment = specs.some(s => s.type === 'attachment') ? interaction.options.getAttachment('الملف') : null;
    const message = makeMessage(interaction, channel, attachment);
    const args = argsOf(cmd, specs, interaction);
    const prefix = db.guild(interaction.guild.id).prefix ?? config.prefix;

    if (await gate(cmd, message)) await run(interaction.client, cmd, message, args, cmd.name, prefix);

    // الأوامر اللي ترسل نتيجتها في الروم مباشرة (مثل قل) ما ترد، فنشيل رسالة "يفكر..."
    if (!message.state.replied) {
        message.state.closed = true;
        await interaction.deleteReply().catch(() => {});
    }
    return true;
};

const deploy = async client => {
    if (process.env.DEPLOY_SLASH === 'false') return;
    const { REST, Routes } = require('discord.js');
    try {
        const body = [...client.extSlash.values()].map(c => c.data.toJSON()).concat(build(client));
        const rest = new REST({ version: '10' }).setToken(client.token);
        const gid = process.env.GUILD_ID?.trim();
        if (gid && client.guilds.cache.has(gid)) await rest.put(Routes.applicationGuildCommands(client.user.id, gid), { body });
        else await rest.put(Routes.applicationCommands(client.user.id), { body });
        console.log(`[Slash] تم تسجيل ${body.length} أمر سلاش (تشمل كل الأوامر العادية كأوامر فرعية)`);
    } catch (err) {
        console.error('[Slash] فشل تسجيل أوامر السلاش:', err.message, err.rawError ? JSON.stringify(err.rawError.errors || err.rawError).slice(0, 600) : '');
    }
};

module.exports = { build, handle, deploy, specsOf };
