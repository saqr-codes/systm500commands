const { PermissionFlagsBits: P } = require('discord.js');
const config = require('../../config');
const db = require('../utils/db');
const e = require('../utils/embeds');
const log = require('../utils/log');
const { norm } = require('../utils/text');

const inviteRegex = /(discord\.gg|discord(?:app)?\.com\/invite)\/[a-z0-9-]+/i;
const linkRegex = /(https?:\/\/\S+|www\.\S+)/i;

const history = new Map();
const joins = new Map();

setInterval(() => {
    const now = Date.now();
    for (const [k, list] of history) {
        if (!list.length || now - list[list.length - 1].at > 10000) history.delete(k);
    }
    for (const [k, list] of joins) {
        if (!list.length || now - list[list.length - 1].at > 20000) joins.delete(k);
    }
}, 600000).unref();

const exempt = (message, p) => {
    const m = message.member;
    if (!m) return true;
    if (config.owners.includes(m.id)) return true;
    if (m.id === message.guild.ownerId) return true;
    if (m.permissions.has(P.Administrator) || m.permissions.has(P.ManageMessages)) return true;
    if (p.users.includes(m.id)) return true;
    return p.roles.some(id => m.roles.cache.has(id));
};

const escalate = async (message, reason) => {
    const g = db.guild(message.guild.id);
    const action = g.protection.action;
    if (action === 'timeout') {
        await message.member.timeout(5 * 60000, reason).catch(() => {});
    } else if (action === 'warn') {
        g.warnCounter += 1;
        (g.warns[message.author.id] ||= []).push({ id: g.warnCounter, reason: `[حماية تلقائية] ${reason}`, mod: message.client.user.id, at: Date.now() });
        db.save();
    }
};

const punish = async (message, reason, extra) => {
    await message.delete().catch(() => {});
    await escalate(message, reason);
    const embed = e.warn(`${message.author} ${reason}`, '🛡️ نظام الحماية');
    const sent = await message.channel.send({ embeds: [embed], ...e.opts }).catch(() => null);
    if (sent) setTimeout(() => sent.delete().catch(() => {}), 5000);
    log.action(message.guild, '🛡️ مخالفة', e.colors.warn, [
        { name: '👤 العضو', value: `${message.author}\n\`${message.author.id}\``, inline: true },
        { name: '📺 الروم', value: `${message.channel}`, inline: true },
        { name: '📌 المخالفة', value: reason, inline: false },
        ...(extra ? [{ name: '💬 الرسالة', value: message.content.slice(0, 900) || '-', inline: false }] : [])
    ]);
};

const message = async msg => {
    const p = db.guild(msg.guild.id).protection;
    if (!(p.links || p.invites || p.spam || p.mentions || p.badwords)) return false;
    if (exempt(msg, p)) return false;

    const text = msg.content;

    if (p.invites && inviteRegex.test(text)) {
        await punish(msg, 'ممنوع نشر روابط الدعوات هنا.', true);
        return true;
    }

    if (p.links && linkRegex.test(text)) {
        await punish(msg, 'ممنوع نشر الروابط هنا.', true);
        return true;
    }

    if (p.badwords && p.words.length) {
        const clean = norm(text);
        if (p.words.some(w => w && clean.includes(norm(w)))) {
            await punish(msg, 'استخدمت كلمة ممنوعة.', true);
            return true;
        }
    }

    if (p.mentions && (msg.mentions.users.size + msg.mentions.roles.size) >= 5) {
        await punish(msg, 'ممنوع الإكثار من المنشن.', false);
        await msg.member.timeout(5 * 60000, 'منشن مزعج').catch(() => {});
        return true;
    }

    if (p.spam) {
        const key = `${msg.guild.id}:${msg.author.id}`;
        const now = Date.now();
        const list = (history.get(key) || []).filter(x => now - x.at < 4000);
        list.push({ at: now, id: msg.id });
        history.set(key, list);
        if (list.length >= 5) {
            history.delete(key);
            await msg.channel.bulkDelete(list.map(x => x.id), true).catch(() => {});
            await msg.member.timeout(5 * 60000, 'سبام').catch(() => {});
            const sent = await msg.channel.send({
                embeds: [e.warn(`${msg.author} تم إسكاتك 5 دقائق بسبب السبام.`, '🛡️ نظام الحماية')],
                ...e.opts
            }).catch(() => null);
            if (sent) setTimeout(() => sent.delete().catch(() => {}), 5000);
            log.action(msg.guild, '🛡️ سبام', e.colors.warn, [
                { name: '👤 العضو', value: `${msg.author}\n\`${msg.author.id}\``, inline: true },
                { name: '⏱️ العقوبة', value: 'إسكات 5 دقائق', inline: true }
            ]);
            return true;
        }
    }

    return false;
};

const raid = async member => {
    const p = db.guild(member.guild.id).protection;
    if (!p.raid) return false;
    const now = Date.now();
    const list = (joins.get(member.guild.id) || []).filter(x => now - x.at < 10000);
    list.push({ at: now, id: member.id });
    joins.set(member.guild.id, list);
    if (list.length < 7) return false;

    for (const entry of list) {
        const target = member.guild.members.cache.get(entry.id);
        if (target && target.kickable) await target.kick('حماية من الريد').catch(() => {});
    }
    joins.set(member.guild.id, []);
    log.action(member.guild, '🚨 حماية الريد', e.colors.err, [
        { name: '📌 الحالة', value: `تم طرد **${list.length}** عضو دخلوا بشكل جماعي خلال 10 ثواني`, inline: false }
    ]);
    return true;
};

module.exports = { message, raid };
