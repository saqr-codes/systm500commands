// setTimeout آمن للمدد الطويلة (جافاسكربت يلغي أي مدة أكبر من ~24.8 يوم وينفذها فوراً)
const MAX = 2 ** 31 - 1;

const later = (fn, ms) => {
    const handle = { timer: null, cancelled: false };
    const step = left => {
        handle.timer = setTimeout(() => {
            if (handle.cancelled) return;
            if (left > MAX) step(left - MAX);
            else fn();
        }, Math.min(Math.max(left, 0), MAX));
    };
    step(ms);
    handle.cancel = () => { handle.cancelled = true; clearTimeout(handle.timer); };
    return handle;
};

module.exports = { later };
