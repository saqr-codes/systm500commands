// حالة البوت: من الداشبورد (محفوظة محلياً) أو من .env
const { ActivityType } = require('discord.js');
const config = require('../../config');
const db = require('./db');

const types = { Playing: ActivityType.Playing, Watching: ActivityType.Watching, Listening: ActivityType.Listening, Competing: ActivityType.Competing };
let timer = null;

const apply = client => {
    if (timer) clearInterval(timer);
    timer = null;
    const s = db.meta().status;
    const names = (s.names && s.names.length ? s.names : config.status.names).filter(Boolean);
    const status = ['online', 'idle', 'dnd', 'invisible'].includes(s.presence) ? s.presence : 'online';
    if (!names.length) return client.user.setPresence({ status, activities: [] });
    let index = 0;
    const tick = () => {
        client.user.setPresence({ status, activities: [{ name: names[index], type: types[s.type] ?? ActivityType.Playing }] });
        index = (index + 1) % names.length;
    };
    tick();
    if (names.length > 1) timer = setInterval(tick, config.status.interval).unref();
};

module.exports = { apply, types: Object.keys(types) };
