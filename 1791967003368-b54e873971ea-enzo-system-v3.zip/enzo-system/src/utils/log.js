const db = require('./db');
const e = require('./embeds');

// مفاتيح السجلات المفصلة (كل نوع يقدر ينرسل لروم مختلف، وإذا ما انحدد يروح لروم السجلات العام)
const events = [
    ['ban', '🔨 الحظر'], ['unban', '♻️ فك الحظر'], ['kick', '👢 الطرد'], ['timeout', '🔇 الإسكات'], ['warn', '⚠️ التحذيرات'],
    ['messageDelete', '🗑️ حذف الرسائل'], ['messageEdit', '✏️ تعديل الرسائل'], ['join', '📥 دخول الأعضاء'], ['leave', '📤 خروج الأعضاء'],
    ['channelCreate', '📗 إنشاء روم'], ['channelDelete', '📕 حذف روم'], ['roleCreate', '🎭 إنشاء رتبة'], ['roleDelete', '🎭 حذف رتبة'],
    ['nick', '🏷️ تغيير اللقب'], ['memberRoles', '➕ رتب الأعضاء'], ['voice', '🎙️ الرومات الصوتية']
];

const send = (guild, embed, key) => {
    const g = db.guild(guild.id);
    const id = (key && g.logChannels[key]) || g.logs;
    if (!id) return;
    const channel = guild.channels.cache.get(id);
    if (channel) channel.send({ embeds: [embed], ...e.opts }).catch(() => {});
};

const action = (guild, title, color, fields, key) => {
    send(guild, e.base(color).setTitle(title).addFields(fields), key);
};

module.exports = { send, action, events };
