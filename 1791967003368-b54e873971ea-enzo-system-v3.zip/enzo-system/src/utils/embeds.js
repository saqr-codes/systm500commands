const { EmbedBuilder } = require('discord.js');
const config = require('../../config');

const colors = {
    main: 0x6c5ce7,
    ok: 0x2ecc71,
    err: 0xe74c3c,
    warn: 0xf39c12,
    info: 0x3498db,
    gold: 0xf1c40f,
    dark: 0x2b2d31
};

const base = (color = colors.main) => {
    const embed = new EmbedBuilder().setColor(color).setTimestamp();
    if (config.footer) embed.setFooter({ text: config.footer });
    return embed;
};

const ok = (text, title = '✅ تمت العملية') => base(colors.ok).setTitle(title).setDescription(text);
const err = (text, title = '❌ تنبيه') => base(colors.err).setTitle(title).setDescription(text);
const warn = (text, title = '⚠️ تنبيه') => base(colors.warn).setTitle(title).setDescription(text);
const info = (title, text) => base(colors.main).setTitle(title).setDescription(text);

const opts = { allowedMentions: { repliedUser: false, parse: [] } };

const reply = (message, embed, extra = {}) => message.reply({ embeds: [embed], ...opts, ...extra });
const send = (channel, embed, extra = {}) => channel.send({ embeds: [embed], ...opts, ...extra });

const temp = async (message, embed, seconds = 5) => {
    const sent = await reply(message, embed).catch(() => null);
    if (sent) setTimeout(() => sent.delete().catch(() => {}), seconds * 1000);
    return sent;
};

module.exports = { colors, base, ok, err, warn, info, reply, send, temp, opts };
