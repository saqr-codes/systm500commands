// تذكيرات تنحفظ محلياً وما تضيع عند إعادة تشغيل البوت
const crypto = require('crypto');
const db = require('./db');
const e = require('./embeds');
const { later } = require('./timers');

const schedule = (client, reminder) => later(async () => {
    const list = db.meta().reminders;
    const index = list.findIndex(x => x.id === reminder.id);
    if (index !== -1) { list.splice(index, 1); db.save(); }
    const payload = {
        content: `<@${reminder.userId}>`,
        embeds: [e.info('⏰ تذكير', reminder.text)],
        allowedMentions: { users: [reminder.userId] }
    };
    const channel = await client.channels.fetch(reminder.channelId).catch(() => null);
    const sent = channel ? await channel.send(payload).catch(() => null) : null;
    if (!sent) {
        const user = await client.users.fetch(reminder.userId).catch(() => null);
        if (user) user.send({ embeds: payload.embeds }).catch(() => {});
    }
}, reminder.at - Date.now());

const add = (client, { channelId, userId, text, ms }) => {
    const reminder = { id: crypto.randomBytes(5).toString('hex'), channelId, userId, text: text.slice(0, 1500), at: Date.now() + ms };
    db.meta().reminders.push(reminder);
    db.save();
    schedule(client, reminder);
    return reminder;
};

const countFor = userId => db.meta().reminders.filter(x => x.userId === userId).length;

const start = client => {
    for (const reminder of db.meta().reminders) schedule(client, reminder);
};

module.exports = { add, start, countFor };
