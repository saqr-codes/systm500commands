const digits = s => String(s).replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));

const units = { 'ث': 1000, s: 1000, 'د': 60000, m: 60000, 'س': 3600000, h: 3600000, 'ي': 86400000, d: 86400000 };

const parseDuration = input => {
    if (!input) return null;
    const m = digits(input).trim().match(/^(\d+)\s*(ث|د|س|ي|s|m|h|d)?$/i);
    if (!m) return null;
    return Number(m[1]) * units[(m[2] || 'د').toLowerCase()];
};

const formatDuration = ms => {
    let s = Math.floor(ms / 1000);
    const d = Math.floor(s / 86400); s %= 86400;
    const h = Math.floor(s / 3600); s %= 3600;
    const m = Math.floor(s / 60); s %= 60;
    const parts = [];
    if (d) parts.push(`${d} يوم`);
    if (h) parts.push(`${h} ساعة`);
    if (m) parts.push(`${m} دقيقة`);
    if (s || !parts.length) parts.push(`${s} ثانية`);
    return parts.join(' و ');
};

const stamp = (date, style = 'R') => `<t:${Math.floor(new Date(date).getTime() / 1000)}:${style}>`;

const num = n => Number(n).toLocaleString('en-US');

const bar = (value, max, size = 12) => {
    const filled = Math.round(Math.min(1, value / (max || 1)) * size);
    return '▰'.repeat(filled) + '▱'.repeat(size - filled);
};

const pick = list => list[Math.floor(Math.random() * list.length)];

const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

module.exports = { digits, parseDuration, formatDuration, stamp, num, bar, pick, rand };
