const e = require('./embeds');

const permNames = {
    Administrator: 'مدير',
    BanMembers: 'حظر الأعضاء',
    KickMembers: 'طرد الأعضاء',
    ModerateMembers: 'إسكات الأعضاء',
    ManageMessages: 'إدارة الرسائل',
    ManageChannels: 'إدارة القنوات',
    ManageRoles: 'إدارة الرتب',
    ManageGuild: 'إدارة السيرفر',
    ManageNicknames: 'إدارة الألقاب',
    MoveMembers: 'نقل الأعضاء',
    MuteMembers: 'كتم الأعضاء',
    MentionEveryone: 'منشن الجميع'
};

const guard = async (message, target) => {
    const me = message.guild.members.me;
    const fail = text => e.reply(message, e.err(text)).then(() => false);

    if (target.id === message.author.id) return fail('ما تقدر تطبق هذا الأمر على نفسك.');
    if (target.id === message.guild.ownerId) return fail('ما أقدر أطبق هذا الأمر على مالك السيرفر.');
    if (target.id === message.client.user.id) return fail('ما أقدر أطبق هذا الأمر على نفسي.');

    const isOwner = message.author.id === message.guild.ownerId;
    if (!isOwner && message.member.roles.highest.position <= target.roles.highest.position) {
        return fail('رتبة العضو أعلى منك أو تساوي رتبتك.');
    }
    if (target.roles.highest.position >= me.roles.highest.position) {
        return fail('رتبة العضو أعلى من رتبة البوت، ارفع رتبتي أولاً.');
    }
    return true;
};

const caseEmbed = (title, color, user, moderator, reason, extra = []) =>
    e.base(color)
        .setTitle(title)
        .setThumbnail(user.displayAvatarURL({ size: 256 }))
        .addFields(
            { name: '👤 العضو', value: `${user}\n\`${user.id}\``, inline: true },
            { name: '🛡️ المشرف', value: `${moderator}`, inline: true },
            ...extra,
            { name: '📝 السبب', value: reason, inline: false }
        );

const notify = (user, guild, action, reason) =>
    user.send({
        embeds: [
            e.base(e.colors.warn)
                .setTitle(`📨 ${action}`)
                .setDescription(`**السيرفر:** ${guild.name}\n**السبب:** ${reason}`)
        ]
    }).catch(() => {});

module.exports = { permNames, guard, caseEmbed, notify };
