const idOf = (arg, kind) => {
    if (!arg) return null;
    const patterns = {
        user: /^<@!?(\d{15,20})>$/,
        role: /^<@&(\d{15,20})>$/,
        channel: /^<#(\d{15,20})>$/
    };
    const m = arg.match(patterns[kind]);
    if (m) return m[1];
    return /^\d{15,20}$/.test(arg) ? arg : null;
};

const member = async (message, arg) => {
    if (!arg) return null;
    const id = idOf(arg, 'user');
    if (id) return message.guild.members.fetch(id).catch(() => null);
    const q = arg.toLowerCase();
    return message.guild.members.cache.find(m =>
        m.user.username.toLowerCase() === q || m.displayName.toLowerCase() === q
    ) || null;
};

const user = async (client, arg) => {
    const id = idOf(arg, 'user');
    if (!id) return null;
    return client.users.fetch(id).catch(() => null);
};

const role = (message, arg) => {
    if (!arg) return null;
    const id = idOf(arg, 'role');
    if (id) return message.guild.roles.cache.get(id) || null;
    const q = arg.toLowerCase();
    return message.guild.roles.cache.find(r => r.name.toLowerCase() === q) || null;
};

const channel = (message, arg) => {
    if (!arg) return null;
    const id = idOf(arg, 'channel');
    if (id) return message.guild.channels.cache.get(id) || null;
    const q = arg.toLowerCase();
    return message.guild.channels.cache.find(c => c.name.toLowerCase() === q) || null;
};

module.exports = { member, user, role, channel, idOf };
