const db = require('./db');
const e = require('./embeds');
const { rand } = require('./time');

const need = level => 5 * level * level + 50 * level + 100;

const cooldown = new Map();

setInterval(() => {
    const now = Date.now();
    for (const [k, at] of cooldown) if (now - at > 60000) cooldown.delete(k);
}, 600000).unref();

// يعطي العضو كل رتب المستويات اللي وصلها (يشتغل مع الترقية العادية ومع إعطاء الخبرة اليدوي)
const applyRoles = member => {
    const level = db.user(member.guild.id, member.id).level;
    const roles = Object.entries(db.guild(member.guild.id).levelRoles)
        .filter(([lvl, id]) => Number(lvl) <= level && !member.roles.cache.has(id))
        .map(([, id]) => id);
    for (const id of roles) member.roles.add(id).catch(() => {});
};

// يضيف خبرة ويرجع المستوى الجديد لو صار فيه ترقية (وإلا null)
const addXp = (guildId, userId, amount) => {
    const profile = db.user(guildId, userId);
    profile.xp += amount;
    let up = false;
    while (profile.xp >= need(profile.level)) {
        profile.xp -= need(profile.level);
        profile.level += 1;
        profile.cash += profile.level * 50;
        up = true;
    }
    return up ? profile.level : null;
};

const announce = (guild, fallbackChannel, user, level) => {
    const cfg = db.guild(guild.id).levels;
    const channel = (cfg.channel && guild.channels.cache.get(cfg.channel)) || fallbackChannel;
    if (!channel) return;
    const embed = e.base(e.colors.gold)
        .setTitle('🎉 ترقية مستوى')
        .setDescription(`مبروك ${user} وصلت للمستوى **${level}**\nمكافأتك **${level * 50}** عملة`);
    channel.send({ embeds: [embed], ...e.opts }).catch(() => {});
};

const give = async message => {
    const key = `${message.guild.id}:${message.author.id}`;
    const now = Date.now();
    const profile = db.user(message.guild.id, message.author.id);
    const cfg = db.guild(message.guild.id).levels;
    profile.messages += 1;

    if (cfg.enabled && now - (cooldown.get(key) || 0) >= 60000) {
        cooldown.set(key, now);
        const min = Math.min(cfg.xpMin, cfg.xpMax);
        const max = Math.max(cfg.xpMin, cfg.xpMax);
        const level = addXp(message.guild.id, message.author.id, rand(min, max));
        if (level) {
            announce(message.guild, message.channel, message.author, level);
            applyRoles(message.member);
        }
    }
    db.save();
};

// خبرة الصوت: تنستدعى كل دقيقة لكل عضو داخل روم صوتي
const voiceTick = (client, guildId, userId) => {
    const cfg = db.guild(guildId).levels;
    if (!cfg.enabled || !cfg.voiceEnabled) return;
    const guild = client.guilds.cache.get(guildId);
    const member = guild?.members.cache.get(userId);
    if (!member || member.user.bot || member.voice.selfDeaf || member.voice.serverDeaf) return;
    const min = Math.min(cfg.voiceMin, cfg.voiceMax);
    const max = Math.max(cfg.voiceMin, cfg.voiceMax);
    const level = addXp(guildId, userId, rand(min, max));
    if (level) {
        announce(guild, null, member, level);
        applyRoles(member);
    }
};

module.exports = { need, give, applyRoles, addXp, voiceTick };
