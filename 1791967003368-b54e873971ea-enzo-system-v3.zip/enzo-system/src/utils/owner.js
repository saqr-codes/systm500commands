const config = require('../../config');

// مالك البوت: من OWNERS في .env، أو مالك السيرفر لو ما فيه OWNERS والبوت داخل سيرفر واحد فقط
const isBotOwner = (client, userId, guild) => {
    if (config.owners.includes(userId)) return true;
    return config.owners.length === 0 && client.guilds.cache.size === 1 && guild?.ownerId === userId;
};

module.exports = { isBotOwner };
