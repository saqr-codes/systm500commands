// نسخ احتياطي يومي لكل بيانات البوت: حفظ محلي في backups/ + إرسال لروم محدد
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { AttachmentBuilder } = require('discord.js');
const { isBotOwner } = require('./owner');
const db = require('./db');
const extDb = require('../ext/database/db');

const root = path.join(__dirname, '..', '..');
const backupDir = path.join(root, 'backups');
const DAY = 24 * 3600 * 1000;
const KEEP_LOCAL = 14;
const SIZE_FALLBACK = 9.5 * 1024 * 1024;

const pad = n => String(n).padStart(2, '0');
const stampName = (d = new Date()) =>
    `backup_${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}_${pad(d.getHours())}-${pad(d.getMinutes())}.json.gz`;

// من يقدر يدير النسخ الاحتياطي: مالك البوت، أو مالك السيرفر لو ما فيه OWNERS والبوت بسيرفر واحد
const canManage = isBotOwner;

const build = () => {
    db.flush();
    extDb.flush();
    const payload = { version: 2, createdAt: new Date().toISOString(), main: db.snapshot(), ext: extDb.snapshot() };
    return zlib.gzipSync(Buffer.from(JSON.stringify(payload), 'utf8'), { level: 9 });
};

const saveLocal = (buffer, name) => {
    fs.mkdirSync(backupDir, { recursive: true });
    const file = path.join(backupDir, name);
    fs.writeFileSync(file, buffer);
    const files = fs.readdirSync(backupDir)
        .filter(f => f.startsWith('backup_') && (f.endsWith('.json.gz') || f.endsWith('.json')))
        .map(f => ({ f, t: fs.statSync(path.join(backupDir, f)).mtimeMs }))
        .sort((a, b) => b.t - a.t);
    for (const old of files.slice(KEEP_LOCAL)) fs.unlinkSync(path.join(backupDir, old.f));
    return file;
};

const sendToRoom = async (client, buffer, name, reason) => {
    const id = db.meta().backup.channelId;
    if (!id) return { sent: false, note: 'لم يتم تحديد روم للنسخ' };
    const channel = await client.channels.fetch(id).catch(() => null);
    if (!channel || !channel.isTextBased()) return { sent: false, note: 'تعذر الوصول لروم النسخ الاحتياطي' };
    const limit = channel.guild?.maximumUploadLimit || SIZE_FALLBACK;
    if (buffer.length > limit - 100 * 1024) {
        return { sent: false, note: `حجم النسخة (${(buffer.length / 1048576).toFixed(1)}MB) أكبر من حد الرفع في الروم` };
    }
    const totalGuilds = db.guildCount();
    await channel.send({
        content: `💾 **نسخة احتياطية** • ${reason}\n🗓️ <t:${Math.floor(Date.now() / 1000)}:F>\n📦 ${(buffer.length / 1024).toFixed(1)} KB • 🏰 ${totalGuilds} سيرفر\nللاستعادة: اكتب \`استعادة\` وأرفق هذا الملف أو رد عليه.`,
        files: [new AttachmentBuilder(buffer, { name })],
        allowedMentions: { parse: [] }
    });
    return { sent: true, note: null };
};

let running = false;

const run = async (client, reason = 'تلقائي') => {
    if (running) return { ok: false, error: 'فيه نسخة قيد التنفيذ' };
    running = true;
    const state = db.meta().backup;
    try {
        const buffer = build();
        const name = stampName();
        saveLocal(buffer, name);
        const result = await sendToRoom(client, buffer, name, reason).catch(err => ({ sent: false, note: err.message }));
        state.last = Date.now();
        state.lastSize = buffer.length;
        state.lastError = result.sent ? null : result.note;
        db.save();
        console.log(`[Backup] ${name} (${(buffer.length / 1024).toFixed(1)} KB) ${result.sent ? 'أرسلت للروم' : `محلية فقط: ${result.note}`}`);
        return { ok: true, name, size: buffer.length, sent: result.sent, note: result.note };
    } catch (err) {
        state.lastError = err.message;
        db.save();
        console.error('[Backup] فشل النسخ الاحتياطي:', err.message);
        return { ok: false, error: err.message };
    } finally {
        running = false;
    }
};

const restore = buffer => {
    const raw = buffer[0] === 0x1f && buffer[1] === 0x8b ? zlib.gunzipSync(buffer) : buffer;
    const data = JSON.parse(raw.toString('utf8'));
    if (!data || !data.main || !data.ext) throw new Error('هذا الملف مو نسخة احتياطية صالحة');
    // نسخة أمان قبل الاستبدال
    saveLocal(build(), stampName().replace('backup_', 'backup_pre-restore_'));
    const keep = { ...db.meta().backup };
    db.replaceAll(data.main);
    extDb.replaceAll(data.ext);
    Object.assign(db.meta().backup, { channelId: keep.channelId, enabled: keep.enabled });
    db.save();
    return { guilds: Object.keys(data.main.guilds).length, createdAt: data.createdAt || null };
};

const start = client => {
    const tick = () => {
        const state = db.meta().backup;
        if (!state.enabled) return;
        if (Date.now() - state.last >= DAY) run(client, 'يومي تلقائي');
    };
    setTimeout(tick, 60 * 1000).unref();
    setInterval(tick, 10 * 60 * 1000).unref();
};

module.exports = { run, start, restore, canManage, build, backupDir, DAY };
