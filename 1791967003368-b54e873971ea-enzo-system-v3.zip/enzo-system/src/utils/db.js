// تخزين محلي بالكامل: ملف JSON داخل مجلد data بدون أي قاعدة بيانات خارجية
const fs = require('fs');
const path = require('path');

const dir = path.join(__dirname, '..', '..', 'data');
const file = path.join(dir, 'database.json');

const guildDefaults = () => ({
    prefix: null,
    logs: null,
    suggestions: null,
    warnCounter: 0,
    warns: {},
    welcome: { channel: null, leave: null, message: 'اهلا بك {user} في {server} ، انت العضو رقم {count}', autoRole: null },
    protection: {
        links: false,
        invites: false,
        spam: false,
        mentions: false,
        badwords: false,
        raid: false,
        words: [],
        users: [],
        roles: [],
        action: 'delete'
    },
    logChannels: {},
    levels: { enabled: true, channel: null, xpMin: 15, xpMax: 25, voiceEnabled: false, voiceMin: 5, voiceMax: 10 },
    bank: { daily: 1440, work: 60, crime: 120, rob: 60 },
    aliases: {},
    customCmds: [],
    forms: { logChannel: null, role: null, title: 'نموذج التقديم', description: 'اضغط على الزر بالأسفل للتقديم.', color: '#5865F2', questions: [] },
    captcha: { enabled: false, unverified: null, verified: null, title: 'التحقق من السيرفر', description: 'للوصول لبقية السيرفر اضغط الزر وحل التحقق.', button: 'تحقق' },
    tickets: { category: null, role: null, logs: null, counter: 0, open: {} },
    tempVoice: { creator: null, rooms: {} },
    autoReply: [],
    autoLine: { channels: [], image: null },
    automation: {
        tax: [],
        taxLine: null,
        images: [],
        youtube: [],
        react: {},
        feelings: { channel: null, anonymous: false },
        boost: { channel: null, message: 'شكراً {user} على البوست 💜', embed: false }
    },
    shop: [],
    levelRoles: {}
});

const userDefaults = () => ({
    cash: 0,
    bank: 0,
    xp: 0,
    level: 0,
    messages: 0,
    voice: 0,
    rep: 0,
    inventory: [],
    cd: {}
});

const metaDefaults = () => ({
    backup: { channelId: null, enabled: true, last: 0, lastSize: 0, lastError: null },
    reminders: [],
    status: { names: null, type: 'Playing', presence: 'online' }
});

const emptyStore = () => ({ guilds: {}, users: {}, meta: {} });

const read = p => JSON.parse(fs.readFileSync(p, 'utf8'));

const load = () => {
    fs.mkdirSync(dir, { recursive: true });
    for (const candidate of [file, file + '.bak']) {
        if (!fs.existsSync(candidate)) continue;
        try {
            return Object.assign(emptyStore(), read(candidate));
        } catch {
            try { fs.renameSync(candidate, path.join(dir, `database.corrupt-${Date.now()}.json`)); } catch {}
        }
    }
    return emptyStore();
};

let store = load();
let filled = new WeakSet();

const isObj = v => v && typeof v === 'object' && !Array.isArray(v);

const fill = (target, defaults) => {
    for (const key of Object.keys(defaults)) {
        if (target[key] === undefined) target[key] = structuredClone(defaults[key]);
        else if (isObj(defaults[key]) && isObj(target[key])) fill(target[key], defaults[key]);
    }
    return target;
};

// نكمل القيم الافتراضية مرة وحدة لكل كائن بدل كل استدعاء (أسرع بكثير مع كل رسالة)
const ensure = (obj, defaults) => {
    if (!filled.has(obj)) {
        fill(obj, defaults());
        filled.add(obj);
    }
    return obj;
};

let timer = null;
let lastBak = 0;

const flush = () => {
    if (timer) clearTimeout(timer);
    timer = null;
    try {
        fs.mkdirSync(dir, { recursive: true });
        const tmp = file + '.tmp';
        fs.writeFileSync(tmp, JSON.stringify(store));
        if (fs.existsSync(file) && Date.now() - lastBak > 10 * 60000) {
            fs.copyFileSync(file, file + '.bak');
            lastBak = Date.now();
        }
        fs.renameSync(tmp, file);
    } catch (e) {
        console.error('فشل حفظ البيانات', e.message);
    }
};

const save = () => {
    if (timer) return;
    timer = setTimeout(flush, 2000);
};

const guild = id => {
    if (!store.guilds[id]) store.guilds[id] = {};
    return ensure(store.guilds[id], guildDefaults);
};

const user = (guildId, userId) => {
    if (!store.users[guildId]) store.users[guildId] = {};
    if (!store.users[guildId][userId]) store.users[guildId][userId] = {};
    return ensure(store.users[guildId][userId], userDefaults);
};

const users = guildId => store.users[guildId] || {};

const meta = () => {
    if (!isObj(store.meta)) store.meta = {};
    return ensure(store.meta, metaDefaults);
};

// نسخة كاملة من البيانات (للنسخ الاحتياطي)
const snapshot = () => structuredClone(store);

// استبدال كل البيانات (للاستعادة من نسخة احتياطية)
const replaceAll = data => {
    if (!isObj(data) || !isObj(data.guilds) || !isObj(data.users)) throw new Error('ملف النسخة الاحتياطية غير صالح');
    store = Object.assign(emptyStore(), data);
    filled = new WeakSet();
    flush();
};

process.on('exit', flush);
process.on('SIGINT', () => { flush(); process.exit(0); });
process.on('SIGTERM', () => { flush(); process.exit(0); });

const guildCount = () => Object.keys(store.guilds).length;

module.exports = { guild, user, users, meta, save, flush, snapshot, replaceAll, guildCount, file, dir };
