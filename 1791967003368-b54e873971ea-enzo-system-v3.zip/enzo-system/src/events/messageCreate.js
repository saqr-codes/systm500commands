const db = require('../utils/db');
const e = require('../utils/embeds');
const xp = require('../utils/xp');
const automod = require('../core/automod');
const automation = require('../core/automation');
const handler = require('../core/handler');

module.exports = {
    name: 'messageCreate',
    async run(client, message) {
        if (!message.guild) return;
        if (await automation.boost(message)) return;
        if (message.author.bot || !message.member) return;

        if (await automod.message(message)) return;
        if (await handler.execute(client, message)) return;
        if (await automation.message(message)) return;

        const g = db.guild(message.guild.id);
        const text = message.content.trim().toLowerCase();

        const reply = g.autoReply.find(x => x.trigger === text);
        if (reply) message.reply({ content: reply.response, allowedMentions: { parse: [], repliedUser: false } }).catch(() => {});

        if (g.autoLine.channels.includes(message.channel.id) && g.autoLine.image) {
            message.channel.send({ embeds: [e.base(e.colors.dark).setImage(g.autoLine.image).setFooter(null).setTimestamp(null)] }).catch(() => {});
        }

        xp.give(message);
    }
};
