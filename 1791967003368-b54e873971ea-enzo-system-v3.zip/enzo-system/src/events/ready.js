const { Events } = require('discord.js');
const voice = require('../core/voice');

module.exports = {
    name: Events.ClientReady,
    once: true,
    run(client) {
        console.log(`تم تسجيل الدخول باسم ${client.user.tag}`);
        console.log(`الأوامر المحملة: ${client.categories ? [...client.categories.values()].reduce((a, c) => a + c.commands.length, 0) : 0}`);

        require('../utils/presence').apply(client);

        voice.seed(client);
        require('../utils/reminders').start(client);
    }
};
