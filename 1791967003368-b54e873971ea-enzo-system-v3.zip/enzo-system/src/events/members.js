const db = require('../utils/db');
const e = require('../utils/embeds');
const log = require('../utils/log');
const t = require('../utils/time');
const automod = require('../core/automod');
const welcome = require('../core/welcome');

module.exports = [
    {
        name: 'guildMemberAdd',
        async run(client, member) {
            if (await automod.raid(member)) return;
            const g = db.guild(member.guild.id);

            if (g.welcome.autoRole && !member.user.bot) member.roles.add(g.welcome.autoRole).catch(() => {});
            if (g.captcha.enabled && g.captcha.unverified && !member.user.bot) member.roles.add(g.captcha.unverified).catch(() => {});

            const channel = g.welcome.channel && member.guild.channels.cache.get(g.welcome.channel);
            if (channel) channel.send({ content: `${member}`, embeds: [welcome.joinEmbed(member)], allowedMentions: { users: [member.id] } }).catch(() => {});

            log.action(member.guild, '📥 دخول عضو', e.colors.ok, [
                { name: '👤 العضو', value: `${member}\n\`${member.id}\``, inline: true },
                { name: '📅 عمر الحساب', value: t.stamp(member.user.createdAt, 'R'), inline: true }
            ], 'join');
        }
    },
    {
        name: 'guildMemberRemove',
        run(client, member) {
            const g = db.guild(member.guild.id);
            const channel = g.welcome.leave && member.guild.channels.cache.get(g.welcome.leave);
            if (channel) channel.send({ embeds: [welcome.leaveEmbed(member)], ...e.opts }).catch(() => {});

            log.action(member.guild, '📤 خروج عضو', e.colors.err, [
                { name: '👤 العضو', value: `${member.user.tag}\n\`${member.id}\``, inline: true }
            ], 'leave');
        }
    }
];
