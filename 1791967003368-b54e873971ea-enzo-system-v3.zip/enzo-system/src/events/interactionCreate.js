const e = require('../utils/embeds');
const db = require('../utils/db');
const tickets = require('../core/tickets');
const { PermissionFlagsBits: P, MessageFlags } = require('discord.js');

const staff = interaction => {
    const g = db.guild(interaction.guild.id);
    return interaction.member.permissions.has(P.ManageMessages) || (g.tickets.role && interaction.member.roles.cache.has(g.tickets.role));
};

module.exports = {
    name: 'interactionCreate',
    async run(client, interaction) {
        if (!interaction.guild) return;

        try {
            if (await require('../core/slash').handle(client, interaction)) return;
            if (await require('../core/forms').handle(interaction)) return;
            if (await require('../core/captcha').handle(interaction)) return;
            if (await require('../ext/interactions')(client, interaction)) return;

            if (interaction.isButton()) {
                if (interaction.customId === 'tk:open') return interaction.showModal(tickets.modal());

                if (interaction.customId === 'tk:claim') {
                    if (!staff(interaction)) return interaction.reply({ embeds: [e.err('هذا الزر لفريق الإدارة فقط.')], flags: MessageFlags.Ephemeral });
                    const done = await tickets.claim(interaction.channel, interaction.member);
                    if (!done) return interaction.reply({ embeds: [e.err('هذي مو تذكرة.')], flags: MessageFlags.Ephemeral });
                    await interaction.update({ components: [tickets.controlRow(true)] });
                    return interaction.channel.send({ embeds: [e.ok(`${interaction.member} استلم التذكرة ✋`)], ...e.opts });
                }

                if (interaction.customId === 'tk:close') {
                    const ticket = db.guild(interaction.guild.id).tickets.open[interaction.channel.id];
                    if (!ticket) return interaction.reply({ embeds: [e.err('هذي مو تذكرة.')], flags: MessageFlags.Ephemeral });
                    if (!staff(interaction) && ticket.owner !== interaction.user.id) {
                        return interaction.reply({ embeds: [e.err('ما عندك صلاحية إغلاق هذي التذكرة.')], flags: MessageFlags.Ephemeral });
                    }
                    await interaction.deferUpdate();
                    return tickets.close(interaction.channel, interaction.user, payload => interaction.channel.send(payload));
                }
            }

            if (interaction.isModalSubmit() && interaction.customId === 'tk:modal') {
                return tickets.open(interaction, interaction.fields.getTextInputValue('reason'));
            }
        } catch (error) {
            console.error('خطأ في التفاعل:', error);
            const payload = { embeds: [e.err('صار خطأ غير متوقع.')], flags: MessageFlags.Ephemeral };
            if (interaction.replied || interaction.deferred) interaction.followUp(payload).catch(() => {});
            else interaction.reply(payload).catch(() => {});
        }
    }
};
