const e = require('../utils/embeds');
const log = require('../utils/log');
const voice = require('../core/voice');

module.exports = {
    name: 'voiceStateUpdate',
    async run(client, oldState, newState) {
        const member = newState.member || oldState.member;
        if (!member || member.user.bot) return;

        const guildId = newState.guild.id;
        const before = oldState.channelId;
        const after = newState.channelId;

        if (!before && after) voice.begin(guildId, member.id);
        if (before && !after) voice.end(guildId, member.id);

        if (before !== after) {
            await voice.temp(oldState, newState).catch(error => console.error('خطأ في الرومات المؤقتة:', error.message));

            let title = '🎙️ دخول روم صوتي';
            let color = e.colors.ok;
            let text = `${member} دخل ${newState.channel}`;
            if (before && !after) {
                title = '🔇 خروج من روم صوتي';
                color = e.colors.err;
                text = `${member} خرج من ${oldState.channel}`;
            } else if (before && after) {
                title = '🔀 انتقال بين الرومات';
                color = e.colors.info;
                text = `${member} انتقل من ${oldState.channel} إلى ${newState.channel}`;
            }
            log.send(newState.guild, e.base(color).setTitle(title).setDescription(text), 'voice');
        }
    }
};
