const e = require('../utils/embeds');
const log = require('../utils/log');

const clip = (text, n = 900) => (text && text.length ? text.slice(0, n) : '-');

module.exports = [
    {
        name: 'messageDelete',
        run(client, message) {
            if (!message.guild || message.author?.bot) return;
            const fields = [
                { name: '👤 الكاتب', value: message.author ? `${message.author}\n\`${message.author.id}\`` : 'غير معروف', inline: true },
                { name: '📺 الروم', value: `${message.channel}`, inline: true },
                { name: '💬 المحتوى', value: clip(message.content), inline: false }
            ];
            if (message.attachments?.size) fields.push({ name: '📎 مرفقات', value: `${message.attachments.size}`, inline: true });
            log.action(message.guild, '🗑️ رسالة محذوفة', e.colors.err, fields, 'messageDelete');
        }
    },
    {
        name: 'messageUpdate',
        run(client, before, after) {
            if (!after.guild || after.author?.bot || before.content === after.content) return;
            log.action(after.guild, '✏️ رسالة معدلة', e.colors.warn, [
                { name: '👤 الكاتب', value: `${after.author}\n\`${after.author?.id}\``, inline: true },
                { name: '📺 الروم', value: `${after.channel}\n[الذهاب للرسالة](${after.url})`, inline: true },
                { name: '⬅️ قبل', value: clip(before.content), inline: false },
                { name: '➡️ بعد', value: clip(after.content), inline: false }
            ], 'messageEdit');
        }
    },
    {
        name: 'guildBanAdd',
        run(client, ban) {
            log.action(ban.guild, '🔨 عضو محظور', e.colors.err, [
                { name: '👤 العضو', value: `${ban.user.tag}\n\`${ban.user.id}\``, inline: true },
                { name: '📝 السبب', value: clip(ban.reason, 300), inline: true }
            ], 'ban');
        }
    },
    {
        name: 'guildBanRemove',
        run(client, ban) {
            log.action(ban.guild, '♻️ فك حظر', e.colors.ok, [
                { name: '👤 العضو', value: `${ban.user.tag}\n\`${ban.user.id}\``, inline: true }
            ], 'unban');
        }
    },
    {
        name: 'channelCreate',
        run(client, channel) {
            if (!channel.guild) return;
            log.action(channel.guild, '📗 إنشاء روم', e.colors.ok, [
                { name: '📺 الروم', value: `${channel}\n\`${channel.name}\``, inline: true }
            ], 'channelCreate');
        }
    },
    {
        name: 'channelDelete',
        run(client, channel) {
            if (!channel.guild) return;
            log.action(channel.guild, '📕 حذف روم', e.colors.err, [
                { name: '📺 الروم', value: `\`${channel.name}\``, inline: true }
            ], 'channelDelete');
        }
    },
    {
        name: 'roleCreate',
        run(client, role) {
            log.action(role.guild, '🎭 إنشاء رتبة', e.colors.ok, [
                { name: '🎭 الرتبة', value: `${role}\n\`${role.name}\``, inline: true }
            ], 'roleCreate');
        }
    },
    {
        name: 'roleDelete',
        run(client, role) {
            log.action(role.guild, '🎭 حذف رتبة', e.colors.err, [
                { name: '🎭 الرتبة', value: `\`${role.name}\``, inline: true }
            ], 'roleDelete');
        }
    },
    {
        name: 'guildMemberUpdate',
        run(client, before, after) {
            const added = after.roles.cache.filter(r => !before.roles.cache.has(r.id));
            const removed = before.roles.cache.filter(r => !after.roles.cache.has(r.id));
            if (added.size || removed.size) {
                const fields = [{ name: '👤 العضو', value: `${after}\n\`${after.id}\``, inline: true }];
                if (added.size) fields.push({ name: '➕ رتب أضيفت', value: added.map(r => `${r}`).join(' '), inline: false });
                if (removed.size) fields.push({ name: '➖ رتب سحبت', value: removed.map(r => `${r}`).join(' '), inline: false });
                log.action(after.guild, '🎭 تحديث رتب عضو', e.colors.info, fields, 'memberRoles');
            }
            if (before.nickname !== after.nickname) {
                log.action(after.guild, '🏷️ تغيير لقب', e.colors.info, [
                    { name: '👤 العضو', value: `${after}`, inline: true },
                    { name: '⬅️ قبل', value: before.nickname || 'بدون', inline: true },
                    { name: '➡️ بعد', value: after.nickname || 'بدون', inline: true }
                ], 'nick');
            }
        }
    }
];
