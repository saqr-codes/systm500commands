// أقسام الداشبورد المنقولة من لوحة E-246 القديمة، كلها تعمل داخل ديسكورد
const { EmbedBuilder, StringSelectMenuBuilder, ButtonStyle } = require('discord.js');
const config = require('../../config');
const db = require('../utils/db');
const extDb = require('../ext/database/db');
const e = require('../utils/embeds');
const t = require('../utils/time');
const log = require('../utils/log');
const presence = require('../utils/presence');
const forms = require('../core/forms');
const captcha = require('../core/captcha');
const { norm } = require('../utils/text');
const { eph, TEXT, clip, ch, role, row, btn, ask, fail, findRole, channelPicker, rolePicker } = require('./kit');

const colorInt = hex => {
    const v = parseInt(String(hex || '').replace('#', ''), 16);
    return Number.isNaN(v) || v > 0xffffff ? 0x5865f2 : v;
};
const isHex = s => /^#?[0-9a-f]{6}$/i.test(String(s || '').trim());
const isUrl = s => /^https?:\/\/\S+$/i.test(String(s || '').trim());
const unicodeOrCustom = s => /^(<a?:\w+:\d{15,20}>|\p{Extended_Pictographic}[\p{Extended_Pictographic}\u200d\ufe0f\u{1F3FB}-\u{1F3FF}]*)$/u.test(s);

const sections = {
    // ═══ سجلات مفصلة ═══
    logs: {
        embed({ guild }) {
            const g = db.guild(guild.id);
            const lines = log.events.map(([k, label]) => `${label}: ${g.logChannels[k] ? ch(g.logChannels[k]) : '↩️ العام'}`).join('\n');
            return e.base().setTitle('📜 السجلات المفصلة').setDescription(`${lines}\n\n↩️ العام = روم السجلات الرئيسي: ${ch(g.logs)}`)
                .setFooter({ text: 'اختر نوع السجل ثم الروم (إلغاء الاختيار يرجعه للروم العام)' });
        },
        components({ guild }, state) {
            const g = db.guild(guild.id);
            const key = state.logKey || log.events[0][0];
            const menu = new StringSelectMenuBuilder().setCustomId('dash:log:key').setPlaceholder('اختر نوع السجل')
                .addOptions(log.events.map(([k, label]) => ({ label: label.replace(/^\S+\s/, ''), value: k, emoji: label.split(' ')[0], default: k === key })));
            return [row(menu), channelPicker('dash:log:value', 'اختر الروم', TEXT, g.logChannels[key], { guild })];
        },
        async handle(i, ctx, state, redraw) {
            if (i.customId === 'dash:log:key') { state.logKey = i.values[0]; return redraw(i); }
            if (i.customId === 'dash:log:value') {
                const g = db.guild(ctx.guild.id);
                const key = state.logKey || log.events[0][0];
                if (i.values[0]) g.logChannels[key] = i.values[0]; else delete g.logChannels[key];
                db.save();
                return redraw(i);
            }
        }
    },

    // ═══ منشئ الامبد ═══
    embed: {
        draft: state => (state.draft ||= { title: '', description: '', color: '#5865F2', image: '', thumbnail: '', footer: '' }),
        preview(d) {
            const em = new EmbedBuilder().setColor(colorInt(d.color));
            if (d.title) em.setTitle(d.title);
            em.setDescription(d.description || (d.title ? null : '_المعاينة فاضية، اضغط تعديل المحتوى_'));
            if (d.image) em.setImage(d.image);
            if (d.thumbnail) em.setThumbnail(d.thumbnail);
            if (d.footer) em.setFooter({ text: d.footer });
            return em;
        },
        embed(ctx, state) {
            const target = state.embedChannel || ctx.message.channel.id;
            return [
                e.info('🧱 منشئ الامبد', `الروم المستهدف: ${ch(target)}\nعدّل المحتوى ثم اضغط **إرسال** (المعاينة بالأسفل).`),
                this.preview(this.draft(state))
            ];
        },
        components(ctx, state) {
            return [
                channelPicker('dash:emb:channel', 'اختر روم الإرسال (الافتراضي هذا الروم)', TEXT, state.embedChannel || ctx.message.channel.id, { guild: ctx.guild }),
                row(
                    btn('dash:emb:edit', 'تعديل المحتوى', '✏️'),
                    btn('dash:emb:media', 'الصور والفوتر', '🖼️'),
                    btn('dash:emb:send', 'إرسال', '📤', ButtonStyle.Success),
                    btn('dash:emb:reset', 'تصفير', '🗑️', ButtonStyle.Danger)
                )
            ];
        },
        async handle(i, ctx, state, redraw) {
            const d = this.draft(state);
            if (i.customId === 'dash:emb:channel') { state.embedChannel = i.values[0] || null; return redraw(i); }
            if (i.customId === 'dash:emb:reset') { state.draft = null; return redraw(i); }
            if (i.customId === 'dash:emb:edit') {
                const s = await ask(i, 'محتوى الامبد', [
                    { id: 'title', label: 'العنوان', required: false, max: 256, value: d.title },
                    { id: 'description', label: 'الوصف', long: true, required: false, max: 3000, value: d.description },
                    { id: 'color', label: 'اللون (مثل #5865F2)', required: false, max: 7, value: d.color }
                ]);
                if (!s) return;
                const color = s.fields.getTextInputValue('color').trim() || '#5865F2';
                if (!isHex(color)) return fail(s, 'اللون لازم يكون بصيغة #RRGGBB.');
                d.title = s.fields.getTextInputValue('title').trim();
                d.description = s.fields.getTextInputValue('description').trim();
                d.color = color.startsWith('#') ? color : `#${color}`;
                return redraw(null);
            }
            if (i.customId === 'dash:emb:media') {
                const s = await ask(i, 'الصور والفوتر', [
                    { id: 'image', label: 'رابط الصورة الكبيرة', required: false, max: 500, value: d.image },
                    { id: 'thumbnail', label: 'رابط الصورة الصغيرة', required: false, max: 500, value: d.thumbnail },
                    { id: 'footer', label: 'نص الفوتر', required: false, max: 200, value: d.footer }
                ]);
                if (!s) return;
                const image = s.fields.getTextInputValue('image').trim();
                const thumbnail = s.fields.getTextInputValue('thumbnail').trim();
                if ((image && !isUrl(image)) || (thumbnail && !isUrl(thumbnail))) return fail(s, 'الروابط لازم تبدأ بـ http.');
                d.image = image;
                d.thumbnail = thumbnail;
                d.footer = s.fields.getTextInputValue('footer').trim();
                return redraw(null);
            }
            if (i.customId === 'dash:emb:send') {
                if (!d.title && !d.description && !d.image) return i.reply({ embeds: [e.err('الامبد فاضي، عدّل المحتوى أول.')], ...eph });
                const channel = ctx.guild.channels.cache.get(state.embedChannel || ctx.message.channel.id);
                const sent = channel ? await channel.send({ embeds: [this.preview(d)] }).then(() => true).catch(() => false) : false;
                return i.reply({ embeds: [sent ? e.ok(`تم إرسال الامبد إلى ${channel}`) : e.err('ما قدرت أرسل في هذا الروم، تأكد من صلاحياتي.')], ...eph });
            }
        }
    },

    // ═══ الرسائل المثبتة ═══
    sticky: {
        embed({ guild }) {
            const list = extDb.listSticky(guild.id);
            const text = list.length ? clip(list.map(s => `${ch(s.channelId)} ← ${clip(s.content, 70)}`).join('\n'), 3800) : 'ما فيه رسائل مثبتة.';
            return e.base().setTitle(`📌 الرسائل المثبتة (${list.length})`).setDescription(text)
                .setFooter({ text: 'الرسالة المثبتة تنعاد للأسفل تلقائياً بعد كل رسالة جديدة في الروم' });
        },
        components({ guild }, state) {
            return [
                channelPicker('dash:stk:channel', 'اختر الروم', TEXT, state.stickyChannel, { guild }),
                row(btn('dash:stk:set', 'تثبيت رسالة في الروم المحدد', '📌', ButtonStyle.Primary), btn('dash:stk:del', 'إزالة من الروم المحدد', '🗑️', ButtonStyle.Danger))
            ];
        },
        async handle(i, ctx, state, redraw) {
            if (i.customId === 'dash:stk:channel') { state.stickyChannel = i.values[0] || null; return redraw(i); }
            const channel = state.stickyChannel && ctx.guild.channels.cache.get(state.stickyChannel);
            if (!channel) return i.reply({ embeds: [e.err('اختر الروم أول من القائمة.')], ...eph });
            if (i.customId === 'dash:stk:set') {
                const cur = extDb.getStickyMessage(channel.id);
                const s = await ask(i, 'الرسالة المثبتة', [{ id: 'text', label: 'النص', long: true, max: 1800, value: cur?.content }]);
                if (!s) return;
                const content = s.fields.getTextInputValue('text').trim();
                if (!content) return fail(s, 'اكتب النص.');
                if (cur?.lastMessageId) await (await channel.messages.fetch(cur.lastMessageId).catch(() => null))?.delete().catch(() => {});
                extDb.setStickyMessage(ctx.guild.id, channel.id, content);
                const sent = await channel.send({ content: `__**رسالة مثبتة**__\n\n${content}` }).catch(() => null);
                if (sent) extDb.updateStickyMessageId(channel.id, sent.id);
                else await s.followUp({ embeds: [e.err('ما قدرت أرسل في الروم، تأكد من صلاحياتي.')], ...eph }).catch(() => {});
                return redraw(null);
            }
            if (i.customId === 'dash:stk:del') {
                const cur = extDb.getStickyMessage(channel.id);
                if (!cur) return i.reply({ embeds: [e.err('ما فيه رسالة مثبتة في هذا الروم.')], ...eph });
                if (cur.lastMessageId) await (await channel.messages.fetch(cur.lastMessageId).catch(() => null))?.delete().catch(() => {});
                extDb.removeStickyMessage(channel.id);
                return redraw(i);
            }
        }
    },

    // ═══ رتب التفاعل ═══
    reactroles: {
        embed({ guild }) {
            const list = extDb.listReactRoles(guild.id);
            const text = list.length ? clip(list.map((r, n) => `**${n + 1}.** رسالة \`${r.messageId}\` • ${/^\d+$/.test(r.emoji) ? `<:e:${r.emoji}>` : r.emoji} ← ${role(r.roleId)}`).join('\n'), 3800) : 'ما فيه رتب تفاعل.';
            return e.base().setTitle(`🎭 رتب التفاعل (${list.length})`).setDescription(text);
        },
        components({ guild }, state) {
            const list = extDb.listReactRoles(guild.id).slice(0, 25);
            const rows = [channelPicker('dash:rr:channel', 'روم الرسالة (اختره قبل الإضافة)', TEXT, state.rrChannel, { guild })];
            if (list.length) {
                rows.push(row(new StringSelectMenuBuilder().setCustomId('dash:rr:remove').setPlaceholder('🗑️ اختر رتبة تفاعل لحذفها')
                    .addOptions(list.map((r, n) => ({ label: `${n + 1}. ${guild.roles.cache.get(r.roleId)?.name || 'رتبة محذوفة'}`.slice(0, 100), description: `رسالة ${r.messageId}`, value: String(n) })))));
            }
            rows.push(row(btn('dash:rr:add', 'إضافة رتبة تفاعل', '➕', ButtonStyle.Primary)));
            return rows;
        },
        async handle(i, ctx, state, redraw) {
            if (i.customId === 'dash:rr:channel') { state.rrChannel = i.values[0] || null; return redraw(i); }
            if (i.customId === 'dash:rr:remove') {
                const r = extDb.listReactRoles(ctx.guild.id)[Number(i.values[0])];
                if (r) extDb.removeReactRole(r.messageId, r.emoji);
                return redraw(i);
            }
            if (i.customId === 'dash:rr:add') {
                const channel = state.rrChannel && ctx.guild.channels.cache.get(state.rrChannel);
                if (!channel) return i.reply({ embeds: [e.err('اختر روم الرسالة أول من القائمة.')], ...eph });
                const s = await ask(i, 'إضافة رتبة تفاعل', [
                    { id: 'message', label: 'ايدي الرسالة', max: 20 },
                    { id: 'emoji', label: 'الايموجي', max: 60 },
                    { id: 'role', label: 'ايدي أو اسم الرتبة', max: 100 }
                ]);
                if (!s) return;
                const messageId = s.fields.getTextInputValue('message').trim();
                const emoji = s.fields.getTextInputValue('emoji').trim();
                const picked = findRole(ctx.guild, s.fields.getTextInputValue('role'));
                if (!/^\d{15,20}$/.test(messageId) || !unicodeOrCustom(emoji)) return fail(s, 'اكتب ايدي رسالة صحيح وايموجي صحيح.');
                if (!picked || picked.managed || picked.position >= ctx.guild.members.me.roles.highest.position) return fail(s, 'الرتبة غير موجودة أو أعلى من رتبة البوت.');
                const message = await channel.messages.fetch(messageId).catch(() => null);
                if (!message) return fail(s, 'ما لقيت الرسالة في الروم المحدد.');
                await message.react(emoji).catch(() => {});
                const key = emoji.startsWith('<') ? emoji.replace(/>$/, '').split(':').pop() : emoji;
                extDb.addReactRole(messageId, ctx.guild.id, key, picked.id);
                return redraw(null);
            }
        }
    },

    // ═══ نماذج التقديم ═══
    forms: {
        embed({ guild }) {
            const f = db.guild(guild.id).forms;
            return e.base(colorInt(f.color)).setTitle('📝 نموذج التقديم').addFields(
                { name: '✏️ العنوان', value: clip(f.title, 200), inline: true },
                { name: '📥 روم الاستقبال', value: ch(f.logChannel), inline: true },
                { name: '🎭 رتبة القبول', value: role(f.role), inline: true },
                { name: '📃 الوصف', value: clip(f.description, 500), inline: false },
                { name: `❓ الأسئلة (${f.questions.length}/5)`, value: f.questions.length ? f.questions.map((q, n) => `**${n + 1}.** ${clip(q, 100)}`).join('\n') : 'لا يوجد أسئلة', inline: false }
            );
        },
        components({ guild }) {
            const f = db.guild(guild.id).forms;
            return [
                channelPicker('dash:frm:log', '📥 روم استقبال التقديمات', TEXT, f.logChannel, { guild }),
                rolePicker('dash:frm:role', '🎭 رتبة تنعطى عند القبول (اختياري)', f.role, { guild }),
                row(btn('dash:frm:text', 'العنوان والوصف', '✏️'), btn('dash:frm:q', 'الأسئلة', '❓'), btn('dash:frm:panel', 'إرسال اللوحة هنا', '📨', ButtonStyle.Primary))
            ];
        },
        async handle(i, ctx, state, redraw) {
            const f = db.guild(ctx.guild.id).forms;
            if (i.customId === 'dash:frm:log') { f.logChannel = i.values[0] || null; db.save(); return redraw(i); }
            if (i.customId === 'dash:frm:role') { f.role = i.values[0] || null; db.save(); return redraw(i); }
            if (i.customId === 'dash:frm:text') {
                const s = await ask(i, 'عنوان ووصف النموذج', [
                    { id: 'title', label: 'العنوان', max: 100, value: f.title },
                    { id: 'description', label: 'الوصف', long: true, max: 1000, value: f.description },
                    { id: 'color', label: 'اللون #RRGGBB', max: 7, value: f.color }
                ]);
                if (!s) return;
                const color = s.fields.getTextInputValue('color').trim();
                if (!isHex(color)) return fail(s, 'اللون لازم يكون بصيغة #RRGGBB.');
                f.title = s.fields.getTextInputValue('title').trim() || f.title;
                f.description = s.fields.getTextInputValue('description').trim() || f.description;
                f.color = color.startsWith('#') ? color : `#${color}`;
                db.save();
                return redraw(null);
            }
            if (i.customId === 'dash:frm:q') {
                const s = await ask(i, 'أسئلة النموذج', [{ id: 'q', label: 'كل سؤال في سطر (حتى 5)', long: true, max: 900, value: f.questions.join('\n') }]);
                if (!s) return;
                f.questions = s.fields.getTextInputValue('q').split('\n').map(x => x.trim().slice(0, 45)).filter(Boolean).slice(0, 5);
                db.save();
                return redraw(null);
            }
            if (i.customId === 'dash:frm:panel') {
                if (!f.questions.length || !f.logChannel) return i.reply({ embeds: [e.err('أضف أسئلة وحدد روم الاستقبال أول.')], ...eph });
                await ctx.message.channel.send(forms.panel(ctx.guild)).catch(() => null);
                return i.reply({ embeds: [e.ok(`تم إرسال لوحة التقديم في ${ctx.message.channel}`)], ...eph });
            }
        }
    },

    // ═══ التحقق ═══
    captcha: {
        embed({ guild }) {
            const c = db.guild(guild.id).captcha;
            return e.base(c.enabled ? e.colors.ok : e.colors.warn).setTitle('🔐 نظام التحقق').addFields(
                { name: 'الحالة', value: c.enabled ? '🟢 مفعل' : '🔴 متوقف', inline: true },
                { name: '🎭 رتبة غير الموثق', value: role(c.unverified), inline: true },
                { name: '✅ رتبة الموثق', value: role(c.verified), inline: true },
                { name: '✏️ لوحة التحقق', value: `**${clip(c.title, 100)}**\n${clip(c.description, 300)}\nالزر: ${c.button}`, inline: false }
            ).setFooter({ text: 'الأعضاء الجدد ياخذون رتبة غير الموثق، وبعد حل الكود ياخذون رتبة الموثق' });
        },
        components({ guild }) {
            const c = db.guild(guild.id).captcha;
            return [
                rolePicker('dash:cap:unv', '🎭 رتبة غير الموثق (تنسحب بعد التحقق)', c.unverified, { guild }),
                rolePicker('dash:cap:ver', '✅ رتبة الموثق', c.verified, { guild }),
                row(
                    btn('dash:cap:toggle', c.enabled ? 'إيقاف' : 'تفعيل', '🔁'),
                    btn('dash:cap:text', 'نص اللوحة', '✏️'),
                    btn('dash:cap:panel', 'إرسال اللوحة هنا', '📨', ButtonStyle.Primary)
                )
            ];
        },
        async handle(i, ctx, state, redraw) {
            const c = db.guild(ctx.guild.id).captcha;
            const check = id => {
                const r = ctx.guild.roles.cache.get(id);
                return r && !r.managed && r.position < ctx.guild.members.me.roles.highest.position;
            };
            if (i.customId === 'dash:cap:unv' || i.customId === 'dash:cap:ver') {
                const id = i.values[0] || null;
                if (id && !check(id)) return i.reply({ embeds: [e.err('هذي الرتبة أعلى من رتبة البوت أو رتبة نظام.')], ...eph });
                if (i.customId === 'dash:cap:unv') c.unverified = id; else c.verified = id;
                db.save();
                return redraw(i);
            }
            if (i.customId === 'dash:cap:toggle') {
                if (!c.enabled && !c.verified) return i.reply({ embeds: [e.err('حدد رتبة الموثق أول.')], ...eph });
                c.enabled = !c.enabled;
                db.save();
                return redraw(i);
            }
            if (i.customId === 'dash:cap:text') {
                const s = await ask(i, 'نص لوحة التحقق', [
                    { id: 'title', label: 'العنوان', max: 100, value: c.title },
                    { id: 'description', label: 'الوصف', long: true, max: 600, value: c.description },
                    { id: 'button', label: 'نص الزر', max: 40, value: c.button }
                ]);
                if (!s) return;
                c.title = s.fields.getTextInputValue('title').trim() || c.title;
                c.description = s.fields.getTextInputValue('description').trim() || c.description;
                c.button = s.fields.getTextInputValue('button').trim() || c.button;
                db.save();
                return redraw(null);
            }
            if (i.customId === 'dash:cap:panel') {
                if (!c.verified) return i.reply({ embeds: [e.err('حدد رتبة الموثق أول.')], ...eph });
                await ctx.message.channel.send(captcha.panel(ctx.guild)).catch(() => null);
                return i.reply({ embeds: [e.ok(`تم إرسال لوحة التحقق في ${ctx.message.channel}`)], ...eph });
            }
        }
    },

    // ═══ الاختصارات والأوامر المخصصة ═══
    commands: {
        embed({ guild }) {
            const g = db.guild(guild.id);
            const aliases = Object.entries(g.aliases);
            return e.base().setTitle('🔀 الاختصارات والأوامر المخصصة').addFields(
                { name: `🔀 الاختصارات (${aliases.length})`, value: aliases.length ? clip(aliases.map(([s, c]) => `\`${s}\` ← \`${c}\``).join('\n'), 1000) : 'لا يوجد\nاختصار يشغّل أمر موجود باسم أقصر', inline: false },
                { name: `💬 الأوامر المخصصة (${g.customCmds.length})`, value: g.customCmds.length ? clip(g.customCmds.map(c => `\`${c.name}\` ← ${clip(c.response, 50)}`).join('\n'), 1000) : 'لا يوجد\nأمر يرد بنص تحدده ({user} {server})', inline: false }
            );
        },
        components({ guild }) {
            const g = db.guild(guild.id);
            const rows = [];
            const aliases = Object.keys(g.aliases).slice(0, 25);
            if (aliases.length) rows.push(row(new StringSelectMenuBuilder().setCustomId('dash:cmd:delalias').setPlaceholder('🗑️ حذف اختصار')
                .addOptions(aliases.map(s => ({ label: s.slice(0, 100), description: g.aliases[s].slice(0, 90), value: s })))));
            if (g.customCmds.length) rows.push(row(new StringSelectMenuBuilder().setCustomId('dash:cmd:delcustom').setPlaceholder('🗑️ حذف أمر مخصص')
                .addOptions(g.customCmds.slice(0, 25).map((c, n) => ({ label: c.name.slice(0, 100), description: clip(c.response, 90), value: String(n) })))));
            rows.push(row(btn('dash:cmd:alias', 'إضافة اختصار', '🔀', ButtonStyle.Primary), btn('dash:cmd:custom', 'إضافة أمر مخصص', '💬', ButtonStyle.Primary)));
            return rows;
        },
        async handle(i, ctx, state, redraw) {
            const g = db.guild(ctx.guild.id);
            if (i.customId === 'dash:cmd:delalias') { delete g.aliases[i.values[0]]; db.save(); return redraw(i); }
            if (i.customId === 'dash:cmd:delcustom') { g.customCmds.splice(Number(i.values[0]), 1); db.save(); return redraw(i); }
            if (i.customId === 'dash:cmd:alias') {
                const s = await ask(i, 'إضافة اختصار', [
                    { id: 'short', label: 'الاختصار (كلمة وحدة)', max: 30 },
                    { id: 'command', label: 'الأمر (مثل: حظر أو مسح 10)', max: 100 }
                ]);
                if (!s) return;
                const short = norm(s.fields.getTextInputValue('short').trim());
                const target = s.fields.getTextInputValue('command').trim().replace(/\s+/g, ' ');
                if (!short || /\s/.test(short)) return fail(s, 'الاختصار لازم يكون كلمة وحدة.');
                if (ctx.client.commands.has(short)) return fail(s, 'هذا الاسم محجوز لأمر موجود.');
                if (!ctx.client.commands.has(norm(target.split(' ')[0]))) return fail(s, 'الأمر الهدف غير موجود.');
                if (Object.keys(g.aliases).length >= 50) return fail(s, 'وصلت الحد الأقصى 50 اختصار.');
                g.aliases[short] = target;
                db.save();
                return redraw(null);
            }
            if (i.customId === 'dash:cmd:custom') {
                const s = await ask(i, 'إضافة أمر مخصص', [
                    { id: 'name', label: 'اسم الأمر (كلمة وحدة)', max: 30 },
                    { id: 'response', label: 'الرد ({user} {server})', long: true, max: 1500 }
                ]);
                if (!s) return;
                const name = s.fields.getTextInputValue('name').trim().toLowerCase();
                const response = s.fields.getTextInputValue('response').trim();
                if (!name || /\s/.test(name) || !response) return fail(s, 'اكتب اسم (كلمة وحدة) ورد.');
                if (ctx.client.commands.has(norm(name)) || g.aliases[norm(name)]) return fail(s, 'هذا الاسم محجوز لأمر أو اختصار.');
                if (g.customCmds.length >= 50) return fail(s, 'وصلت الحد الأقصى 50 أمر.');
                g.customCmds = g.customCmds.filter(c => norm(c.name) !== norm(name));
                g.customCmds.push({ name, response });
                db.save();
                return redraw(null);
            }
        }
    },

    // ═══ الإحصائيات والسجل ═══
    stats: {
        embed({ guild, client }) {
            const g = db.guild(guild.id);
            const users = Object.entries(db.users(guild.id));
            const top = (key, fmt) => {
                const list = users.filter(([, u]) => u[key] > 0).sort((a, b) => b[1][key] - a[1][key]).slice(0, 3);
                return list.length ? list.map(([id, u], n) => `${['🥇', '🥈', '🥉'][n]} <@${id}> • ${fmt(u[key])}`).join('\n') : 'لا يوجد';
            };
            const sum = key => users.reduce((a, [, u]) => a + (u[key] || 0), 0);
            const warns = Object.entries(g.warns).flatMap(([uid, list]) => list.map(w => ({ ...w, uid })))
                .sort((a, b) => b.at - a.at).slice(0, 4);
            const actions = extDb.listModActions(guild.id, 4);
            const history = [
                ...warns.map(w => `⚠️ <@${w.uid}> • ${clip(w.reason, 40)} • ${t.stamp(w.at)}`),
                ...actions.map(a => `⛓️ ${a.action} • <@${a.targetId}> • ${t.stamp(a.timestamp)}`)
            ];
            return e.base().setTitle('📊 الإحصائيات والسجل').addFields(
                { name: '👥 الأعضاء', value: t.num(guild.memberCount), inline: true },
                { name: '💬 مجموع الرسائل', value: t.num(sum('messages')), inline: true },
                { name: '🎙️ ساعات الصوت', value: t.num(Math.floor(sum('voice') / 3600)), inline: true },
                { name: '💰 مجموع الفلوس', value: t.num(sum('cash') + sum('bank')), inline: true },
                { name: '⚠️ التحذيرات', value: t.num(Object.values(g.warns).reduce((a, l) => a + l.length, 0)), inline: true },
                { name: '📡 البنق', value: `${client.ws.ping}ms`, inline: true },
                { name: '💬 أكثر رسائل', value: top('messages', n => `${t.num(n)}`), inline: true },
                { name: '🎙️ أكثر صوت', value: top('voice', n => `${Math.floor(n / 3600)}س`), inline: true },
                { name: '💰 الأغنى', value: top('cash', n => t.num(n)), inline: true },
                { name: '🗃️ آخر سجل إدارة', value: history.length ? clip(history.join('\n'), 1000) : 'لا يوجد', inline: false }
            );
        },
        components: () => [row(btn('dash:sta:refresh', 'تحديث', '🔄'), btn('dash:sta:clear', 'مسح سجل السجن', '🗑️', ButtonStyle.Danger))],
        async handle(i, ctx, state, redraw) {
            if (i.customId === 'dash:sta:refresh') return redraw(i);
            if (i.customId === 'dash:sta:clear') { extDb.clearModActions(ctx.guild.id); return redraw(i); }
        }
    },

    // ═══ إعدادات البوت (لمالك البوت) ═══
    botsettings: {
        embed({ client }) {
            const s = db.meta().status;
            const names = s.names && s.names.length ? s.names : config.status.names;
            return e.base().setTitle('🤖 إعدادات البوت').setThumbnail(client.user.displayAvatarURL({ size: 256 })).addFields(
                { name: '🏷️ الاسم', value: client.user.username, inline: true },
                { name: '📡 الحالة', value: s.presence, inline: true },
                { name: '🎮 نوع النشاط', value: s.type, inline: true },
                { name: '💬 نصوص النشاط (تتبدل كل 20 ثانية)', value: names.length ? names.map(n => `• ${n}`).join('\n') : 'بدون', inline: false }
            );
        },
        components() {
            const s = db.meta().status;
            const pres = new StringSelectMenuBuilder().setCustomId('dash:bot:presence').setPlaceholder('📡 حالة البوت')
                .addOptions([['online', '🟢 متصل'], ['idle', '🌙 خامل'], ['dnd', '⛔ مشغول'], ['invisible', '⚫ مخفي']]
                    .map(([v, l]) => ({ label: l.slice(2), value: v, emoji: l.slice(0, 2).trim(), default: s.presence === v })));
            const type = new StringSelectMenuBuilder().setCustomId('dash:bot:type').setPlaceholder('🎮 نوع النشاط')
                .addOptions(presence.types.map(v => ({ label: { Playing: 'يلعب', Watching: 'يشاهد', Listening: 'يستمع', Competing: 'يتنافس' }[v], value: v, default: s.type === v })));
            return [row(pres), row(type), row(btn('dash:bot:names', 'نصوص النشاط', '💬'), btn('dash:bot:name', 'اسم البوت', '🏷️'), btn('dash:bot:avatar', 'صورة البوت', '🖼️'))];
        },
        async handle(i, ctx, state, redraw) {
            const s = db.meta().status;
            if (i.customId === 'dash:bot:presence') { s.presence = i.values[0]; db.save(); presence.apply(ctx.client); return redraw(i); }
            if (i.customId === 'dash:bot:type') { s.type = i.values[0]; db.save(); presence.apply(ctx.client); return redraw(i); }
            if (i.customId === 'dash:bot:names') {
                const cur = s.names && s.names.length ? s.names : config.status.names;
                const sub = await ask(i, 'نصوص النشاط', [{ id: 'names', label: 'كل نص في سطر (فاضي = بدون)', long: true, required: false, max: 400, value: cur.join('\n') }]);
                if (!sub) return;
                s.names = sub.fields.getTextInputValue('names').split('\n').map(x => x.trim().slice(0, 100)).filter(Boolean).slice(0, 10);
                if (!s.names.length) s.names = [];
                db.save();
                presence.apply(ctx.client);
                return redraw(null);
            }
            if (i.customId === 'dash:bot:name') {
                const sub = await ask(i, 'اسم البوت', [{ id: 'name', label: 'الاسم الجديد', max: 32, value: ctx.client.user.username }]);
                if (!sub) return;
                const done = await ctx.client.user.setUsername(sub.fields.getTextInputValue('name').trim()).then(() => true).catch(() => false);
                if (!done) await fail(sub, 'ما قدرت أغير الاسم، ديسكورد يحدد عدد مرات التغيير.');
                return redraw(null);
            }
            if (i.customId === 'dash:bot:avatar') {
                const sub = await ask(i, 'صورة البوت', [{ id: 'url', label: 'رابط الصورة', max: 500 }]);
                if (!sub) return;
                const url = sub.fields.getTextInputValue('url').trim();
                if (!isUrl(url)) return fail(sub, 'اكتب رابط صحيح.');
                const done = await ctx.client.user.setAvatar(url).then(() => true).catch(() => false);
                if (!done) await fail(sub, 'ما قدرت أغير الصورة.');
                return redraw(null);
            }
        }
    }
};

const list = [
    { key: 'logs', label: 'السجلات المفصلة', emoji: '📜' },
    { key: 'embed', label: 'منشئ الامبد', emoji: '🧱' },
    { key: 'sticky', label: 'الرسائل المثبتة', emoji: '📌' },
    { key: 'reactroles', label: 'رتب التفاعل', emoji: '🎭' },
    { key: 'forms', label: 'نماذج التقديم', emoji: '📝' },
    { key: 'captcha', label: 'التحقق', emoji: '🔐' },
    { key: 'commands', label: 'الاختصارات والأوامر المخصصة', emoji: '🔀' },
    { key: 'stats', label: 'الإحصائيات والسجل', emoji: '📊' },
    { key: 'botsettings', label: 'إعدادات البوت', emoji: '🤖', ownerOnly: true }
];

module.exports = { sections, list };
