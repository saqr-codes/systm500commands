// أدوات مشتركة لأقسام الداشبورد
const {
    ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, ChannelSelectMenuBuilder,
    RoleSelectMenuBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ChannelType, MessageFlags
} = require('discord.js');
const e = require('../utils/embeds');

const eph = { flags: MessageFlags.Ephemeral };
const TEXT = [ChannelType.GuildText, ChannelType.GuildAnnouncement];
const VOICE = [ChannelType.GuildVoice, ChannelType.GuildStageVoice];
const CATEGORY = [ChannelType.GuildCategory];

const clip = (text, n = 1000) => (text.length > n ? `${text.slice(0, n - 1)}…` : text);
const ch = id => (id ? `<#${id}>` : '`غير محدد`');
const role = id => (id ? `<@&${id}>` : '`غير محدد`');
const onoff = v => (v ? '🟢' : '🔴');
const row = (...components) => new ActionRowBuilder().addComponents(...components);
const btn = (id, label, emoji, style = ButtonStyle.Secondary) =>
    new ButtonBuilder().setCustomId(id).setLabel(label).setEmoji(emoji).setStyle(style);

// ───────── أدوات التفاعل ─────────
const ask = async (i, title, fields) => {
    const id = `dash:modal:${i.id}`;
    const modal = new ModalBuilder().setCustomId(id).setTitle(title.slice(0, 45));
    for (const f of fields) {
        const input = new TextInputBuilder()
            .setCustomId(f.id)
            .setLabel(f.label.slice(0, 45))
            .setStyle(f.long ? TextInputStyle.Paragraph : TextInputStyle.Short)
            .setRequired(f.required !== false)
            .setMaxLength(f.max || 200);
        if (f.placeholder) input.setPlaceholder(f.placeholder.slice(0, 100));
        if (f.value) input.setValue(String(f.value).slice(0, f.max || 200));
        modal.addComponents(row(input));
    }
    await i.showModal(modal);
    const submit = await i.awaitModalSubmit({ time: 180000, filter: m => m.customId === id && m.user.id === i.user.id }).catch(() => null);
    if (submit) await submit.deferUpdate().catch(() => {});
    return submit;
};

const fail = (submit, text) => submit.followUp({ embeds: [e.err(text)], ...eph }).catch(() => {});

const findRole = (guild, arg) => {
    const q = String(arg || '').trim();
    const id = (q.match(/\d{15,20}/) || [])[0];
    return (id && guild.roles.cache.get(id)) || guild.roles.cache.find(x => x.name.toLowerCase() === q.toLowerCase()) || null;
};

const validRoles = (guild, ids) => ids.filter(id => guild.roles.cache.has(id));
const validChannels = (guild, ids) => ids.filter(id => guild.channels.cache.has(id));

const channelPicker = (customId, placeholder, types, current, { max = 1, guild } = {}) => {
    const menu = new ChannelSelectMenuBuilder().setCustomId(customId).setPlaceholder(placeholder.slice(0, 150))
        .setChannelTypes(types).setMinValues(0).setMaxValues(max);
    const ids = validChannels(guild, [].concat(current || []).filter(Boolean)).slice(0, max);
    if (ids.length) menu.setDefaultChannels(...ids);
    return row(menu);
};

const rolePicker = (customId, placeholder, current, { max = 1, guild } = {}) => {
    const menu = new RoleSelectMenuBuilder().setCustomId(customId).setPlaceholder(placeholder.slice(0, 150))
        .setMinValues(0).setMaxValues(max);
    const ids = validRoles(guild, [].concat(current || []).filter(Boolean)).slice(0, max);
    if (ids.length) menu.setDefaultRoles(...ids);
    return row(menu);
};


module.exports = {
    eph, TEXT, VOICE, CATEGORY, clip, ch, role, onoff, row, btn, ask, fail, findRole,
    validRoles, validChannels, channelPicker, rolePicker
};
