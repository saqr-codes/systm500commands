const config = require('../../config');
const db = require('../utils/db');
const e = require('../utils/embeds');
const r = require('../utils/resolve');
const t = require('../utils/time');

const coin = config.coin;
const money = n => `**${t.num(n)}** ${coin}`;

const parseAmount = (raw, max) => {
    if (!raw) return null;
    if (['كل', 'الكل', 'all'].includes(raw.toLowerCase())) return max;
    const n = Number(t.digits(raw).replace(/,/g, ''));
    return Number.isInteger(n) && n > 0 && n <= 1e12 ? n : null;
};

const cooldown = async (message, profile, key, ms) => {
    const left = (profile.cd[key] || 0) + ms - Date.now();
    if (left > 0) {
        await e.reply(message, e.warn(`انتظر **${t.formatDuration(left)}** قبل ما تستخدم هذا الأمر مرة ثانية.`, '⏳ انتظر شوي'));
        return false;
    }
    profile.cd[key] = Date.now();
    return true;
};

const mention = async (message, arg) => {
    const m = await r.member(message, arg);
    if (!m || m.user.bot) {
        await e.reply(message, e.err('منشن عضو صحيح (مو بوت).'));
        return null;
    }
    return m;
};

const bankMs = (message, key) => db.guild(message.guild.id).bank[key] * 60000;

const slotsIcons = ['🍒', '🍋', '🍇', '🔔', '💎', '7️⃣'];

module.exports = {
    category: 'الاقتصاد',
    icon: '💰',
    commands: [
        {
            name: 'رصيد',
            aliases: ['فلوس', 'رصيدي', 'محفظة'],
            desc: 'عرض رصيدك أو رصيد عضو',
            usage: 'رصيد [@العضو]',
            async run(message, args) {
                const member = args[0] ? await mention(message, args[0]) : message.member;
                if (!member) return;
                const p = db.user(message.guild.id, member.id);
                const users = Object.entries(db.users(message.guild.id)).sort((a, b) => (b[1].cash + b[1].bank) - (a[1].cash + a[1].bank));
                const rank = users.findIndex(([id]) => id === member.id) + 1;
                const embed = e.base(e.colors.gold)
                    .setTitle(`💳 حساب ${member.displayName}`)
                    .setThumbnail(member.displayAvatarURL({ size: 256 }))
                    .addFields(
                        { name: '👛 الكاش', value: money(p.cash), inline: true },
                        { name: '🏦 البنك', value: money(p.bank), inline: true },
                        { name: '💎 المجموع', value: money(p.cash + p.bank), inline: true },
                        { name: '🏆 الترتيب', value: `#${rank || '-'}`, inline: true }
                    );
                return e.reply(message, embed);
            }
        },
        {
            name: 'راتب',
            aliases: ['يومي', 'جائزة'],
            desc: 'استلام الراتب اليومي',
            usage: 'راتب',
            async run(message) {
                const p = db.user(message.guild.id, message.author.id);
                if (!(await cooldown(message, p, 'daily', bankMs(message, 'daily')))) return;
                const amount = t.rand(800, 1500);
                p.cash += amount;
                db.save();
                return e.reply(message, e.base(e.colors.ok).setTitle('💵 الراتب اليومي').setDescription(`استلمت ${money(amount)}\nرصيدك الآن ${money(p.cash)}`));
            }
        },
        {
            name: 'عمل',
            aliases: ['اشتغل', 'شغل'],
            desc: 'اشتغل واكسب فلوس',
            usage: 'عمل',
            async run(message) {
                const p = db.user(message.guild.id, message.author.id);
                if (!(await cooldown(message, p, 'work', bankMs(message, 'work')))) return;
                const jobs = ['مبرمج', 'سائق', 'طباخ', 'مصمم', 'بائع', 'نجار', 'طبيب', 'مهندس', 'صحفي', 'حارس'];
                const amount = t.rand(200, 600);
                p.cash += amount;
                db.save();
                return e.reply(message, e.base(e.colors.ok).setTitle('🛠️ يوم عمل').setDescription(`اشتغلت كـ **${t.pick(jobs)}** وكسبت ${money(amount)}`));
            }
        },
        {
            name: 'جريمة',
            aliases: ['سرقة_بنك', 'مغامرة'],
            desc: 'مخاطرة قد تربحك أو تخسرك',
            usage: 'جريمة',
            async run(message) {
                const p = db.user(message.guild.id, message.author.id);
                if (!(await cooldown(message, p, 'crime', bankMs(message, 'crime')))) return;
                if (Math.random() < 0.5) {
                    const amount = t.rand(500, 1500);
                    p.cash += amount;
                    db.save();
                    return e.reply(message, e.base(e.colors.ok).setTitle('🦹 نجحت العملية').setDescription(`هربت بغنيمة ${money(amount)}`));
                }
                const fine = Math.min(p.cash, t.rand(300, 900));
                p.cash -= fine;
                db.save();
                return e.reply(message, e.base(e.colors.err).setTitle('🚓 انمسكت').setDescription(`دفعت غرامة ${money(fine)}`));
            }
        },
        {
            name: 'سرقة',
            aliases: ['انهب', 'اسرق'],
            desc: 'محاولة سرقة كاش عضو',
            usage: 'سرقة @العضو',
            async run(message, args) {
                const member = await mention(message, args[0]);
                if (!member) return;
                if (member.id === message.author.id) return e.reply(message, e.err('ما تقدر تسرق نفسك.'));
                const p = db.user(message.guild.id, message.author.id);
                const v = db.user(message.guild.id, member.id);
                if (v.cash < 200) return e.reply(message, e.err('الضحية كاشه قليل، ما يستاهل.'));
                if (p.cash < 200) return e.reply(message, e.err('لازم يكون معك 200 كاش على الأقل عشان تسرق.'));
                if (!(await cooldown(message, p, 'rob', bankMs(message, 'rob')))) return;
                if (Math.random() < 0.45) {
                    const amount = Math.floor(v.cash * (t.rand(10, 30) / 100));
                    v.cash -= amount;
                    p.cash += amount;
                    db.save();
                    return e.reply(message, e.base(e.colors.ok).setTitle('🥷 سرقة ناجحة').setDescription(`سرقت ${money(amount)} من ${member}`));
                }
                const fine = Math.floor(p.cash * 0.15);
                p.cash -= fine;
                v.cash += fine;
                db.save();
                return e.reply(message, e.base(e.colors.err).setTitle('🚨 فشلت السرقة').setDescription(`انمسكت ودفعت ${money(fine)} لـ ${member}`));
            }
        },
        {
            name: 'تحويل',
            aliases: ['حول', 'ارسل_فلوس'],
            desc: 'تحويل فلوس لعضو',
            usage: 'تحويل @العضو <المبلغ>',
            async run(message, args) {
                const member = await mention(message, args[0]);
                if (!member) return;
                if (member.id === message.author.id) return e.reply(message, e.err('ما تقدر تحول لنفسك.'));
                const p = db.user(message.guild.id, message.author.id);
                const amount = parseAmount(args[1], p.cash);
                if (!amount) return e.reply(message, e.err('اكتب مبلغ صحيح.'));
                if (amount > p.cash) return e.reply(message, e.err(`كاشك ما يكفي، معك ${money(p.cash)}`));
                const fee = Math.floor(amount * 0.02);
                p.cash -= amount;
                db.user(message.guild.id, member.id).cash += amount - fee;
                db.save();
                return e.reply(message, e.base(e.colors.ok).setTitle('💸 تم التحويل').addFields(
                    { name: 'المستلم', value: `${member}`, inline: true },
                    { name: 'المبلغ', value: money(amount), inline: true },
                    { name: 'الضريبة 2%', value: money(fee), inline: true }
                ));
            }
        },
        {
            name: 'ايداع',
            aliases: ['حط_بنك', 'ودع'],
            desc: 'إيداع الكاش في البنك',
            usage: 'ايداع <المبلغ | كل>',
            async run(message, args) {
                const p = db.user(message.guild.id, message.author.id);
                const amount = parseAmount(args[0], p.cash);
                if (!amount || amount > p.cash) return e.reply(message, e.err('اكتب مبلغ صحيح ما يتجاوز كاشك.'));
                p.cash -= amount;
                p.bank += amount;
                db.save();
                return e.reply(message, e.ok(`تم إيداع ${money(amount)} في البنك 🏦\nرصيد البنك: ${money(p.bank)}`));
            }
        },
        {
            name: 'سحب_بنك',
            aliases: ['اسحب', 'سحب_فلوس'],
            desc: 'سحب فلوس من البنك',
            usage: 'سحب_بنك <المبلغ | كل>',
            async run(message, args) {
                const p = db.user(message.guild.id, message.author.id);
                const amount = parseAmount(args[0], p.bank);
                if (!amount || amount > p.bank) return e.reply(message, e.err('اكتب مبلغ صحيح ما يتجاوز رصيد بنكك.'));
                p.bank -= amount;
                p.cash += amount;
                db.save();
                return e.reply(message, e.ok(`تم سحب ${money(amount)} من البنك 👛\nكاشك: ${money(p.cash)}`));
            }
        },
        {
            name: 'الاغنياء',
            aliases: ['توب_فلوس', 'اغنى'],
            desc: 'قائمة أغنى الأعضاء',
            usage: 'الاغنياء',
            async run(message) {
                const medals = ['🥇', '🥈', '🥉'];
                const top = Object.entries(db.users(message.guild.id))
                    .map(([id, u]) => [id, u.cash + u.bank])
                    .filter(([, total]) => total > 0)
                    .sort((a, b) => b[1] - a[1]).slice(0, 10);
                if (!top.length) return e.reply(message, e.info('🏆 أغنى الأعضاء', 'ما فيه أحد عنده فلوس للحين.'));
                const lines = top.map(([id, total], i) => `${medals[i] || `**${i + 1}.**`} <@${id}> • ${money(total)}`).join('\n');
                return e.reply(message, e.base(e.colors.gold).setTitle('🏆 أغنى الأعضاء').setDescription(lines));
            }
        },
        {
            name: 'حظ',
            aliases: ['كوين', 'رهان'],
            desc: 'رهان على الصورة أو الكتابة',
            usage: 'حظ <صورة | كتابة> <المبلغ>',
            async run(message, args) {
                const sides = { 'صورة': 'صورة', 'كتابة': 'كتابة', 'ملك': 'صورة', 'نقش': 'كتابة' };
                const choice = sides[args[0]];
                const p = db.user(message.guild.id, message.author.id);
                const amount = parseAmount(args[1], p.cash);
                if (!choice || !amount) return e.reply(message, e.err('الاستخدام: `حظ صورة 500`'));
                if (amount > p.cash) return e.reply(message, e.err(`كاشك ما يكفي، معك ${money(p.cash)}`));
                const result = Math.random() < 0.5 ? 'صورة' : 'كتابة';
                const won = result === choice;
                p.cash += won ? amount : -amount;
                db.save();
                return e.reply(message, e.base(won ? e.colors.ok : e.colors.err)
                    .setTitle(won ? '🎉 ربحت' : '💔 خسرت')
                    .setDescription(`النتيجة: **${result}**\n${won ? 'ربحت' : 'خسرت'} ${money(amount)}\nرصيدك: ${money(p.cash)}`));
            }
        },
        {
            name: 'سلوت',
            aliases: ['ماكينة', 'سلوتس'],
            desc: 'ماكينة الحظ',
            usage: 'سلوت <المبلغ>',
            async run(message, args) {
                const p = db.user(message.guild.id, message.author.id);
                const amount = parseAmount(args[0], p.cash);
                if (!amount) return e.reply(message, e.err('اكتب مبلغ صحيح.'));
                if (amount > p.cash) return e.reply(message, e.err(`كاشك ما يكفي، معك ${money(p.cash)}`));
                const roll = [t.pick(slotsIcons), t.pick(slotsIcons), t.pick(slotsIcons)];
                const unique = new Set(roll).size;
                let multiplier = -1;
                if (unique === 1) multiplier = 5;
                else if (unique === 2) multiplier = 1;
                p.cash += amount * multiplier;
                db.save();
                const title = multiplier === 5 ? '🎰 جاكبوت' : multiplier === 1 ? '🎰 ربحت' : '🎰 خسرت';
                const text = multiplier > 0 ? `ربحت ${money(amount * multiplier)}` : `خسرت ${money(amount)}`;
                return e.reply(message, e.base(multiplier > 0 ? e.colors.ok : e.colors.err)
                    .setTitle(title)
                    .setDescription(`## ${roll.join('  ')}\n${text}\nرصيدك: ${money(p.cash)}`));
            }
        },
        {
            name: 'متجر',
            aliases: ['السوق', 'المتجر'],
            desc: 'عرض متجر السيرفر',
            usage: 'متجر',
            async run(message) {
                const shop = db.guild(message.guild.id).shop;
                if (!shop.length) return e.reply(message, e.info('🛒 المتجر', 'المتجر فاضي حالياً.'));
                const lines = shop.map((item, i) =>
                    `**${i + 1}.** ${item.name} • ${money(item.price)}${item.role ? ` • 🎭 <@&${item.role}>` : ''}`
                ).join('\n');
                return e.reply(message, e.base(e.colors.gold).setTitle('🛒 متجر السيرفر').setDescription(`${lines}\n\nللشراء اكتب: \`شراء <رقم المنتج>\``));
            }
        },
        {
            name: 'شراء',
            aliases: ['اشتري'],
            desc: 'شراء منتج من المتجر',
            usage: 'شراء <رقم المنتج>',
            async run(message, args) {
                const shop = db.guild(message.guild.id).shop;
                const item = shop[Number(t.digits(args[0] || '')) - 1];
                if (!item) return e.reply(message, e.err('رقم المنتج غير صحيح، شوف `متجر`'));
                const p = db.user(message.guild.id, message.author.id);
                if (p.cash < item.price) return e.reply(message, e.err(`تحتاج ${money(item.price)} وكاشك ${money(p.cash)}`));
                if (item.role && message.member.roles.cache.has(item.role)) return e.reply(message, e.err('عندك هذي الرتبة بالفعل.'));
                p.cash -= item.price;
                if (item.role) {
                    const given = await message.member.roles.add(item.role).then(() => true).catch(() => false);
                    if (!given) {
                        p.cash += item.price;
                        db.save();
                        return e.reply(message, e.err('ما قدرت أعطيك الرتبة (تأكد إن رتبة البوت أعلى منها)، ولا تم خصم أي مبلغ.'));
                    }
                } else p.inventory.push(item.name);
                db.save();
                return e.reply(message, e.ok(`اشتريت **${item.name}** بسعر ${money(item.price)}`, '🛍️ تمت عملية الشراء'));
            }
        },
        {
            name: 'حقيبة',
            aliases: ['مخزن', 'مشترياتي'],
            desc: 'عرض مشترياتك',
            usage: 'حقيبة',
            async run(message) {
                const p = db.user(message.guild.id, message.author.id);
                if (!p.inventory.length) return e.reply(message, e.info('🎒 حقيبتك', 'حقيبتك فاضية.'));
                const counts = {};
                p.inventory.forEach(i => { counts[i] = (counts[i] || 0) + 1; });
                const lines = Object.entries(counts).map(([name, n]) => `• ${name} × **${n}**`).join('\n');
                return e.reply(message, e.info('🎒 حقيبتك', lines));
            }
        },
        {
            name: 'اضافة_منتج',
            aliases: ['منتج_جديد'],
            desc: 'إضافة منتج للمتجر (يمكن ربطه برتبة)',
            usage: 'اضافة_منتج <السعر> <الاسم> [@الرتبة]',
            perms: ['ManageGuild'],
            async run(message, args) {
                const price = parseAmount(args[0]);
                if (!price) return e.reply(message, e.err('الاستخدام: `اضافة_منتج 5000 VIP @رتبة`'));
                const rolePart = args[args.length - 1];
                const role = args.length > 2 ? r.role(message, rolePart) : null;
                const name = args.slice(1, role ? -1 : undefined).join(' ');
                if (!name) return e.reply(message, e.err('اكتب اسم المنتج.'));
                db.guild(message.guild.id).shop.push({ name, price, role: role ? role.id : null });
                db.save();
                return e.reply(message, e.ok(`تمت إضافة **${name}** بسعر ${money(price)}`));
            }
        },
        {
            name: 'حذف_منتج',
            aliases: ['ازالة_منتج'],
            desc: 'حذف منتج من المتجر',
            usage: 'حذف_منتج <رقم المنتج>',
            perms: ['ManageGuild'],
            async run(message, args) {
                const shop = db.guild(message.guild.id).shop;
                const index = Number(t.digits(args[0] || '')) - 1;
                if (!shop[index]) return e.reply(message, e.err('رقم المنتج غير صحيح.'));
                const [removed] = shop.splice(index, 1);
                db.save();
                return e.reply(message, e.ok(`تم حذف **${removed.name}** من المتجر`));
            }
        },
        {
            name: 'اعطاء_فلوس',
            aliases: ['اضف_فلوس'],
            desc: 'إعطاء فلوس لعضو (للإدارة)',
            usage: 'اعطاء_فلوس @العضو <المبلغ>',
            perms: ['Administrator'],
            async run(message, args) {
                const member = await mention(message, args[0]);
                const amount = parseAmount(args[1]);
                if (!member || !amount) return e.reply(message, e.err('الاستخدام: `اعطاء_فلوس @العضو 1000`'));
                db.user(message.guild.id, member.id).cash += amount;
                db.save();
                return e.reply(message, e.ok(`تم إعطاء ${member} مبلغ ${money(amount)}`));
            }
        },
        {
            name: 'خصم_فلوس',
            aliases: ['سحب_فلوس_عضو'],
            desc: 'خصم فلوس من عضو (للإدارة)',
            usage: 'خصم_فلوس @العضو <المبلغ>',
            perms: ['Administrator'],
            async run(message, args) {
                const member = await mention(message, args[0]);
                const amount = parseAmount(args[1]);
                if (!member || !amount) return e.reply(message, e.err('الاستخدام: `خصم_فلوس @العضو 1000`'));
                const p = db.user(message.guild.id, member.id);
                p.cash = Math.max(0, p.cash - amount);
                db.save();
                return e.reply(message, e.ok(`تم خصم ${money(amount)} من ${member}`));
            }
        },
        {
            name: 'تصفير_رصيد',
            aliases: ['اصفر_حساب'],
            desc: 'تصفير رصيد عضو (للإدارة)',
            usage: 'تصفير_رصيد @العضو',
            perms: ['Administrator'],
            async run(message, args) {
                const member = await mention(message, args[0]);
                if (!member) return;
                const p = db.user(message.guild.id, member.id);
                p.cash = 0;
                p.bank = 0;
                db.save();
                return e.reply(message, e.ok(`تم تصفير حساب ${member}`));
            }
        }
    ]
};
