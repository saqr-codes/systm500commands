const { ChannelType } = require('discord.js');
const db = require('../utils/db');
const e = require('../utils/embeds');
const r = require('../utils/resolve');
const welcome = require('../core/welcome');

const textChannel = (message, arg) => {
    const c = r.channel(message, arg);
    return c && c.isTextBased() && !c.isVoiceBased() ? c : null;
};

const channelSetter = (name, aliases, desc, label, apply) => ({
    name,
    aliases,
    desc,
    usage: `${name} #الروم`,
    perms: ['Administrator'],
    async run(message, args) {
        if (['حذف', 'ايقاف', 'الغاء'].includes(args[0])) {
            apply(db.guild(message.guild.id), null);
            db.save();
            return e.reply(message, e.ok(`تم إلغاء ${label}`));
        }
        const channel = textChannel(message, args[0]);
        if (!channel) return e.reply(message, e.err(`منشن الروم، أو اكتب \`${name} حذف\` للإلغاء.`));
        apply(db.guild(message.guild.id), channel.id);
        db.save();
        return e.reply(message, e.ok(`تم تحديد ${label}: ${channel}`));
    }
});

module.exports = {
    category: 'الإعدادات',
    icon: '⚙️',
    commands: [
        {
            name: 'بريفكس',
            aliases: ['بادئة', 'تغيير_البريفكس'],
            desc: 'تغيير بريفكس البوت في السيرفر (اكتب "بدون" لإلغائه)',
            usage: 'بريفكس <الرمز>',
            perms: ['Administrator'],
            async run(message, args) {
                if (!args[0]) return e.reply(message, e.err('اكتب البريفكس الجديد أو `بدون`.'));
                const value = args[0] === 'بدون' ? '' : args[0].slice(0, 3);
                db.guild(message.guild.id).prefix = value;
                db.save();
                return e.reply(message, e.ok(value ? `البريفكس الجديد: \`${value}\`` : 'تم إلغاء البريفكس، الأوامر تشتغل بدون رمز'));
            }
        },
        channelSetter('لوق_اعداد', ['اعداد_لوق', 'سجلات'], 'تحديد روم السجلات', 'روم السجلات', (g, id) => { g.logs = id; }),
        channelSetter('اقتراحات_اعداد', ['اعداد_اقتراحات'], 'تحديد روم الاقتراحات', 'روم الاقتراحات', (g, id) => { g.suggestions = id; }),
        channelSetter('ترحيب_اعداد', ['اعداد_ترحيب'], 'تحديد روم الترحيب', 'روم الترحيب', (g, id) => { g.welcome.channel = id; }),
        channelSetter('خروج_اعداد', ['اعداد_مغادرة'], 'تحديد روم المغادرة', 'روم المغادرة', (g, id) => { g.welcome.leave = id; }),
        {
            name: 'ترحيب_رسالة',
            aliases: ['رسالة_ترحيب'],
            desc: 'تغيير رسالة الترحيب (المتغيرات: {user} {name} {server} {count})',
            usage: 'ترحيب_رسالة <النص>',
            perms: ['Administrator'],
            async run(message, args) {
                const text = args.join(' ').slice(0, 800);
                if (!text) return e.reply(message, e.err('اكتب نص الرسالة، المتغيرات المتاحة: `{user}` `{name}` `{server}` `{count}`'));
                db.guild(message.guild.id).welcome.message = text;
                db.save();
                return e.reply(message, e.ok('تم حفظ رسالة الترحيب، هذي تجربتها:'))
                    .then(() => e.send(message.channel, welcome.joinEmbed(message.member)));
            }
        },
        {
            name: 'ترحيب_تجربة',
            aliases: ['تجربة_ترحيب'],
            desc: 'تجربة رسالة الترحيب',
            usage: 'ترحيب_تجربة',
            perms: ['Administrator'],
            async run(message) {
                return e.reply(message, welcome.joinEmbed(message.member));
            }
        },
        {
            name: 'رتبة_تلقائية',
            aliases: ['رتبة_الدخول', 'اوتو_رول'],
            desc: 'رتبة تنعطى للأعضاء الجدد (اكتب "حذف" لإلغائها)',
            usage: 'رتبة_تلقائية @الرتبة',
            perms: ['Administrator'],
            async run(message, args) {
                const g = db.guild(message.guild.id);
                if (args[0] === 'حذف') {
                    g.welcome.autoRole = null;
                    db.save();
                    return e.reply(message, e.ok('تم إلغاء الرتبة التلقائية'));
                }
                const role = r.role(message, args.join(' '));
                if (!role) return e.reply(message, e.err('منشن الرتبة أو اكتب اسمها.'));
                if (role.position >= message.guild.members.me.roles.highest.position) {
                    return e.reply(message, e.err('هذي الرتبة أعلى من رتبة البوت.'));
                }
                g.welcome.autoRole = role.id;
                db.save();
                return e.reply(message, e.ok(`الأعضاء الجدد راح ياخذون رتبة ${role}`));
            }
        },
        {
            name: 'روم_مؤقت_اعداد',
            aliases: ['اعداد_روم_مؤقت', 'روم_خاص_اعداد'],
            desc: 'تحديد روم صوتي: من يدخله ينفتح له روم صوتي خاص',
            usage: 'روم_مؤقت_اعداد <ايدي الروم الصوتي>',
            perms: ['Administrator'],
            async run(message, args) {
                const g = db.guild(message.guild.id);
                if (args[0] === 'حذف') {
                    g.tempVoice.creator = null;
                    db.save();
                    return e.reply(message, e.ok('تم إلغاء نظام الرومات المؤقتة'));
                }
                const channel = r.channel(message, args.join(' ')) || message.member.voice.channel;
                if (!channel || channel.type !== ChannelType.GuildVoice) {
                    return e.reply(message, e.err('اكتب ايدي روم صوتي، أو ادخل روم صوتي ونفذ الأمر.'));
                }
                g.tempVoice.creator = channel.id;
                db.save();
                return e.reply(message, e.ok(`أي عضو يدخل **${channel.name}** راح ينفتح له روم صوتي خاص فيه`));
            }
        },
        {
            name: 'خط_اعداد',
            aliases: ['اعداد_خط', 'خط_تلقائي'],
            desc: 'تشغيل الخط التلقائي في روم (مرة ثانية يلغيه)',
            usage: 'خط_اعداد #الروم',
            perms: ['Administrator'],
            async run(message, args) {
                const channel = textChannel(message, args[0]) || message.channel;
                const g = db.guild(message.guild.id);
                const index = g.autoLine.channels.indexOf(channel.id);
                if (index === -1) g.autoLine.channels.push(channel.id); else g.autoLine.channels.splice(index, 1);
                db.save();
                const note = g.autoLine.image ? '' : '\nحدد صورة الخط بالأمر `خط_صورة <الرابط>`';
                return e.reply(message, e.ok(`${channel} ${index === -1 ? 'تم تفعيل الخط التلقائي فيه' : 'تم إلغاء الخط التلقائي منه'}${note}`));
            }
        },
        {
            name: 'خط_صورة',
            aliases: ['صورة_الخط'],
            desc: 'تحديد رابط صورة الخط التلقائي',
            usage: 'خط_صورة <رابط الصورة>',
            perms: ['Administrator'],
            async run(message, args) {
                const url = args[0] || message.attachments.first()?.url;
                if (!url || !/^https?:\/\//i.test(url)) return e.reply(message, e.err('ارسل رابط صورة صحيح أو أرفق صورة.'));
                db.guild(message.guild.id).autoLine.image = url;
                db.save();
                return e.reply(message, e.base(e.colors.ok).setTitle('✅ تم حفظ صورة الخط').setImage(url));
            }
        },
        {
            name: 'رد_اضافة',
            aliases: ['اضافة_رد'],
            desc: 'إضافة رد تلقائي: الكلمة | الرد',
            usage: 'رد_اضافة <الكلمة> | <الرد>',
            perms: ['ManageGuild'],
            async run(message, args) {
                const [trigger, ...rest] = args.join(' ').split('|').map(s => s.trim());
                const response = rest.join('|').trim();
                if (!trigger || !response) return e.reply(message, e.err('الاستخدام: `رد_اضافة السلام | وعليكم السلام`'));
                const g = db.guild(message.guild.id);
                if (g.autoReply.length >= 50) return e.reply(message, e.err('وصلت الحد الأقصى 50 رد.'));
                g.autoReply = g.autoReply.filter(x => x.trigger !== trigger.toLowerCase());
                g.autoReply.push({ trigger: trigger.toLowerCase(), response: response.slice(0, 1500) });
                db.save();
                return e.reply(message, e.ok(`إذا كتب أحد **${trigger}** راح أرد عليه`));
            }
        },
        {
            name: 'رد_حذف',
            aliases: ['حذف_رد'],
            desc: 'حذف رد تلقائي',
            usage: 'رد_حذف <الكلمة>',
            perms: ['ManageGuild'],
            async run(message, args) {
                const g = db.guild(message.guild.id);
                const before = g.autoReply.length;
                g.autoReply = g.autoReply.filter(x => x.trigger !== args.join(' ').toLowerCase());
                if (g.autoReply.length === before) return e.reply(message, e.err('ما لقيت رد بهذي الكلمة.'));
                db.save();
                return e.reply(message, e.ok('تم حذف الرد التلقائي'));
            }
        },
        {
            name: 'الردود',
            aliases: ['قائمة_الردود'],
            desc: 'عرض الردود التلقائية',
            usage: 'الردود',
            perms: ['ManageGuild'],
            async run(message) {
                const list = db.guild(message.guild.id).autoReply;
                if (!list.length) return e.reply(message, e.info('🤖 الردود التلقائية', 'ما فيه ردود مسجلة.'));
                const lines = list.map((x, i) => `**${i + 1}.** \`${x.trigger}\` ← ${x.response.slice(0, 60)}`).join('\n');
                return e.reply(message, e.info(`🤖 الردود التلقائية (${list.length})`, lines));
            }
        }
    ]
};
