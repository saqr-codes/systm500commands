const db = require('../utils/db');
const e = require('../utils/embeds');
const r = require('../utils/resolve');
const t = require('../utils/time');
const { parseAmount, withTax } = require('../core/automation');

const textChannel = (message, arg) => {
    const c = r.channel(message, arg);
    return c && c.isTextBased() && !c.isVoiceBased() ? c : null;
};

// أمر يشغل/يطفي ميزة لروم (مرة ثانية يلغيها)
const roomToggle = (name, aliases, desc, label, pick) => ({
    name,
    aliases,
    desc,
    usage: `${name} [#الروم]`,
    perms: ['ManageGuild'],
    async run(message, args) {
        const channel = (args[0] ? textChannel(message, args[0]) : null) || (args[0] ? null : message.channel);
        if (!channel) return e.reply(message, e.err('منشن روم كتابي صحيح.'));
        const list = pick(db.guild(message.guild.id).automation);
        const index = list.indexOf(channel.id);
        if (index === -1) list.push(channel.id); else list.splice(index, 1);
        db.save();
        return e.reply(message, e.ok(`${label} ${index === -1 ? 'تم تفعيله في' : 'تم إلغاؤه من'} ${channel}`));
    }
});

const emojiOk = text => /^(<a?:\w+:\d{15,20}>|\p{Extended_Pictographic}[\p{Extended_Pictographic}\u200d\ufe0f\u{1F3FB}-\u{1F3FF}]*)$/u.test(text);

const mention = id => (id ? `<#${id}>` : '`غير محدد`');

module.exports = {
    category: 'الأتمتة',
    icon: '🤖',
    commands: [
        {
            name: 'ضريبة',
            aliases: ['tax', 'بروبوت'],
            desc: 'حساب ضريبة بروبوت (المبلغ اللي لازم يتحول عشان يوصل كامل)',
            usage: 'ضريبة <المبلغ مثل 5000 أو 2.5k أو 1m>',
            async run(message, args) {
                const amount = parseAmount(args.join(''));
                if (!amount) return e.reply(message, e.err('اكتب مبلغ صحيح مثل `5000` أو `2.5k` أو `1m`.'));
                const total = withTax(amount);
                return e.reply(message, e.base(e.colors.gold).setTitle('💳 حساب الضريبة').addFields(
                    { name: 'المبلغ المطلوب يوصل', value: `\`${t.num(amount)}\``, inline: true },
                    { name: 'المبلغ اللي تحوله', value: `\`${t.num(total)}\``, inline: true },
                    { name: 'الضريبة', value: `\`${t.num(total - amount)}\``, inline: true }
                ));
            }
        },
        roomToggle('ضريبة_تلقائية', ['ضريبة_اوتو', 'اوتو_تاكس'], 'تفعيل الضريبة التلقائية في روم (أي مبلغ يكتب فيه ينحسب)', 'الضريبة التلقائية', a => a.tax),
        {
            name: 'ضريبة_خط',
            aliases: ['خط_الضريبة'],
            desc: 'رابط صورة أو نص يرسله البوت بعد كل حساب ضريبة تلقائي (اكتب "حذف" للإلغاء)',
            usage: 'ضريبة_خط <رابط | حذف>',
            perms: ['ManageGuild'],
            async run(message, args) {
                const a = db.guild(message.guild.id).automation;
                const value = args.join(' ') || message.attachments.first()?.url;
                if (!value) return e.reply(message, e.err('اكتب الرابط أو `حذف`.'));
                a.taxLine = ['حذف', 'الغاء'].includes(value) ? null : value.slice(0, 500);
                db.save();
                return e.reply(message, e.ok(a.taxLine ? 'تم حفظ خط الضريبة' : 'تم حذف خط الضريبة'));
            }
        },
        roomToggle('روم_صور', ['صور_فقط'], 'جعل الروم للصور فقط (يحذف أي رسالة بدون صورة)', 'وضع الصور فقط', a => a.images),
        roomToggle('روم_يوتيوب', ['يوتيوب_فقط'], 'جعل الروم لروابط يوتيوب فقط', 'وضع روابط اليوتيوب فقط', a => a.youtube),
        {
            name: 'تفاعل_تلقائي',
            aliases: ['ريأكشن_تلقائي', 'اوتو_رياكت'],
            desc: 'إضافة تفاعل تلقائي على كل رسالة في روم (اكتب "حذف" لحذف تفاعلات الروم)',
            usage: 'تفاعل_تلقائي <الايموجي | حذف> [#الروم]',
            perms: ['ManageGuild'],
            async run(message, args) {
                const react = db.guild(message.guild.id).automation.react;
                const channel = textChannel(message, args[1]) || message.channel;
                if (['حذف', 'الغاء'].includes(args[0])) {
                    delete react[channel.id];
                    db.save();
                    return e.reply(message, e.ok(`تم حذف التفاعلات التلقائية من ${channel}`));
                }
                if (!args[0] || !emojiOk(args[0])) return e.reply(message, e.err('اكتب ايموجي صحيح (عادي أو مخصص من سيرفر البوت).'));
                const list = (react[channel.id] ||= []);
                if (list.length >= 5) return e.reply(message, e.err('الحد الأقصى 5 تفاعلات لكل روم.'));
                if (!list.includes(args[0])) list.push(args[0]);
                db.save();
                return e.reply(message, e.ok(`كل رسالة في ${channel} راح ياخذ تفاعل ${list.join(' ')}`));
            }
        },
        {
            name: 'مشاعر',
            aliases: ['روم_مشاعر'],
            desc: 'تحويل روم لروم مشاعر: البوت يعيد نشر الرسائل كامبد (مرة ثانية يلغيه)',
            usage: 'مشاعر [#الروم]',
            perms: ['ManageGuild'],
            async run(message, args) {
                const f = db.guild(message.guild.id).automation.feelings;
                const channel = textChannel(message, args[0]) || message.channel;
                if (f.channel === channel.id) {
                    f.channel = null;
                    db.save();
                    return e.reply(message, e.ok(`تم إلغاء روم المشاعر ${channel}`));
                }
                f.channel = channel.id;
                db.save();
                return e.reply(message, e.ok(`${channel} الحين روم مشاعر${f.anonymous ? ' (مجهول)' : ''}\nتحكم بالإخفاء بالأمر \`مشاعر_مجهول\``));
            }
        },
        {
            name: 'مشاعر_مجهول',
            aliases: ['مشاعر_سرية'],
            desc: 'إخفاء اسم الكاتب في روم المشاعر',
            usage: 'مشاعر_مجهول <تشغيل | ايقاف>',
            perms: ['ManageGuild'],
            async run(message, args) {
                const f = db.guild(message.guild.id).automation.feelings;
                const wanted = { 'تشغيل': true, 'ايقاف': false }[args[0]];
                f.anonymous = wanted === undefined ? !f.anonymous : wanted;
                db.save();
                return e.reply(message, e.ok(f.anonymous ? 'الكتابة في روم المشاعر صارت مجهولة 🕶️' : 'يظهر اسم الكاتب في روم المشاعر'));
            }
        },
        {
            name: 'بوست_اعداد',
            aliases: ['شكر_البوست', 'اعداد_بوست'],
            desc: 'رسالة شكر لمن يسوي بوست للسيرفر (المتغيرات: {user} {server}) — اكتب "حذف" للإلغاء',
            usage: 'بوست_اعداد #الروم [امبد] <الرسالة>',
            perms: ['ManageGuild'],
            async run(message, args) {
                const b = db.guild(message.guild.id).automation.boost;
                if (['حذف', 'الغاء'].includes(args[0])) {
                    b.channel = null;
                    db.save();
                    return e.reply(message, e.ok('تم إلغاء رسالة شكر البوست'));
                }
                const channel = textChannel(message, args[0]);
                if (!channel) return e.reply(message, e.err('الاستخدام: `بوست_اعداد #الروم شكراً {user} على البوست 💜`\nأو اكتب `بوست_اعداد حذف`.'));
                const rest = args.slice(1);
                const embed = rest[0] === 'امبد';
                if (embed) rest.shift();
                if (rest.length) b.message = rest.join(' ').slice(0, 1500);
                b.channel = channel.id;
                b.embed = embed;
                db.save();
                return e.reply(message, e.ok(`رسالة شكر البوست راح تنرسل في ${channel}${embed ? ' كامبد' : ''}\n> ${b.message.replace(/{user}/g, message.author.toString())}`));
            }
        },
        {
            name: 'اتمتة',
            aliases: ['الاتمتة', 'اوتوميشن'],
            desc: 'عرض كل إعدادات الأتمتة',
            usage: 'اتمتة',
            perms: ['ManageGuild'],
            async run(message) {
                const a = db.guild(message.guild.id).automation;
                const list = ids => (ids.length ? ids.map(mention).join(' ') : 'لا يوجد');
                const reacts = Object.entries(a.react).map(([id, l]) => `<#${id}> ${l.join(' ')}`).join('\n') || 'لا يوجد';
                return e.reply(message, e.base().setTitle('🤖 إعدادات الأتمتة').addFields(
                    { name: '💳 الضريبة التلقائية', value: list(a.tax), inline: false },
                    { name: '🖼️ رومات الصور', value: list(a.images), inline: false },
                    { name: '▶️ رومات اليوتيوب', value: list(a.youtube), inline: false },
                    { name: '😀 التفاعل التلقائي', value: reacts, inline: false },
                    { name: '💭 روم المشاعر', value: `${mention(a.feelings.channel)}${a.feelings.anonymous ? ' • مجهول' : ''}`, inline: true },
                    { name: '💜 شكر البوست', value: mention(a.boost.channel), inline: true }
                ));
            }
        }
    ]
};
