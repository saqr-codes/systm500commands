const { ChannelType, version } = require('discord.js');
const os = require('os');
const db = require('../utils/db');
const e = require('../utils/embeds');
const r = require('../utils/resolve');
const t = require('../utils/time');
const reminders = require('../utils/reminders');

const flagNames = {
    Staff: 'موظف ديسكورد',
    Partner: 'شريك',
    BugHunterLevel1: 'صائد أخطاء',
    HypeSquadOnlineHouse1: 'بسالة',
    HypeSquadOnlineHouse2: 'تألق',
    HypeSquadOnlineHouse3: 'توازن',
    PremiumEarlySupporter: 'داعم مبكر',
    VerifiedDeveloper: 'مطور موثق',
    ActiveDeveloper: 'مطور نشط'
};

const statusNames = { online: '🟢 متصل', idle: '🌙 خامل', dnd: '⛔ مشغول', offline: '⚫ غير متصل' };

const channelNames = {
    [ChannelType.GuildText]: 'كتابي',
    [ChannelType.GuildVoice]: 'صوتي',
    [ChannelType.GuildCategory]: 'تصنيف',
    [ChannelType.GuildAnnouncement]: 'إعلانات',
    [ChannelType.GuildForum]: 'منتدى',
    [ChannelType.GuildStageVoice]: 'ستيج'
};

module.exports = {
    category: 'الأدوات',
    icon: '🧰',
    commands: [
        {
            name: 'بنق',
            aliases: ['بينق', 'ping'],
            desc: 'سرعة استجابة البوت',
            usage: 'بنق',
            async run(message) {
                const sent = await message.reply({ content: '🏓 ...', ...e.opts });
                const embed = e.base()
                    .setTitle('🏓 سرعة البوت')
                    .addFields(
                        { name: '📡 الرسائل', value: `\`${sent.createdTimestamp - message.createdTimestamp}ms\``, inline: true },
                        { name: '💓 الاتصال', value: `\`${message.client.ws.ping}ms\``, inline: true }
                    );
                return sent.edit({ content: '', embeds: [embed] });
            }
        },
        {
            name: 'بوت',
            aliases: ['معلومات_البوت', 'عن_البوت'],
            desc: 'معلومات وإحصائيات البوت',
            usage: 'بوت',
            async run(message) {
                const c = message.client;
                const embed = e.base()
                    .setTitle(`🤖 ${c.user.username}`)
                    .setThumbnail(c.user.displayAvatarURL({ size: 256 }))
                    .addFields(
                        { name: '🌐 السيرفرات', value: t.num(c.guilds.cache.size), inline: true },
                        { name: '👥 الأعضاء', value: t.num(c.guilds.cache.reduce((a, g) => a + g.memberCount, 0)), inline: true },
                        { name: '⏱️ مدة التشغيل', value: t.formatDuration(c.uptime), inline: true },
                        { name: '💾 الذاكرة', value: `${(process.memoryUsage().rss / 1048576).toFixed(1)} MB`, inline: true },
                        { name: '📚 المكتبة', value: `discord.js ${version}`, inline: true },
                        { name: '🧩 الأوامر', value: t.num(c.commands.size), inline: true }
                    );
                return e.reply(message, embed);
            }
        },
        {
            name: 'احصائيات',
            aliases: ['احصاءات', 'ستاتس'],
            desc: 'إحصائيات النظام',
            usage: 'احصائيات',
            async run(message) {
                const mem = process.memoryUsage();
                const embed = e.base()
                    .setTitle('📊 إحصائيات النظام')
                    .addFields(
                        { name: '🖥️ النظام', value: `${os.platform()} • ${os.arch()}`, inline: true },
                        { name: '⚙️ المعالج', value: `${os.cpus().length} أنوية`, inline: true },
                        { name: '🧠 الرام', value: `${(mem.heapUsed / 1048576).toFixed(1)} / ${(mem.heapTotal / 1048576).toFixed(1)} MB`, inline: true },
                        { name: '🟩 Node', value: process.version, inline: true },
                        { name: '📡 البنق', value: `${message.client.ws.ping}ms`, inline: true },
                        { name: '⏱️ التشغيل', value: t.formatDuration(message.client.uptime), inline: true }
                    );
                return e.reply(message, embed);
            }
        },
        {
            name: 'سيرفر',
            aliases: ['معلومات_السيرفر', 'السيرفر'],
            desc: 'معلومات السيرفر',
            usage: 'سيرفر',
            async run(message) {
                const g = message.guild;
                await g.members.fetch().catch(() => {});
                const channels = g.channels.cache;
                const embed = e.base()
                    .setTitle(`🏰 ${g.name}`)
                    .setThumbnail(g.iconURL({ size: 256 }))
                    .addFields(
                        { name: '👑 المالك', value: `<@${g.ownerId}>`, inline: true },
                        { name: '🆔 الايدي', value: `\`${g.id}\``, inline: true },
                        { name: '📅 تاريخ الإنشاء', value: t.stamp(g.createdAt, 'D'), inline: true },
                        { name: '👥 الأعضاء', value: `${t.num(g.memberCount)} (🤖 ${g.members.cache.filter(m => m.user.bot).size})`, inline: true },
                        { name: '💬 الرومات', value: `كتابي ${channels.filter(c => c.type === ChannelType.GuildText).size} • صوتي ${channels.filter(c => c.isVoiceBased()).size}`, inline: true },
                        { name: '🎭 الرتب', value: `${g.roles.cache.size}`, inline: true },
                        { name: '😀 الايموجي', value: `${g.emojis.cache.size}`, inline: true },
                        { name: '💎 البوست', value: `مستوى ${g.premiumTier} • ${g.premiumSubscriptionCount || 0} بوست`, inline: true },
                        { name: '🔐 التحقق', value: `${g.verificationLevel}`, inline: true }
                    );
                if (g.bannerURL()) embed.setImage(g.bannerURL({ size: 1024 }));
                return e.reply(message, embed);
            }
        },
        {
            name: 'معلومات',
            aliases: ['يوزر', 'من_هذا', 'هوية'],
            desc: 'معلومات عضو',
            usage: 'معلومات [@العضو]',
            async run(message, args) {
                const member = args[0] ? await r.member(message, args[0]) : message.member;
                if (!member) return e.reply(message, e.err('ما لقيت العضو.'));
                await member.user.fetch().catch(() => {});
                const flags = member.user.flags ? member.user.flags.toArray().map(f => flagNames[f]).filter(Boolean) : [];
                const roles = member.roles.cache.filter(x => x.id !== message.guild.id)
                    .sort((a, b) => b.position - a.position).map(x => `${x}`);
                const embed = e.base()
                    .setTitle(`👤 ${member.displayName}`)
                    .setThumbnail(member.displayAvatarURL({ size: 256 }))
                    .addFields(
                        { name: '🏷️ الاسم', value: member.user.tag, inline: true },
                        { name: '🆔 الايدي', value: `\`${member.id}\``, inline: true },
                        { name: '📡 الحالة', value: statusNames[member.presence?.status || 'offline'], inline: true },
                        { name: '📅 إنشاء الحساب', value: t.stamp(member.user.createdAt, 'D'), inline: true },
                        { name: '📥 دخول السيرفر', value: t.stamp(member.joinedAt, 'D'), inline: true },
                        { name: '🎖️ أعلى رتبة', value: `${member.roles.highest}`, inline: true },
                        { name: `🎭 الرتب (${roles.length})`, value: roles.slice(0, 15).join(' ') || 'لا يوجد', inline: false }
                    );
                if (flags.length) embed.addFields({ name: '🏅 الشارات', value: flags.join(' • '), inline: false });
                if (member.user.bannerURL()) embed.setImage(member.user.bannerURL({ size: 1024 }));
                return e.reply(message, embed);
            }
        },
        {
            name: 'افتار',
            aliases: ['صورة', 'صورتي', 'ايفتار'],
            desc: 'عرض صورة حساب عضو',
            usage: 'افتار [@العضو]',
            async run(message, args) {
                const user = args[0] ? (await r.member(message, args[0]))?.user || await r.user(message.client, args[0]) : message.author;
                if (!user) return e.reply(message, e.err('ما لقيت العضو.'));
                const url = user.displayAvatarURL({ size: 1024 });
                const embed = e.base().setTitle(`🖼️ صورة ${user.username}`).setImage(url).setDescription(`[رابط الصورة](${url})`);
                return e.reply(message, embed);
            }
        },
        {
            name: 'بنر',
            aliases: ['خلفية', 'بانر'],
            desc: 'عرض بنر حساب عضو',
            usage: 'بنر [@العضو]',
            async run(message, args) {
                const base = args[0] ? (await r.member(message, args[0]))?.user || await r.user(message.client, args[0]) : message.author;
                if (!base) return e.reply(message, e.err('ما لقيت العضو.'));
                const user = await base.fetch(true).catch(() => null);
                if (!user || !user.bannerURL()) return e.reply(message, e.err('هذا العضو ما عنده بنر.'));
                return e.reply(message, e.base().setTitle(`🎨 بنر ${user.username}`).setImage(user.bannerURL({ size: 1024 })));
            }
        },
        {
            name: 'رتبة_معلومات',
            aliases: ['معلومات_رتبة'],
            desc: 'معلومات رتبة',
            usage: 'رتبة_معلومات @الرتبة',
            async run(message, args) {
                const role = r.role(message, args.join(' '));
                if (!role) return e.reply(message, e.err('منشن الرتبة أو اكتب اسمها.'));
                const embed = e.base(role.color || e.colors.main)
                    .setTitle(`🎭 ${role.name}`)
                    .addFields(
                        { name: '🆔 الايدي', value: `\`${role.id}\``, inline: true },
                        { name: '🎨 اللون', value: role.hexColor, inline: true },
                        { name: '👥 الأعضاء', value: `${role.members.size}`, inline: true },
                        { name: '📌 الترتيب', value: `${role.position}`, inline: true },
                        { name: '📢 منشن', value: role.mentionable ? 'نعم' : 'لا', inline: true },
                        { name: '👁️ منفصلة', value: role.hoist ? 'نعم' : 'لا', inline: true },
                        { name: '📅 الإنشاء', value: t.stamp(role.createdAt, 'D'), inline: false }
                    );
                return e.reply(message, embed);
            }
        },
        {
            name: 'روم_معلومات',
            aliases: ['معلومات_روم'],
            desc: 'معلومات روم',
            usage: 'روم_معلومات [#الروم]',
            async run(message, args) {
                const c = r.channel(message, args[0]) || message.channel;
                const embed = e.base()
                    .setTitle(`📺 ${c.name}`)
                    .addFields(
                        { name: '🆔 الايدي', value: `\`${c.id}\``, inline: true },
                        { name: '📂 النوع', value: channelNames[c.type] || 'أخرى', inline: true },
                        { name: '📅 الإنشاء', value: t.stamp(c.createdAt, 'D'), inline: true }
                    );
                if (c.topic) embed.addFields({ name: '📝 الوصف', value: c.topic, inline: false });
                return e.reply(message, embed);
            }
        },
        {
            name: 'الاعضاء',
            aliases: ['عدد', 'احصاء_الاعضاء'],
            desc: 'إحصائية الأعضاء والحالات',
            usage: 'الاعضاء',
            async run(message) {
                const g = message.guild;
                await g.members.fetch().catch(() => {});
                const members = g.members.cache;
                const count = s => members.filter(m => (m.presence?.status || 'offline') === s).size;
                const embed = e.base()
                    .setTitle('👥 إحصائية الأعضاء')
                    .setDescription(
                        `**الكل:** ${t.num(g.memberCount)}\n` +
                        `**البشر:** ${members.filter(m => !m.user.bot).size}\n` +
                        `**البوتات:** ${members.filter(m => m.user.bot).size}\n\n` +
                        `🟢 متصل: **${count('online')}**\n🌙 خامل: **${count('idle')}**\n⛔ مشغول: **${count('dnd')}**\n⚫ غير متصل: **${count('offline')}**\n\n` +
                        `🎙️ في الصوت: **${members.filter(m => m.voice.channel).size}**`
                    );
                return e.reply(message, embed);
            }
        },
        {
            name: 'الوقت',
            aliases: ['الساعة', 'التاريخ'],
            desc: 'الوقت والتاريخ الحالي',
            usage: 'الوقت',
            async run(message) {
                const now = new Date();
                return e.reply(message, e.info('🕐 الوقت الآن', `${t.stamp(now, 'F')}\n${t.stamp(now, 'R')}`));
            }
        },
        {
            name: 'حاسبة',
            aliases: ['احسب', 'حساب_رقم'],
            desc: 'آلة حاسبة',
            usage: 'حاسبة 5*(3+2)',
            async run(message, args) {
                const raw = t.digits(args.join(' ')).replace(/×/g, '*').replace(/÷/g, '/').replace(/\^/g, '**');
                if (!raw || !/^[\d+\-*/().%\s]+$/.test(raw)) return e.reply(message, e.err('اكتب معادلة صحيحة مثل `5*(3+2)`'));
                let result;
                try {
                    result = Function(`"use strict"; return (${raw})`)();
                } catch {
                    return e.reply(message, e.err('المعادلة غير صحيحة.'));
                }
                if (typeof result !== 'number' || !Number.isFinite(result)) return e.reply(message, e.err('ما أقدر أحسب هذي المعادلة.'));
                return e.reply(message, e.base().setTitle('🧮 الحاسبة').addFields(
                    { name: 'المعادلة', value: `\`${raw}\``, inline: false },
                    { name: 'الناتج', value: `\`${result}\``, inline: false }
                ));
            }
        },
        {
            name: 'تصويت',
            aliases: ['استفتاء', 'بول'],
            desc: 'إنشاء تصويت بنعم أو لا',
            usage: 'تصويت <السؤال>',
            perms: ['ManageMessages'],
            async run(message, args) {
                if (!args.length) return e.reply(message, e.err('اكتب سؤال التصويت.'));
                const embed = e.base(e.colors.info)
                    .setTitle('📊 تصويت جديد')
                    .setDescription(`## ${args.join(' ')}\n\n✅ موافق\n❌ غير موافق`)
                    .setAuthor({ name: message.member.displayName, iconURL: message.author.displayAvatarURL() });
                await message.delete().catch(() => {});
                const sent = await e.send(message.channel, embed);
                await sent.react('✅').catch(() => {});
                await sent.react('❌').catch(() => {});
            }
        },
        {
            name: 'تذكير',
            aliases: ['ذكرني'],
            desc: 'تذكير بعد مدة معينة',
            usage: 'تذكير <المدة> <النص>',
            async run(message, args) {
                const ms = t.parseDuration(args[0]);
                const text = args.slice(1).join(' ');
                if (!ms || ms > 30 * 86400000 || !text) {
                    return e.reply(message, e.err('الاستخدام: `تذكير 10د اشتري خبز` ، الحد الأقصى 30 يوم.'));
                }
                if (reminders.countFor(message.author.id) >= 10) return e.reply(message, e.err('عندك 10 تذكيرات شغالة، انتظر ينتهي واحد منها.'));
                reminders.add(message.client, { channelId: message.channel.id, userId: message.author.id, text, ms });
                return e.reply(message, e.ok(`راح أذكرك بعد **${t.formatDuration(ms)}**`, '⏰ تم ضبط التذكير'));
            }
        },
        {
            name: 'ايموجي',
            aliases: ['كبر'],
            desc: 'تكبير ايموجي مخصص',
            usage: 'ايموجي <الايموجي>',
            async run(message, args) {
                const m = (args[0] || '').match(/<(a?):(\w+):(\d+)>/);
                if (!m) return e.reply(message, e.err('اكتب ايموجي مخصص من السيرفرات.'));
                const url = `https://cdn.discordapp.com/emojis/${m[3]}.${m[1] ? 'gif' : 'png'}?size=256`;
                return e.reply(message, e.base().setTitle(`😀 ${m[2]}`).setImage(url).setDescription(`[الرابط](${url})`));
            }
        },
        {
            name: 'الدعوة',
            aliases: ['ضيف_البوت', 'رابط_البوت'],
            desc: 'رابط دعوة البوت',
            usage: 'الدعوة',
            async run(message) {
                const url = `https://discord.com/api/oauth2/authorize?client_id=${message.client.user.id}&permissions=8&scope=bot`;
                return e.reply(message, e.info('🔗 دعوة البوت', `[اضغط هنا لإضافة البوت](${url})`));
            }
        },
        {
            name: 'الرتب',
            aliases: ['قائمة_الرتب'],
            desc: 'عرض رتب السيرفر',
            usage: 'الرتب',
            async run(message) {
                const roles = message.guild.roles.cache.filter(x => x.id !== message.guild.id)
                    .sort((a, b) => b.position - a.position).map(x => `${x}`);
                const text = roles.join(' ').slice(0, 3900) || 'لا يوجد';
                return e.reply(message, e.info(`🎭 رتب السيرفر (${roles.length})`, text));
            }
        }
    ]
};
