const { joinVoiceChannel, getVoiceConnection } = require('@discordjs/voice');
const e = require('../utils/embeds');
const r = require('../utils/resolve');
const db = require('../utils/db');

const ownRoom = async (message) => {
    const channel = message.member.voice.channel;
    const g = db.guild(message.guild.id);
    if (!channel || !g.tempVoice.rooms[channel.id]) {
        await e.reply(message, e.err('لازم تكون داخل رومك الصوتي المؤقت.'));
        return null;
    }
    if (g.tempVoice.rooms[channel.id] !== message.author.id) {
        await e.reply(message, e.err('هذا الروم مو ملكك.'));
        return null;
    }
    return channel;
};

module.exports = {
    category: 'الصوت',
    icon: '🎙️',
    commands: [
        {
            name: 'ادخل',
            aliases: ['تعال', 'ادخل_الروم'],
            desc: 'يدخل البوت الروم الصوتي اللي أنت فيه',
            usage: 'ادخل [#الروم الصوتي]',
            perms: ['MoveMembers'],
            async run(message, args) {
                const channel = r.channel(message, args[0]) || message.member.voice.channel;
                if (!channel || !channel.isVoiceBased()) return e.reply(message, e.err('ادخل روم صوتي أو حدد روم صوتي.'));
                joinVoiceChannel({
                    channelId: channel.id,
                    guildId: message.guild.id,
                    adapterCreator: message.guild.voiceAdapterCreator,
                    selfDeaf: true
                });
                return e.reply(message, e.ok(`دخلت **${channel.name}** 🎧`));
            }
        },
        {
            name: 'اطلع',
            aliases: ['اخرج', 'روح', 'غادر'],
            desc: 'يخرج البوت من الروم الصوتي',
            usage: 'اطلع',
            perms: ['MoveMembers'],
            async run(message) {
                const connection = getVoiceConnection(message.guild.id);
                if (!connection) return e.reply(message, e.err('أنا مو داخل أي روم صوتي.'));
                connection.destroy();
                return e.reply(message, e.ok('طلعت من الروم الصوتي 👋'));
            }
        },
        {
            name: 'روم_اسم',
            aliases: ['غير_اسم_رومي', 'اسم_رومي'],
            desc: 'تغيير اسم روم الصوتي المؤقت الخاص بك',
            usage: 'روم_اسم <الاسم الجديد>',
            async run(message, args) {
                const channel = await ownRoom(message);
                if (!channel) return;
                const name = args.join(' ').slice(0, 90);
                if (!name) return e.reply(message, e.err('اكتب الاسم الجديد.'));
                await channel.setName(name).catch(() => {});
                return e.reply(message, e.ok(`تم تغيير اسم رومك إلى **${name}**`));
            }
        },
        {
            name: 'روم_حد',
            aliases: ['حد_رومي', 'عدد_رومي'],
            desc: 'تحديد عدد الأعضاء في رومك المؤقت (0 بدون حد)',
            usage: 'روم_حد <العدد>',
            async run(message, args) {
                const channel = await ownRoom(message);
                if (!channel) return;
                const limit = Number(args[0]);
                if (Number.isNaN(limit) || limit < 0 || limit > 99) return e.reply(message, e.err('اكتب رقم من 0 إلى 99.'));
                await channel.setUserLimit(limit).catch(() => {});
                return e.reply(message, e.ok(limit ? `الحد الأقصى لرومك **${limit}** أعضاء` : 'تم إلغاء الحد من رومك'));
            }
        },
        {
            name: 'روم_قفل',
            aliases: ['اقفل_رومي'],
            desc: 'قفل رومك المؤقت عن الآخرين',
            usage: 'روم_قفل',
            async run(message) {
                const channel = await ownRoom(message);
                if (!channel) return;
                await channel.permissionOverwrites.edit(message.guild.roles.everyone, { Connect: false }).catch(() => {});
                return e.reply(message, e.ok('تم قفل رومك 🔒'));
            }
        },
        {
            name: 'روم_فتح',
            aliases: ['افتح_رومي'],
            desc: 'فتح رومك المؤقت للجميع',
            usage: 'روم_فتح',
            async run(message) {
                const channel = await ownRoom(message);
                if (!channel) return;
                await channel.permissionOverwrites.edit(message.guild.roles.everyone, { Connect: null }).catch(() => {});
                return e.reply(message, e.ok('تم فتح رومك 🔓'));
            }
        }
    ]
};
