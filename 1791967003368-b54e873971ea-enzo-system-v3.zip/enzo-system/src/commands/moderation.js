const { ChannelType } = require('discord.js');
const db = require('../utils/db');
const e = require('../utils/embeds');
const r = require('../utils/resolve');
const t = require('../utils/time');
const log = require('../utils/log');
const { guard, caseEmbed, notify } = require('../utils/mod');

const needMember = async (message, arg) => {
    const m = await r.member(message, arg);
    if (!m) {
        await e.reply(message, e.err('منشن العضو أو اكتب الايدي الخاص به.'));
        return null;
    }
    return m;
};

const reasonFrom = (args, from) => args.slice(from).join(' ') || 'بدون سبب';

const textChannel = (message, arg) => {
    const c = r.channel(message, arg);
    return c && c.isTextBased() && c.type !== ChannelType.GuildVoice ? c : message.channel;
};

const rolePosition = async (message, role) => {
    const me = message.guild.members.me;
    const isOwner = message.author.id === message.guild.ownerId;
    if (role.managed || role.id === message.guild.id) {
        await e.reply(message, e.err('هذي الرتبة ما تنعطى ولا تنسحب يدوياً.'));
        return false;
    }
    if (role.position >= me.roles.highest.position) {
        await e.reply(message, e.err('هذي الرتبة أعلى من رتبة البوت.'));
        return false;
    }
    if (!isOwner && role.position >= message.member.roles.highest.position) {
        await e.reply(message, e.err('هذي الرتبة أعلى منك أو تساوي رتبتك.'));
        return false;
    }
    return true;
};

module.exports = {
    category: 'الإدارة',
    icon: '🛡️',
    commands: [
        {
            name: 'حظر',
            aliases: ['باند', 'بان'],
            desc: 'حظر عضو من السيرفر',
            usage: 'حظر @العضو [السبب]',
            perms: ['BanMembers'],
            async run(message, args) {
                const member = await r.member(message, args[0]);
                const user = member ? member.user : await r.user(message.client, args[0]);
                if (!user) return e.reply(message, e.err('منشن العضو أو اكتب الايدي الخاص به.'));
                if (member && !(await guard(message, member))) return;
                const reason = reasonFrom(args, 1);
                await notify(user, message.guild, 'تم حظرك', reason);
                await message.guild.members.ban(user.id, { reason: `${message.author.tag}: ${reason}` })
                    .catch(() => null)
                    .then(res => {
                        if (!res) return e.reply(message, e.err('ما قدرت أحظره، تأكد من صلاحياتي ورتبتي.'));
                        log.send(message.guild, caseEmbed('🔨 حظر عضو', e.colors.err, user, message.author, reason), 'ban');
                        return e.reply(message, caseEmbed('🔨 تم حظر العضو', e.colors.err, user, message.author, reason));
                    });
            }
        },
        {
            name: 'فك_حظر',
            aliases: ['فك_باند', 'الغاء_حظر'],
            desc: 'فك الحظر عن عضو بالايدي',
            usage: 'فك_حظر <ايدي العضو>',
            perms: ['BanMembers'],
            async run(message, args) {
                const user = await r.user(message.client, args[0]);
                if (!user) return e.reply(message, e.err('اكتب ايدي العضو المحظور.'));
                const done = await message.guild.members.unban(user.id, reasonFrom(args, 1)).catch(() => null);
                if (!done) return e.reply(message, e.err('هذا العضو مو محظور أو ما قدرت أفك حظره.'));
                log.send(message.guild, caseEmbed('♻️ فك حظر', e.colors.ok, user, message.author, reasonFrom(args, 1)), 'unban');
                return e.reply(message, caseEmbed('♻️ تم فك الحظر', e.colors.ok, user, message.author, reasonFrom(args, 1)));
            }
        },
        {
            name: 'المحظورين',
            aliases: ['قائمة_الحظر', 'البانات'],
            desc: 'عرض قائمة المحظورين',
            usage: 'المحظورين',
            perms: ['BanMembers'],
            async run(message) {
                const bans = await message.guild.bans.fetch().catch(() => null);
                if (!bans) return e.reply(message, e.err('ما قدرت أجيب قائمة الحظر.'));
                if (!bans.size) return e.reply(message, e.info('🔨 المحظورين', 'ما فيه أحد محظور حالياً.'));
                const list = [...bans.values()].slice(0, 20)
                    .map((b, i) => `**${i + 1}.** ${b.user.tag} \`${b.user.id}\``).join('\n');
                return e.reply(message, e.info(`🔨 المحظورين (${bans.size})`, list));
            }
        },
        {
            name: 'طرد',
            aliases: ['كيك'],
            desc: 'طرد عضو من السيرفر',
            usage: 'طرد @العضو [السبب]',
            perms: ['KickMembers'],
            async run(message, args) {
                const member = await needMember(message, args[0]);
                if (!member || !(await guard(message, member))) return;
                const reason = reasonFrom(args, 1);
                await notify(member.user, message.guild, 'تم طردك', reason);
                const done = await member.kick(`${message.author.tag}: ${reason}`).then(() => true).catch(() => false);
                if (!done) return e.reply(message, e.err('ما قدرت أطرده.'));
                log.send(message.guild, caseEmbed('👢 طرد عضو', e.colors.warn, member.user, message.author, reason), 'kick');
                return e.reply(message, caseEmbed('👢 تم طرد العضو', e.colors.warn, member.user, message.author, reason));
            }
        },
        {
            name: 'اسكات',
            aliases: ['ميوت', 'تايم'],
            desc: 'إسكات عضو لمدة محددة',
            usage: 'اسكات @العضو <المدة 10د / 2س / 1ي> [السبب]',
            perms: ['ModerateMembers'],
            async run(message, args) {
                const member = await needMember(message, args[0]);
                if (!member || !(await guard(message, member))) return;
                const ms = t.parseDuration(args[1]);
                if (!ms || ms > 28 * 86400000) {
                    return e.reply(message, e.err('اكتب مدة صحيحة مثل `10د` أو `2س` أو `1ي` ، الحد الأقصى 28 يوم.'));
                }
                const reason = reasonFrom(args, 2);
                const done = await member.timeout(ms, `${message.author.tag}: ${reason}`).then(() => true).catch(() => false);
                if (!done) return e.reply(message, e.err('ما قدرت أسكته.'));
                await notify(member.user, message.guild, 'تم إسكاتك', `${reason}\nالمدة: ${t.formatDuration(ms)}`);
                const embed = caseEmbed('🔇 تم إسكات العضو', e.colors.warn, member.user, message.author, reason, [
                    { name: '⏱️ المدة', value: t.formatDuration(ms), inline: true }
                ]);
                log.send(message.guild, embed, 'timeout');
                return e.reply(message, embed);
            }
        },
        {
            name: 'فك_اسكات',
            aliases: ['فك_ميوت', 'الغاء_اسكات'],
            desc: 'فك الإسكات عن عضو',
            usage: 'فك_اسكات @العضو',
            perms: ['ModerateMembers'],
            async run(message, args) {
                const member = await needMember(message, args[0]);
                if (!member) return;
                const done = await member.timeout(null).then(() => true).catch(() => false);
                if (!done) return e.reply(message, e.err('ما قدرت أفك الإسكات.'));
                return e.reply(message, caseEmbed('🔊 تم فك الإسكات', e.colors.ok, member.user, message.author, 'فك يدوي'));
            }
        },
        {
            name: 'تحذير',
            aliases: ['انذار', 'وارن'],
            desc: 'إعطاء تحذير لعضو',
            usage: 'تحذير @العضو <السبب>',
            perms: ['ManageMessages'],
            async run(message, args) {
                const member = await needMember(message, args[0]);
                if (!member || !(await guard(message, member))) return;
                const reason = reasonFrom(args, 1);
                const g = db.guild(message.guild.id);
                g.warnCounter += 1;
                if (!g.warns[member.id]) g.warns[member.id] = [];
                g.warns[member.id].push({ id: g.warnCounter, reason, mod: message.author.id, at: Date.now() });
                db.save();
                await notify(member.user, message.guild, 'وصلك تحذير', reason);
                const embed = caseEmbed('⚠️ تم تحذير العضو', e.colors.warn, member.user, message.author, reason, [
                    { name: '🔢 رقم التحذير', value: `#${g.warnCounter}`, inline: true },
                    { name: '📊 مجموع تحذيراته', value: `${g.warns[member.id].length}`, inline: true }
                ]);
                log.send(message.guild, embed, 'warn');
                return e.reply(message, embed);
            }
        },
        {
            name: 'تحذيرات',
            aliases: ['انذارات', 'سجل'],
            desc: 'عرض تحذيرات عضو',
            usage: 'تحذيرات [@العضو]',
            perms: ['ManageMessages'],
            async run(message, args) {
                const member = args[0] ? await needMember(message, args[0]) : message.member;
                if (!member) return;
                const list = db.guild(message.guild.id).warns[member.id] || [];
                if (!list.length) return e.reply(message, e.info('📋 سجل التحذيرات', `${member} نظيف، ما عليه أي تحذير.`));
                const lines = list.slice(-10).map(w =>
                    `**#${w.id}** • ${t.stamp(w.at)} • <@${w.mod}>\n╰ ${w.reason}`
                ).join('\n\n');
                return e.reply(message, e.info(`📋 تحذيرات ${member.displayName} (${list.length})`, lines));
            }
        },
        {
            name: 'حذف_تحذير',
            aliases: ['ازالة_تحذير'],
            desc: 'حذف تحذير برقمه',
            usage: 'حذف_تحذير @العضو <رقم التحذير>',
            perms: ['ManageMessages'],
            async run(message, args) {
                const member = await needMember(message, args[0]);
                if (!member) return;
                const id = Number(t.digits(args[1] || ''));
                const g = db.guild(message.guild.id);
                const list = g.warns[member.id] || [];
                const index = list.findIndex(w => w.id === id);
                if (index === -1) return e.reply(message, e.err('ما لقيت تحذير بهذا الرقم عند العضو.'));
                list.splice(index, 1);
                db.save();
                return e.reply(message, e.ok(`تم حذف التحذير **#${id}** من ${member}`));
            }
        },
        {
            name: 'مسح_تحذيرات',
            aliases: ['تصفير_تحذيرات'],
            desc: 'مسح كل تحذيرات عضو',
            usage: 'مسح_تحذيرات @العضو',
            perms: ['ManageMessages'],
            async run(message, args) {
                const member = await needMember(message, args[0]);
                if (!member) return;
                const g = db.guild(message.guild.id);
                const count = (g.warns[member.id] || []).length;
                delete g.warns[member.id];
                db.save();
                return e.reply(message, e.ok(`تم مسح **${count}** تحذير من ${member}`));
            }
        },
        {
            name: 'مسح',
            aliases: ['تنظيف', 'حذف', 'كلير'],
            desc: 'مسح عدد من الرسائل أو رسائل عضو معين',
            usage: 'مسح <العدد> [@العضو]',
            perms: ['ManageMessages'],
            async run(message, args) {
                const amount = Number(t.digits(args[0] || ''));
                if (!amount || amount < 1 || amount > 100) {
                    return e.reply(message, e.err('اكتب عدد من 1 إلى 100.'));
                }
                const target = args[1] ? await r.member(message, args[1]) : null;
                await message.delete().catch(() => {});
                let list = await message.channel.messages.fetch({ limit: 100 });
                list = [...list.values()];
                if (target) list = list.filter(m => m.author.id === target.id);
                list = list.slice(0, amount);
                const deleted = await message.channel.bulkDelete(list, true).catch(() => null);
                const count = deleted ? deleted.size : 0;
                const sent = await message.channel.send({
                    embeds: [e.ok(`تم مسح **${count}** رسالة${target ? ` من ${target}` : ''}`, '🧹 تنظيف')],
                    ...e.opts
                }).catch(() => null);
                if (sent) setTimeout(() => sent.delete().catch(() => {}), 4000);
            }
        },
        {
            name: 'قفل',
            aliases: ['اقفل'],
            desc: 'قفل الشات عن الأعضاء',
            usage: 'قفل [#الروم]',
            perms: ['ManageChannels'],
            async run(message, args) {
                const channel = textChannel(message, args[0]);
                await channel.permissionOverwrites.edit(message.guild.roles.everyone, { SendMessages: false });
                return e.reply(message, e.ok(`تم قفل ${channel} 🔒`));
            }
        },
        {
            name: 'فتح',
            aliases: ['افتح'],
            desc: 'فتح الشات للأعضاء',
            usage: 'فتح [#الروم]',
            perms: ['ManageChannels'],
            async run(message, args) {
                const channel = textChannel(message, args[0]);
                await channel.permissionOverwrites.edit(message.guild.roles.everyone, { SendMessages: null });
                return e.reply(message, e.ok(`تم فتح ${channel} 🔓`));
            }
        },
        {
            name: 'اخفاء',
            aliases: ['خفي'],
            desc: 'إخفاء الروم عن الأعضاء',
            usage: 'اخفاء [#الروم]',
            perms: ['ManageChannels'],
            async run(message, args) {
                const channel = r.channel(message, args[0]) || message.channel;
                await channel.permissionOverwrites.edit(message.guild.roles.everyone, { ViewChannel: false });
                return e.reply(message, e.ok(`تم إخفاء ${channel} 🙈`));
            }
        },
        {
            name: 'اظهار',
            aliases: ['اظهر'],
            desc: 'إظهار الروم للأعضاء',
            usage: 'اظهار [#الروم]',
            perms: ['ManageChannels'],
            async run(message, args) {
                const channel = r.channel(message, args[0]) || message.channel;
                await channel.permissionOverwrites.edit(message.guild.roles.everyone, { ViewChannel: null });
                return e.reply(message, e.ok(`تم إظهار ${channel} 👀`));
            }
        },
        {
            name: 'قفل_السيرفر',
            aliases: ['قفل_الكل'],
            desc: 'قفل كل الرومات الكتابية',
            usage: 'قفل_السيرفر',
            perms: ['Administrator'],
            async run(message) {
                const channels = message.guild.channels.cache.filter(c => c.type === ChannelType.GuildText);
                let done = 0;
                for (const channel of channels.values()) {
                    const ok = await channel.permissionOverwrites.edit(message.guild.roles.everyone, { SendMessages: false })
                        .then(() => true).catch(() => false);
                    if (ok) done += 1;
                }
                return e.reply(message, e.ok(`تم قفل **${done}** روم 🔒`));
            }
        },
        {
            name: 'فتح_السيرفر',
            aliases: ['فتح_الكل'],
            desc: 'فتح كل الرومات الكتابية',
            usage: 'فتح_السيرفر',
            perms: ['Administrator'],
            async run(message) {
                const channels = message.guild.channels.cache.filter(c => c.type === ChannelType.GuildText);
                let done = 0;
                for (const channel of channels.values()) {
                    const ok = await channel.permissionOverwrites.edit(message.guild.roles.everyone, { SendMessages: null })
                        .then(() => true).catch(() => false);
                    if (ok) done += 1;
                }
                return e.reply(message, e.ok(`تم فتح **${done}** روم 🔓`));
            }
        },
        {
            name: 'بطيء',
            aliases: ['سلو', 'وضع_بطيء'],
            desc: 'تحديد الوضع البطيء للروم',
            usage: 'بطيء <الثواني> (0 للإيقاف)',
            perms: ['ManageChannels'],
            async run(message, args) {
                const seconds = Number(t.digits(args[0] || ''));
                if (Number.isNaN(seconds) || seconds < 0 || seconds > 21600) {
                    return e.reply(message, e.err('اكتب عدد ثواني من 0 إلى 21600.'));
                }
                await message.channel.setRateLimitPerUser(seconds);
                return e.reply(message, e.ok(seconds ? `الوضع البطيء الآن **${seconds}** ثانية 🐢` : 'تم إيقاف الوضع البطيء'));
            }
        },
        {
            name: 'لقب',
            aliases: ['نيك', 'غير_اسم'],
            desc: 'تغيير لقب عضو (بدون لقب لإعادته)',
            usage: 'لقب @العضو [اللقب الجديد]',
            perms: ['ManageNicknames'],
            async run(message, args) {
                const member = await needMember(message, args[0]);
                if (!member || !(await guard(message, member))) return;
                const name = args.slice(1).join(' ') || null;
                const done = await member.setNickname(name).then(() => true).catch(() => false);
                if (!done) return e.reply(message, e.err('ما قدرت أغير اللقب.'));
                return e.reply(message, e.ok(name ? `تم تغيير لقب ${member} إلى **${name}**` : `تمت إعادة لقب ${member}`));
            }
        },
        {
            name: 'اعطاء_رتبة',
            aliases: ['رتبة', 'اعطي'],
            desc: 'إعطاء رتبة لعضو',
            usage: 'اعطاء_رتبة @العضو @الرتبة',
            perms: ['ManageRoles'],
            async run(message, args) {
                const member = await needMember(message, args[0]);
                if (!member) return;
                const role = r.role(message, args.slice(1).join(' '));
                if (!role) return e.reply(message, e.err('منشن الرتبة أو اكتب اسمها.'));
                if (!(await rolePosition(message, role))) return;
                const done = await member.roles.add(role).then(() => true).catch(() => false);
                if (!done) return e.reply(message, e.err('ما قدرت أعطيه الرتبة.'));
                return e.reply(message, e.ok(`تم إعطاء ${member} رتبة ${role}`));
            }
        },
        {
            name: 'سحب_رتبة',
            aliases: ['شيل_رتبة', 'سحب'],
            desc: 'سحب رتبة من عضو',
            usage: 'سحب_رتبة @العضو @الرتبة',
            perms: ['ManageRoles'],
            async run(message, args) {
                const member = await needMember(message, args[0]);
                if (!member) return;
                const role = r.role(message, args.slice(1).join(' '));
                if (!role) return e.reply(message, e.err('منشن الرتبة أو اكتب اسمها.'));
                if (!(await rolePosition(message, role))) return;
                const done = await member.roles.remove(role).then(() => true).catch(() => false);
                if (!done) return e.reply(message, e.err('ما قدرت أسحب الرتبة.'));
                return e.reply(message, e.ok(`تم سحب رتبة ${role} من ${member}`));
            }
        },
        {
            name: 'نقل',
            aliases: ['سحب_للروم', 'مف'],
            desc: 'نقل عضو لروم صوتي',
            usage: 'نقل @العضو [#الروم الصوتي]',
            perms: ['MoveMembers'],
            async run(message, args) {
                const member = await needMember(message, args[0]);
                if (!member) return;
                if (!member.voice.channel) return e.reply(message, e.err('العضو مو داخل روم صوتي.'));
                const target = r.channel(message, args[1]) || message.member.voice.channel;
                if (!target || !target.isVoiceBased()) return e.reply(message, e.err('حدد روم صوتي أو ادخل روم صوتي.'));
                const done = await member.voice.setChannel(target).then(() => true).catch(() => false);
                if (!done) return e.reply(message, e.err('ما قدرت أنقله.'));
                return e.reply(message, e.ok(`تم نقل ${member} إلى ${target}`));
            }
        },
        {
            name: 'فصل',
            aliases: ['اطرد_صوت', 'ديسكونكت'],
            desc: 'فصل عضو من الروم الصوتي',
            usage: 'فصل @العضو',
            perms: ['MoveMembers'],
            async run(message, args) {
                const member = await needMember(message, args[0]);
                if (!member) return;
                if (!member.voice.channel) return e.reply(message, e.err('العضو مو داخل روم صوتي.'));
                const done = await member.voice.disconnect().then(() => true).catch(() => false);
                if (!done) return e.reply(message, e.err('ما قدرت أفصله.'));
                return e.reply(message, e.ok(`تم فصل ${member} من الروم الصوتي`));
            }
        },
        {
            name: 'كتم_صوت',
            aliases: ['ميوت_صوت'],
            desc: 'كتم عضو في الرومات الصوتية',
            usage: 'كتم_صوت @العضو',
            perms: ['MuteMembers'],
            async run(message, args) {
                const member = await needMember(message, args[0]);
                if (!member) return;
                if (!member.voice.channel) return e.reply(message, e.err('العضو مو داخل روم صوتي.'));
                const done = await member.voice.setMute(true).then(() => true).catch(() => false);
                if (!done) return e.reply(message, e.err('ما قدرت أكتمه.'));
                return e.reply(message, e.ok(`تم كتم ${member} 🔇`));
            }
        },
        {
            name: 'فك_كتم_صوت',
            aliases: ['فك_ميوت_صوت'],
            desc: 'فك كتم عضو في الرومات الصوتية',
            usage: 'فك_كتم_صوت @العضو',
            perms: ['MuteMembers'],
            async run(message, args) {
                const member = await needMember(message, args[0]);
                if (!member) return;
                if (!member.voice.channel) return e.reply(message, e.err('العضو مو داخل روم صوتي.'));
                const done = await member.voice.setMute(false).then(() => true).catch(() => false);
                if (!done) return e.reply(message, e.err('ما قدرت أفك الكتم.'));
                return e.reply(message, e.ok(`تم فك كتم ${member} 🔊`));
            }
        },
        {
            name: 'اعادة_روم',
            aliases: ['نيوك', 'تصفير_روم'],
            desc: 'إعادة إنشاء الروم الحالي لمسح كل رسائله',
            usage: 'اعادة_روم',
            perms: ['ManageChannels'],
            async run(message) {
                const old = message.channel;
                const position = old.position;
                const fresh = await old.clone().catch(() => null);
                if (!fresh) return e.reply(message, e.err('ما قدرت أعيد إنشاء الروم.'));
                await old.delete().catch(() => {});
                await fresh.setPosition(position).catch(() => {});
                return fresh.send({ embeds: [e.ok(`تمت إعادة إنشاء الروم بواسطة ${message.author}`, '💥 تصفير الروم')], ...e.opts });
            }
        }
    ]
};
