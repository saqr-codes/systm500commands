const { ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType, MessageFlags } = require('discord.js');
const db = require('../utils/db');
const e = require('../utils/embeds');
const r = require('../utils/resolve');
const t = require('../utils/time');
const backup = require('../utils/backup');

const guardOwner = async message => {
    if (backup.canManage(message.client, message.author.id, message.guild)) return true;
    await e.reply(message, e.err('أوامر النسخ الاحتياطي لمالك البوت فقط، حدده في `OWNERS` داخل ملف `.env`.'));
    return false;
};

const statusEmbed = () => {
    const b = db.meta().backup;
    return e.base(b.enabled ? e.colors.ok : e.colors.warn)
        .setTitle('💾 حالة النسخ الاحتياطي')
        .addFields(
            { name: '🔁 النسخ اليومي', value: b.enabled ? '🟢 مفعل' : '🔴 متوقف', inline: true },
            { name: '📺 روم النسخ', value: b.channelId ? `<#${b.channelId}>` : '`غير محدد`', inline: true },
            { name: '🕐 آخر نسخة', value: b.last ? `${t.stamp(b.last, 'F')}\n${t.stamp(b.last, 'R')}` : 'لا يوجد', inline: false },
            { name: '📦 الحجم', value: b.lastSize ? `${(b.lastSize / 1024).toFixed(1)} KB` : '-', inline: true },
            { name: '⚠️ آخر خطأ', value: b.lastError || 'لا يوجد', inline: true }
        )
        .setFooter({ text: 'النسخة تحتوي كل بيانات السيرفرات + الإضافات، وتنحفظ محلياً في مجلد backups آخر 14 نسخة' });
};

module.exports = {
    category: 'النسخ الاحتياطي',
    icon: '💾',
    commands: [
        {
            name: 'باكب',
            aliases: ['نسخة_احتياطية', 'backup'],
            desc: 'أخذ نسخة احتياطية الآن وإرسالها لروم النسخ',
            usage: 'باكب',
            async run(message) {
                if (!(await guardOwner(message))) return;
                const wait = await e.reply(message, e.info('⏳ جاري النسخ', 'ثواني...'));
                const res = await backup.run(message.client, `يدوي بواسطة ${message.author.tag}`);
                const embed = res.ok
                    ? e.ok(`تم إنشاء النسخة \`${res.name}\` (${(res.size / 1024).toFixed(1)} KB)\n${res.sent ? 'وأرسلت لروم النسخ ✅' : `حفظت محلياً فقط: ${res.note}`}`, '💾 تم النسخ')
                    : e.err(`فشل النسخ: ${res.error}`);
                return wait.edit({ embeds: [embed], ...e.opts }).catch(() => {});
            }
        },
        {
            name: 'باكب_روم',
            aliases: ['روم_النسخ', 'backup_room'],
            desc: 'تحديد الروم اللي ترسل له النسخة اليومية (اكتب "حذف" للإلغاء)',
            usage: 'باكب_روم #الروم',
            async run(message, args) {
                if (!(await guardOwner(message))) return;
                const b = db.meta().backup;
                if (['حذف', 'الغاء', 'ايقاف'].includes(args[0])) {
                    b.channelId = null;
                    db.save();
                    return e.reply(message, e.ok('تم إلغاء روم النسخ، النسخ تنحفظ محلياً فقط'));
                }
                const channel = r.channel(message, args[0]);
                if (!channel || !channel.isTextBased() || channel.isVoiceBased()) {
                    return e.reply(message, e.err('منشن روم كتابي، أو اكتب `باكب_روم حذف` للإلغاء.\nنصيحة: خله روم خاص بالإدارة فقط لأن النسخة فيها كل بيانات البوت.'));
                }
                const me = message.guild.members.me;
                if (!channel.permissionsFor(me)?.has(['ViewChannel', 'SendMessages', 'AttachFiles'])) {
                    return e.reply(message, e.err('ما عندي صلاحية إرسال الملفات في هذا الروم.'));
                }
                b.channelId = channel.id;
                db.save();
                return e.reply(message, e.ok(`راح ترسل النسخة اليومية إلى ${channel}\nاكتب \`باكب\` الحين لتجربة الإرسال.`));
            }
        },
        {
            name: 'باكب_يومي',
            aliases: ['نسخ_يومي'],
            desc: 'تشغيل أو إيقاف النسخ الاحتياطي اليومي',
            usage: 'باكب_يومي <تشغيل | ايقاف>',
            async run(message, args) {
                if (!(await guardOwner(message))) return;
                const b = db.meta().backup;
                const wanted = { 'تشغيل': true, 'فتح': true, 'ايقاف': false, 'قفل': false }[args[0]];
                b.enabled = wanted === undefined ? !b.enabled : wanted;
                db.save();
                return e.reply(message, e.ok(b.enabled ? 'تم تشغيل النسخ الاحتياطي اليومي 🟢' : 'تم إيقاف النسخ الاحتياطي اليومي 🔴'));
            }
        },
        {
            name: 'باكب_حالة',
            aliases: ['حالة_النسخ'],
            desc: 'عرض حالة النسخ الاحتياطي',
            usage: 'باكب_حالة',
            async run(message) {
                if (!(await guardOwner(message))) return;
                return e.reply(message, statusEmbed());
            }
        },
        {
            name: 'استعادة',
            aliases: ['استرجاع', 'restore'],
            desc: 'استعادة كل البيانات من ملف نسخة احتياطية (أرفق الملف أو رد عليه)',
            usage: 'استعادة',
            async run(message) {
                if (!(await guardOwner(message))) return;
                let attachment = message.attachments.first();
                if (!attachment && message.reference?.messageId) {
                    const ref = await message.channel.messages.fetch(message.reference.messageId).catch(() => null);
                    attachment = ref?.attachments.first();
                }
                if (!attachment || !/\.json(\.gz)?$/i.test(attachment.name || '')) {
                    return e.reply(message, e.err('أرفق ملف النسخة (`.json.gz`) مع الأمر، أو رد على رسالة النسخة بالأمر.'));
                }
                if (attachment.size > 50 * 1024 * 1024) return e.reply(message, e.err('الملف كبير جداً.'));

                const row = disabled => new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('restore:yes').setLabel('تأكيد الاستعادة').setEmoji('♻️').setStyle(ButtonStyle.Danger).setDisabled(disabled),
                    new ButtonBuilder().setCustomId('restore:no').setLabel('إلغاء').setStyle(ButtonStyle.Secondary).setDisabled(disabled)
                );
                const sent = await e.reply(message, e.warn(
                    `راح **تُستبدل كل بيانات البوت الحالية** بمحتوى الملف \`${attachment.name}\`.\nتنأخذ نسخة أمان من البيانات الحالية قبل الاستبدال.\n\nتأكيد؟`,
                    '♻️ تأكيد الاستعادة'
                ), { components: [row(false)] });

                const collector = sent.createMessageComponentCollector({ componentType: ComponentType.Button, time: 60000 });
                collector.on('collect', async i => {
                    if (i.user.id !== message.author.id) {
                        return i.reply({ embeds: [e.err('هذا الزر مو لك.')], flags: MessageFlags.Ephemeral });
                    }
                    collector.stop('done');
                    if (i.customId === 'restore:no') return i.update({ embeds: [e.info('❎ تم الإلغاء', 'ما تغيرت أي بيانات.')], components: [] });
                    await i.deferUpdate();
                    try {
                        const res = await fetch(attachment.url);
                        if (!res.ok) throw new Error('تعذر تحميل الملف');
                        const info = backup.restore(Buffer.from(await res.arrayBuffer()));
                        await sent.edit({ embeds: [e.ok(`تمت الاستعادة بنجاح ✅\n🏰 عدد السيرفرات في النسخة: **${info.guilds}**${info.createdAt ? `\n🕐 تاريخ النسخة: ${t.stamp(info.createdAt, 'F')}` : ''}`, '♻️ تمت الاستعادة')], components: [] });
                    } catch (err) {
                        await sent.edit({ embeds: [e.err(`فشلت الاستعادة: ${err.message}\nما تغيرت أي بيانات.`)], components: [] });
                    }
                });
                collector.on('end', (_, reason) => {
                    if (reason === 'time') sent.edit({ components: [row(true)] }).catch(() => {});
                });
            }
        }
    ]
};
