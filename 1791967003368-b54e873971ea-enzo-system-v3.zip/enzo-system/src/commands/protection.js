const db = require('../utils/db');
const e = require('../utils/embeds');
const r = require('../utils/resolve');

const types = [
    { key: 'links', name: 'الروابط', command: 'حماية_روابط', alias: ['منع_الروابط'], desc: 'حذف أي رابط يرسله الأعضاء' },
    { key: 'invites', name: 'الدعوات', command: 'حماية_دعوات', alias: ['منع_الدعوات'], desc: 'حذف روابط دعوات ديسكورد' },
    { key: 'spam', name: 'السبام', command: 'حماية_سبام', alias: ['منع_السبام'], desc: 'إسكات من يرسل رسائل متتابعة بسرعة' },
    { key: 'mentions', name: 'المنشن', command: 'حماية_منشن', alias: ['منع_المنشن'], desc: 'منع الإكثار من المنشن' },
    { key: 'badwords', name: 'الكلمات الممنوعة', command: 'حماية_كلمات', alias: ['منع_الكلمات'], desc: 'حذف الرسائل اللي فيها كلمات ممنوعة' },
    { key: 'raid', name: 'الريد', command: 'حماية_ريد', alias: ['منع_الريد'], desc: 'طرد من يدخل بشكل جماعي مفاجئ' }
];

const states = {
    'تشغيل': true, 'فتح': true, 'on': true, 'شغل': true,
    'ايقاف': false, 'اطفاء': false, 'off': false, 'قفل': false, 'اقفل': false
};

const toggle = type => ({
    name: type.command,
    aliases: type.alias,
    desc: `تشغيل أو إيقاف حماية ${type.name}`,
    usage: `${type.command} <تشغيل | ايقاف>`,
    perms: ['Administrator'],
    async run(message, args) {
        const p = db.guild(message.guild.id).protection;
        const wanted = states[(args[0] || '').toLowerCase()];
        p[type.key] = wanted === undefined ? !p[type.key] : wanted;
        db.save();
        const state = p[type.key];
        return e.reply(message, e.base(state ? e.colors.ok : e.colors.err)
            .setTitle(`🛡️ حماية ${type.name}`)
            .setDescription(`${type.desc}\n\nالحالة: ${state ? '🟢 **مفعلة**' : '🔴 **متوقفة**'}`));
    }
});

module.exports = {
    category: 'الحماية',
    icon: '🔒',
    commands: [
        {
            name: 'حماية',
            aliases: ['الحماية', 'حالة_الحماية'],
            desc: 'عرض حالة جميع أنظمة الحماية',
            usage: 'حماية',
            perms: ['Administrator'],
            async run(message) {
                const p = db.guild(message.guild.id).protection;
                const lines = types.map(x => `${p[x.key] ? '🟢' : '🔴'} **${x.name}** • \`${x.command}\``).join('\n');
                const embed = e.base()
                    .setTitle('🛡️ لوحة الحماية')
                    .setDescription(`${lines}\n\n🚫 الكلمات الممنوعة: **${p.words.length}**\n✅ المستثنين: **${p.users.length + p.roles.length}**`)
                    .setThumbnail(message.guild.iconURL({ size: 256 }));
                return e.reply(message, embed);
            }
        },
        ...types.map(toggle),
        {
            name: 'حماية_تشغيل_الكل',
            aliases: ['فعل_الحماية'],
            desc: 'تشغيل كل أنظمة الحماية',
            usage: 'حماية_تشغيل_الكل',
            perms: ['Administrator'],
            async run(message) {
                const p = db.guild(message.guild.id).protection;
                types.forEach(x => { p[x.key] = true; });
                db.save();
                return e.reply(message, e.ok('تم تفعيل كل أنظمة الحماية 🛡️'));
            }
        },
        {
            name: 'حماية_ايقاف_الكل',
            aliases: ['عطل_الحماية'],
            desc: 'إيقاف كل أنظمة الحماية',
            usage: 'حماية_ايقاف_الكل',
            perms: ['Administrator'],
            async run(message) {
                const p = db.guild(message.guild.id).protection;
                types.forEach(x => { p[x.key] = false; });
                db.save();
                return e.reply(message, e.ok('تم إيقاف كل أنظمة الحماية'));
            }
        },
        {
            name: 'اضافة_كلمة',
            aliases: ['منع_كلمة'],
            desc: 'إضافة كلمة للكلمات الممنوعة',
            usage: 'اضافة_كلمة <الكلمة>',
            perms: ['Administrator'],
            async run(message, args) {
                const word = args.join(' ').toLowerCase();
                if (!word) return e.reply(message, e.err('اكتب الكلمة.'));
                const p = db.guild(message.guild.id).protection;
                if (p.words.includes(word)) return e.reply(message, e.err('الكلمة موجودة بالفعل.'));
                p.words.push(word);
                db.save();
                await message.delete().catch(() => {});
                return e.temp(message, e.ok('تمت إضافة الكلمة للقائمة الممنوعة.'), 4);
            }
        },
        {
            name: 'حذف_كلمة',
            aliases: ['سماح_كلمة'],
            desc: 'حذف كلمة من القائمة الممنوعة',
            usage: 'حذف_كلمة <الكلمة>',
            perms: ['Administrator'],
            async run(message, args) {
                const word = args.join(' ').toLowerCase();
                const p = db.guild(message.guild.id).protection;
                const index = p.words.indexOf(word);
                if (index === -1) return e.reply(message, e.err('الكلمة مو موجودة في القائمة.'));
                p.words.splice(index, 1);
                db.save();
                return e.reply(message, e.ok('تم حذف الكلمة من القائمة الممنوعة.'));
            }
        },
        {
            name: 'الكلمات',
            aliases: ['الكلمات_الممنوعة'],
            desc: 'عرض عدد الكلمات الممنوعة',
            usage: 'الكلمات',
            perms: ['Administrator'],
            async run(message) {
                const p = db.guild(message.guild.id).protection;
                return e.reply(message, e.info('🚫 الكلمات الممنوعة', `عدد الكلمات المسجلة: **${p.words.length}**\nلأمانك ما تنعرض الكلمات هنا، تقدر تضيف وتحذف بالأوامر.`));
            }
        },
        {
            name: 'استثناء',
            aliases: ['استثناء_عضو', 'استثناء_رتبة'],
            desc: 'استثناء عضو أو رتبة من الحماية (مرة ثانية يلغي الاستثناء)',
            usage: 'استثناء @العضو أو @الرتبة',
            perms: ['Administrator'],
            async run(message, args) {
                const p = db.guild(message.guild.id).protection;
                const role = r.role(message, args.join(' '));
                const member = role ? null : await r.member(message, args[0]);
                if (!role && !member) return e.reply(message, e.err('منشن عضو أو رتبة.'));
                const list = role ? p.roles : p.users;
                const id = role ? role.id : member.id;
                const index = list.indexOf(id);
                if (index === -1) list.push(id); else list.splice(index, 1);
                db.save();
                return e.reply(message, e.ok(`${role || member} ${index === -1 ? 'تم استثناؤه من الحماية' : 'تمت إزالة استثنائه'}`));
            }
        },
        {
            name: 'المستثنين',
            aliases: ['قائمة_الاستثناء'],
            desc: 'عرض قائمة المستثنين من الحماية',
            usage: 'المستثنين',
            perms: ['Administrator'],
            async run(message) {
                const p = db.guild(message.guild.id).protection;
                const users = p.users.map(id => `<@${id}>`);
                const roles = p.roles.map(id => `<@&${id}>`);
                if (!users.length && !roles.length) return e.reply(message, e.info('✅ المستثنين', 'ما فيه مستثنين.'));
                return e.reply(message, e.info('✅ المستثنين', `**الأعضاء:** ${users.join(' ') || 'لا يوجد'}\n**الرتب:** ${roles.join(' ') || 'لا يوجد'}`));
            }
        }
    ]
};
