const db = require('../utils/db');
const e = require('../utils/embeds');
const r = require('../utils/resolve');
const t = require('../utils/time');
const config = require('../../config');

const answers = [
    'اكيد 💯', 'نعم', 'مؤكد', 'على الأغلب نعم', 'الأمور تبشر بالخير',
    'مو متأكد، اسأل مرة ثانية', 'ركز واسأل بعدين', 'لا أنصحك',
    'لا', 'مستحيل', 'الأغلب لا', 'ما أتوقع'
];

const wisdom = [
    'من جدّ وجد ومن زرع حصد.',
    'الوقت كالسيف إن لم تقطعه قطعك.',
    'اللي ما يعرف الصقر يشويه.',
    'الصديق وقت الضيق.',
    'العلم في الصغر كالنقش على الحجر.',
    'خير الكلام ما قل ودل.',
    'من صبر ظفر.',
    'الوحدة خير من جليس السوء.',
    'اللي يبي العسل يصبر على قرص النحل.',
    'القناعة كنز لا يفنى.'
];

const jokes = [
    'واحد راح للدكتور قال له: كل ما أشرب قهوة أحس بألم في عيني، قال له: جرب تشيل الملعقة من الكوب.',
    'مرة واحد غبي اشترى ساعة، قالوا له ليش؟ قال: عشان أعرف كم الوقت الضايع.',
    'واحد سأل صاحبه: ليش تنام والنافذة مفتوحة؟ قال: عشان الحلم يدخل بسرعة.',
    'قال المدرس: من يعطيني جملة فيها كلمة "لأن"؟ قال طالب: أنا ما سويت الواجب لأن.',
    'واحد بخيل ما يشرب شاي لأن الكوب يكلف ماء.'
];

const questions = [
    'لو خيروك: تعيش بالماضي أو بالمستقبل؟',
    'لو خيروك: تفقد جوالك أسبوع أو تفقد النوم ليلة؟',
    'لو خيروك: تكون غني ومشغول أو متوسط وعندك وقت؟',
    'لو خيروك: تسافر لأي مكان أو تتعلم أي مهارة؟',
    'لو خيروك: تعرف متى تموت أو كيف تموت؟',
    'لو خيروك: تقرأ الأفكار أو تختفي متى ما تبي؟',
    'لو خيروك: صديق واحد وفي أو عشرة معارف؟',
    'لو خيروك: تاكل أكلة وحدة طول عمرك أو ما تاكل المفضلة أبداً؟'
];

const rps = { 'حجر': '🪨', 'ورقة': '📄', 'مقص': '✂️' };
const beats = { 'حجر': 'مقص', 'ورقة': 'حجر', 'مقص': 'ورقة' };

const words = [
    'مستشفى', 'مدرسة', 'سيارة', 'طائرة', 'حاسوب', 'مكتبة', 'برمجة', 'سيرفر', 'شجرة', 'صحراء',
    'مطعم', 'حديقة', 'كهرباء', 'تلفاز', 'ساعة', 'شمس', 'قمر', 'نجمة', 'بحر', 'جبل'
];

const race = async (message, prompt, answer, seconds, reward) => {
    const intro = e.base(e.colors.info).setTitle('⚡ تحدي السرعة').setDescription(`${prompt}\n\nعندكم **${seconds}** ثانية`);
    await e.reply(message, intro);
    const filter = m => !m.author.bot && m.content.trim().toLowerCase() === answer.toLowerCase();
    const got = await message.channel.awaitMessages({ filter, max: 1, time: seconds * 1000 });
    const winner = got.first();
    if (!winner) return e.send(message.channel, e.err(`انتهى الوقت! الإجابة كانت **${answer}**`));
    db.user(message.guild.id, winner.author.id).cash += reward;
    db.save();
    return e.send(message.channel, e.ok(`${winner.author} أجاب أول وكسب **${reward}** ${config.coin}`, '🏆 فائز'));
};

module.exports = {
    category: 'الترفيه',
    icon: '🎮',
    commands: [
        {
            name: 'نرد',
            aliases: ['زهر', 'رمي_نرد'],
            desc: 'رمي النرد',
            usage: 'نرد [عدد الأوجه]',
            async run(message, args) {
                const sides = Math.min(1000, Math.max(2, Number(t.digits(args[0] || '6')) || 6));
                return e.reply(message, e.info('🎲 النرد', `طلع لك **${t.rand(1, sides)}** من ${sides}`));
            }
        },
        {
            name: 'عملة',
            aliases: ['ملك_او_كتابة', 'قلب_عملة'],
            desc: 'رمي عملة',
            usage: 'عملة',
            async run(message) {
                return e.reply(message, e.info('🪙 العملة', `طلعت **${Math.random() < 0.5 ? 'صورة' : 'كتابة'}**`));
            }
        },
        {
            name: 'كرة',
            aliases: ['سؤال_الكرة', 'الكرة_السحرية'],
            desc: 'اسأل الكرة السحرية',
            usage: 'كرة <سؤالك>',
            async run(message, args) {
                if (!args.length) return e.reply(message, e.err('اكتب سؤالك.'));
                return e.reply(message, e.base().setTitle('🔮 الكرة السحرية').addFields(
                    { name: '❓ السؤال', value: args.join(' '), inline: false },
                    { name: '💬 الجواب', value: t.pick(answers), inline: false }
                ));
            }
        },
        {
            name: 'اختر',
            aliases: ['اختار', 'خيار'],
            desc: 'اختيار عشوائي بين خيارات مفصولة بـ |',
            usage: 'اختر شاي | قهوة | عصير',
            async run(message, args) {
                const options = args.join(' ').split('|').map(s => s.trim()).filter(Boolean);
                if (options.length < 2) return e.reply(message, e.err('اكتب خيارين على الأقل مفصولة بـ `|`'));
                return e.reply(message, e.info('🤔 اختياري', `أنا اخترت: **${t.pick(options)}**`));
            }
        },
        {
            name: 'حجر',
            aliases: ['ورقة', 'مقص', 'حجر_ورقة_مقص'],
            desc: 'العب حجر ورقة مقص ضد البوت',
            usage: 'حجر | ورقة | مقص',
            async run(message, args, ctx) {
                const pick = rps[ctx.used] ? ctx.used : (rps[args[0]] ? args[0] : null);
                if (!pick) return e.reply(message, e.err('اختر: `حجر` أو `ورقة` أو `مقص` مثال: `حجر_ورقة_مقص حجر`'));
                const bot = t.pick(Object.keys(rps));
                const result = pick === bot ? 'تعادل 🤝' : beats[pick] === bot ? 'فزت 🎉' : 'خسرت 💔';
                return e.reply(message, e.base().setTitle('✊ حجر ورقة مقص').setDescription(`أنت: ${rps[pick]} **${pick}**\nأنا: ${rps[bot]} **${bot}**\n\n## ${result}`));
            }
        },
        {
            name: 'حب',
            aliases: ['نسبة_الحب', 'لوف'],
            desc: 'نسبة الحب بين شخصين',
            usage: 'حب @العضو',
            async run(message, args) {
                const member = await r.member(message, args[0]);
                if (!member) return e.reply(message, e.err('منشن العضو.'));
                const seed = [message.author.id, member.id].sort().join('');
                let hash = 0;
                for (const ch of seed) hash = (hash * 31 + ch.charCodeAt(0)) % 101;
                return e.reply(message, e.base(0xe91e63).setTitle('💘 مقياس الحب')
                    .setDescription(`${message.author} ❤️ ${member}\n\n${t.bar(hash, 100, 14)} **${hash}%**`));
            }
        },
        {
            name: 'عكس',
            aliases: ['اعكس'],
            desc: 'عكس نص',
            usage: 'عكس <النص>',
            async run(message, args) {
                const text = args.join(' ');
                if (!text) return e.reply(message, e.err('اكتب النص.'));
                return e.reply(message, e.info('🔁 النص المعكوس', [...text].reverse().join('')));
            }
        },
        {
            name: 'حكمة',
            aliases: ['قول'],
            desc: 'حكمة عشوائية',
            usage: 'حكمة',
            async run(message) {
                return e.reply(message, e.info('📜 حكمة', `> ${t.pick(wisdom)}`));
            }
        },
        {
            name: 'نكتة',
            aliases: ['اضحكني'],
            desc: 'نكتة عشوائية',
            usage: 'نكتة',
            async run(message) {
                return e.reply(message, e.info('😂 نكتة', t.pick(jokes)));
            }
        },
        {
            name: 'خيروك',
            aliases: ['لو_خيروك', 'سؤال'],
            desc: 'سؤال لو خيروك',
            usage: 'خيروك',
            async run(message) {
                const sent = await e.reply(message, e.base(e.colors.info).setTitle('🤷 لو خيروك').setDescription(t.pick(questions)));
                await sent.react('1️⃣').catch(() => {});
                await sent.react('2️⃣').catch(() => {});
            }
        },
        {
            name: 'سرعة',
            aliases: ['اسرع_كتابة', 'كتابة_سريعة', 'تحدي'],
            desc: 'أول من يكتب الكلمة يفوز بجائزة',
            usage: 'سرعة',
            async run(message) {
                const word = t.pick(words);
                return race(message, `اكتب الكلمة التالية بأسرع ما تقدر:\n## ${word}`, word, 15, 150);
            }
        },
        {
            name: 'حساب',
            aliases: ['رياضيات', 'مسألة'],
            desc: 'أول من يحل المسألة يفوز بجائزة',
            usage: 'حساب',
            async run(message) {
                const a = t.rand(10, 99);
                const b = t.rand(2, 20);
                const op = t.pick(['+', '-', '×']);
                const answer = op === '+' ? a + b : op === '-' ? a - b : a * b;
                return race(message, `احسب الناتج:\n## ${a} ${op} ${b}`, String(answer), 20, 200);
            }
        },
        {
            name: 'تخمين',
            aliases: ['خمن', 'خمن_الرقم'],
            desc: 'خمن الرقم من 1 إلى 50 خلال 6 محاولات',
            usage: 'تخمين',
            async run(message) {
                const secret = t.rand(1, 50);
                await e.reply(message, e.info('🔢 خمن الرقم', 'فكرت برقم من **1** إلى **50**\nعندك **6** محاولات، اكتب تخمينك في الشات'));
                let tries = 6;
                const filter = m => m.author.id === message.author.id && /^\d+$/.test(t.digits(m.content.trim()));
                const collector = message.channel.createMessageCollector({ filter, time: 60000 });
                collector.on('collect', async m => {
                    const guess = Number(t.digits(m.content.trim()));
                    tries -= 1;
                    if (guess === secret) {
                        collector.stop('win');
                        db.user(message.guild.id, message.author.id).cash += 250;
                        db.save();
                        return e.reply(m, e.ok(`صح! الرقم هو **${secret}** وكسبت **250** ${config.coin}`, '🎉 فزت'));
                    }
                    if (tries <= 0) {
                        collector.stop('lose');
                        return e.reply(m, e.err(`خلصت محاولاتك، الرقم كان **${secret}**`));
                    }
                    return e.reply(m, e.warn(`الرقم ${guess < secret ? 'أكبر' : 'أصغر'} من تخمينك • باقي **${tries}** محاولات`));
                });
                collector.on('end', (_, reason) => {
                    if (reason === 'time') e.send(message.channel, e.err(`انتهى الوقت، الرقم كان **${secret}**`)).catch(() => {});
                });
            }
        },
        {
            name: 'حرف',
            aliases: ['حرف_عشوائي', 'اعطني_حرف'],
            desc: 'يختار لك حرف عشوائي من الأبجدية العربية',
            usage: 'حرف',
            async run(message) {
                const letters = 'أبتثجحخدذرزسشصضطظعغفقكلمنهوي';
                return e.reply(message, e.info('🔤 حرف عشوائي', `## ${t.pick([...letters])}`));
            }
        }
    ]
};
