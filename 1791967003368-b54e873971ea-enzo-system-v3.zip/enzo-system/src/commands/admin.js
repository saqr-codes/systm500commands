const db = require('../utils/db');
const e = require('../utils/embeds');
const r = require('../utils/resolve');
const { isBotOwner } = require('../utils/owner');

const owner = message => isBotOwner(message.client, message.author.id, message.guild);

module.exports = {
    category: 'الإدارة العامة',
    icon: '👑',
    commands: [
        {
            name: 'قل',
            aliases: ['كرر', 'تكلم'],
            desc: 'البوت يرسل رسالتك',
            usage: 'قل <النص>',
            perms: ['ManageMessages'],
            async run(message, args) {
                const text = args.join(' ');
                if (!text) return e.reply(message, e.err('اكتب النص.'));
                await message.delete().catch(() => {});
                return message.channel.send({ content: text, allowedMentions: { parse: [] } });
            }
        },
        {
            name: 'امبد',
            aliases: ['ارسل_امبد'],
            desc: 'إرسال رسالة امبد: العنوان | النص',
            usage: 'امبد <العنوان> | <النص>',
            perms: ['ManageMessages'],
            async run(message, args) {
                const [title, ...rest] = args.join(' ').split('|').map(s => s.trim());
                const body = rest.join('|').trim();
                if (!title) return e.reply(message, e.err('الاستخدام: `امبد العنوان | النص`'));
                const embed = e.base().setTitle(body ? title : null).setDescription(body || title);
                const image = message.attachments.first();
                if (image) embed.setImage(image.url);
                await message.delete().catch(() => {});
                return e.send(message.channel, embed);
            }
        },
        {
            name: 'اعلان',
            aliases: ['اعلن', 'بث'],
            desc: 'إرسال إعلان مع منشن @everyone',
            usage: 'اعلان <النص>',
            perms: ['MentionEveryone'],
            async run(message, args) {
                const text = args.join(' ');
                if (!text) return e.reply(message, e.err('اكتب نص الإعلان.'));
                await message.delete().catch(() => {});
                const embed = e.base(e.colors.gold)
                    .setTitle('📢 إعلان')
                    .setDescription(text)
                    .setAuthor({ name: message.guild.name, iconURL: message.guild.iconURL() || undefined });
                return message.channel.send({ content: '@everyone', embeds: [embed], allowedMentions: { parse: ['everyone'] } });
            }
        },
        {
            name: 'خاص',
            aliases: ['رسالة_خاصة', 'دم'],
            desc: 'إرسال رسالة خاصة لعضو من البوت',
            usage: 'خاص @العضو <الرسالة>',
            perms: ['Administrator'],
            async run(message, args) {
                const member = await r.member(message, args[0]);
                const text = args.slice(1).join(' ');
                if (!member || !text) return e.reply(message, e.err('الاستخدام: `خاص @العضو الرسالة`'));
                const embed = e.base().setTitle(`📨 رسالة من ${message.guild.name}`).setDescription(text);
                const done = await member.send({ embeds: [embed] }).then(() => true).catch(() => false);
                if (!done) return e.reply(message, e.err('العضو مقفل الخاص.'));
                return e.reply(message, e.ok(`تم إرسال الرسالة إلى ${member}`));
            }
        },
        {
            name: 'انشاء_رتبة',
            aliases: ['رتبة_جديدة'],
            desc: 'إنشاء رتبة جديدة',
            usage: 'انشاء_رتبة <الاسم> [#اللون]',
            perms: ['ManageRoles'],
            async run(message, args) {
                const color = /^#?[0-9a-f]{6}$/i.test(args[args.length - 1] || '') ? args.pop().replace('#', '') : null;
                const name = args.join(' ');
                if (!name) return e.reply(message, e.err('اكتب اسم الرتبة.'));
                const role = await message.guild.roles.create({ name, color: color ? parseInt(color, 16) : undefined }).catch(() => null);
                if (!role) return e.reply(message, e.err('ما قدرت أنشئ الرتبة.'));
                return e.reply(message, e.ok(`تم إنشاء الرتبة ${role}`));
            }
        },
        {
            name: 'حذف_رتبة',
            aliases: ['امسح_رتبة'],
            desc: 'حذف رتبة',
            usage: 'حذف_رتبة @الرتبة',
            perms: ['ManageRoles'],
            async run(message, args) {
                const role = r.role(message, args.join(' '));
                if (!role) return e.reply(message, e.err('منشن الرتبة أو اكتب اسمها.'));
                if (role.position >= message.guild.members.me.roles.highest.position) return e.reply(message, e.err('الرتبة أعلى من رتبة البوت.'));
                const name = role.name;
                const done = await role.delete().then(() => true).catch(() => false);
                if (!done) return e.reply(message, e.err('ما قدرت أحذف الرتبة.'));
                return e.reply(message, e.ok(`تم حذف الرتبة **${name}**`));
            }
        },
        {
            name: 'انشاء_روم',
            aliases: ['روم_جديد'],
            desc: 'إنشاء روم كتابي جديد',
            usage: 'انشاء_روم <الاسم>',
            perms: ['ManageChannels'],
            async run(message, args) {
                const name = args.join('-').slice(0, 90);
                if (!name) return e.reply(message, e.err('اكتب اسم الروم.'));
                const channel = await message.guild.channels.create({ name }).catch(() => null);
                if (!channel) return e.reply(message, e.err('ما قدرت أنشئ الروم.'));
                return e.reply(message, e.ok(`تم إنشاء ${channel}`));
            }
        },
        {
            name: 'حذف_روم',
            aliases: ['امسح_روم'],
            desc: 'حذف روم',
            usage: 'حذف_روم #الروم',
            perms: ['ManageChannels'],
            async run(message, args) {
                const channel = r.channel(message, args[0]);
                if (!channel) return e.reply(message, e.err('منشن الروم.'));
                const name = channel.name;
                const done = await channel.delete().then(() => true).catch(() => false);
                if (channel.id === message.channel.id) return;
                if (!done) return e.reply(message, e.err('ما قدرت أحذف الروم.'));
                return e.reply(message, e.ok(`تم حذف الروم **${name}**`));
            }
        },
        {
            name: 'اسم_البوت',
            aliases: ['غير_اسم_البوت'],
            desc: 'تغيير اسم البوت (لمالك البوت)',
            usage: 'اسم_البوت <الاسم>',
            async run(message, args) {
                if (!owner(message)) return e.reply(message, e.err('هذا الأمر لمالك البوت فقط، حدده في `OWNERS` داخل ملف `.env`.'));
                const name = args.join(' ').slice(0, 32);
                if (!name) return e.reply(message, e.err('اكتب الاسم الجديد.'));
                const done = await message.client.user.setUsername(name).then(() => true).catch(() => false);
                if (!done) return e.reply(message, e.err('ما قدرت أغير الاسم، ديسكورد يحدد عدد مرات التغيير.'));
                return e.reply(message, e.ok(`تم تغيير اسم البوت إلى **${name}**`));
            }
        },
        {
            name: 'صورة_البوت',
            aliases: ['غير_صورة_البوت'],
            desc: 'تغيير صورة البوت (للمالك)',
            usage: 'صورة_البوت <رابط الصورة>',
            async run(message, args) {
                if (!owner(message)) return e.reply(message, e.err('هذا الأمر لمالك البوت فقط، حدده في `OWNERS` داخل ملف `.env`.'));
                const url = args[0] || message.attachments.first()?.url;
                if (!url) return e.reply(message, e.err('ارسل رابط صورة أو أرفقها.'));
                const done = await message.client.user.setAvatar(url).then(() => true).catch(() => false);
                if (!done) return e.reply(message, e.err('ما قدرت أغير الصورة.'));
                return e.reply(message, e.ok('تم تغيير صورة البوت'));
            }
        },
        {
            name: 'اطفاء',
            aliases: ['ايقاف_البوت'],
            desc: 'إيقاف البوت (لمالك البوت فقط)',
            usage: 'اطفاء',
            async run(message) {
                if (!owner(message)) return e.reply(message, e.err('هذا الأمر لمالك البوت فقط، حدده في `OWNERS` داخل ملف `.env`.'));
                await e.reply(message, e.warn('جاري إيقاف البوت...'));
                db.flush();
                process.exit(0);
            }
        }
    ]
};
