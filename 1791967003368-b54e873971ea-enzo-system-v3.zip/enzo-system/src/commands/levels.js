const db = require('../utils/db');
const e = require('../utils/embeds');
const r = require('../utils/resolve');
const t = require('../utils/time');
const xp = require('../utils/xp');

const medals = ['🥇', '🥈', '🥉'];

const board = (message, key, format) => {
    const top = Object.entries(db.users(message.guild.id))
        .filter(([, u]) => u[key] > 0)
        .sort((a, b) => b[1][key] - a[1][key])
        .slice(0, 10);
    if (!top.length) return null;
    return top.map(([id, u], i) => `${medals[i] || `**${i + 1}.**`} <@${id}> • ${format(u)}`).join('\n');
};

const hours = seconds => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    return h ? `${h} ساعة و ${m} دقيقة` : `${m} دقيقة`;
};

const pickMember = async (message, args) => {
    const member = args[0] ? await r.member(message, args[0]) : message.member;
    if (!member) await e.reply(message, e.err('ما لقيت العضو.'));
    return member;
};

module.exports = {
    category: 'المستويات والنشاط',
    icon: '📈',
    commands: [
        {
            name: 'لفل',
            aliases: ['مستوى', 'رانك', 'مستواي'],
            desc: 'عرض مستواك وخبرتك',
            usage: 'لفل [@العضو]',
            async run(message, args) {
                const member = await pickMember(message, args);
                if (!member) return;
                const p = db.user(message.guild.id, member.id);
                const ranking = Object.entries(db.users(message.guild.id))
                    .sort((a, b) => (b[1].level - a[1].level) || (b[1].xp - a[1].xp));
                const rank = ranking.findIndex(([id]) => id === member.id) + 1;
                const need = xp.need(p.level);
                const embed = e.base()
                    .setTitle(`📈 مستوى ${member.displayName}`)
                    .setThumbnail(member.displayAvatarURL({ size: 256 }))
                    .addFields(
                        { name: '⭐ المستوى', value: `${p.level}`, inline: true },
                        { name: '🏆 الترتيب', value: `#${rank || '-'}`, inline: true },
                        { name: '💬 الرسائل', value: t.num(p.messages), inline: true },
                        { name: '✨ الخبرة', value: `${t.bar(p.xp, need, 14)}\n\`${p.xp} / ${need}\``, inline: false }
                    );
                return e.reply(message, embed);
            }
        },
        {
            name: 'توب',
            aliases: ['المتصدرين', 'توب_لفل'],
            desc: 'أعلى الأعضاء مستوى',
            usage: 'توب',
            async run(message) {
                const top = Object.entries(db.users(message.guild.id))
                    .filter(([, u]) => u.level > 0 || u.xp > 0)
                    .sort((a, b) => (b[1].level - a[1].level) || (b[1].xp - a[1].xp))
                    .slice(0, 10);
                if (!top.length) return e.reply(message, e.info('🏆 المتصدرين', 'ما فيه بيانات للحين.'));
                const lines = top.map(([id, u], i) => `${medals[i] || `**${i + 1}.**`} <@${id}> • مستوى **${u.level}** • ${t.num(u.xp)} خبرة`).join('\n');
                return e.reply(message, e.base(e.colors.gold).setTitle('🏆 أعلى الأعضاء مستوى').setDescription(lines));
            }
        },
        {
            name: 'بروفايل',
            aliases: ['ملفي', 'بطاقتي', 'بروفايلي'],
            desc: 'بطاقة شاملة عن حسابك',
            usage: 'بروفايل [@العضو]',
            async run(message, args) {
                const member = await pickMember(message, args);
                if (!member) return;
                const p = db.user(message.guild.id, member.id);
                const warns = (db.guild(message.guild.id).warns[member.id] || []).length;
                const embed = e.base()
                    .setTitle(`🪪 بطاقة ${member.displayName}`)
                    .setThumbnail(member.displayAvatarURL({ size: 256 }))
                    .setDescription(`╭ ⭐ المستوى **${p.level}**\n╰ ${t.bar(p.xp, xp.need(p.level), 14)}`)
                    .addFields(
                        { name: '💰 الكاش', value: t.num(p.cash), inline: true },
                        { name: '🏦 البنك', value: t.num(p.bank), inline: true },
                        { name: '❤️ السمعة', value: `${p.rep}`, inline: true },
                        { name: '💬 الرسائل', value: t.num(p.messages), inline: true },
                        { name: '🎙️ الصوت', value: hours(p.voice), inline: true },
                        { name: '⚠️ التحذيرات', value: `${warns}`, inline: true },
                        { name: '📥 دخل السيرفر', value: t.stamp(member.joinedAt, 'R'), inline: false }
                    );
                return e.reply(message, embed);
            }
        },
        {
            name: 'سمعة',
            aliases: ['ريب', 'شكر'],
            desc: 'إعطاء نقطة سمعة لعضو كل 12 ساعة',
            usage: 'سمعة @العضو',
            async run(message, args) {
                const member = await r.member(message, args[0]);
                if (!member || member.user.bot) return e.reply(message, e.err('منشن عضو صحيح.'));
                if (member.id === message.author.id) return e.reply(message, e.err('ما تقدر تعطي نفسك سمعة.'));
                const p = db.user(message.guild.id, message.author.id);
                const left = (p.cd.rep || 0) + 43200000 - Date.now();
                if (left > 0) return e.reply(message, e.warn(`تقدر تعطي سمعة بعد **${t.formatDuration(left)}**`, '⏳ انتظر شوي'));
                p.cd.rep = Date.now();
                const target = db.user(message.guild.id, member.id);
                target.rep += 1;
                db.save();
                return e.reply(message, e.ok(`أعطيت ${member} نقطة سمعة ❤️\nسمعته الآن **${target.rep}**`));
            }
        },
        {
            name: 'رسائلي',
            aliases: ['نشاطي', 'عدد_رسائلي'],
            desc: 'عدد رسائلك أو رسائل عضو',
            usage: 'رسائلي [@العضو]',
            async run(message, args) {
                const member = await pickMember(message, args);
                if (!member) return;
                const p = db.user(message.guild.id, member.id);
                return e.reply(message, e.info('💬 النشاط الكتابي', `${member} أرسل **${t.num(p.messages)}** رسالة`));
            }
        },
        {
            name: 'توب_رسائل',
            aliases: ['اكثر_تفاعل', 'توب_شات'],
            desc: 'أكثر الأعضاء رسائل',
            usage: 'توب_رسائل',
            async run(message) {
                const lines = board(message, 'messages', u => `**${t.num(u.messages)}** رسالة`);
                if (!lines) return e.reply(message, e.info('💬 توب الرسائل', 'ما فيه بيانات للحين.'));
                return e.reply(message, e.base(e.colors.info).setTitle('💬 أكثر الأعضاء رسائل').setDescription(lines));
            }
        },
        {
            name: 'صوتي',
            aliases: ['وقتي_الصوتي', 'نشاطي_الصوتي'],
            desc: 'مدة جلوسك في الرومات الصوتية',
            usage: 'صوتي [@العضو]',
            async run(message, args) {
                const member = await pickMember(message, args);
                if (!member) return;
                const p = db.user(message.guild.id, member.id);
                return e.reply(message, e.info('🎙️ النشاط الصوتي', `${member} جلس **${hours(p.voice)}** في الرومات الصوتية`));
            }
        },
        {
            name: 'توب_صوت',
            aliases: ['اكثر_صوت', 'توب_فويس'],
            desc: 'أكثر الأعضاء جلوساً في الصوت',
            usage: 'توب_صوت',
            async run(message) {
                const lines = board(message, 'voice', u => `**${hours(u.voice)}**`);
                if (!lines) return e.reply(message, e.info('🎙️ توب الصوت', 'ما فيه بيانات للحين.'));
                return e.reply(message, e.base(e.colors.info).setTitle('🎙️ أكثر الأعضاء جلوساً في الصوت').setDescription(lines));
            }
        },
        {
            name: 'رتبة_لفل',
            aliases: ['اضافة_رتبة_لفل'],
            desc: 'ربط رتبة بمستوى معين',
            usage: 'رتبة_لفل <المستوى> @الرتبة',
            perms: ['ManageRoles'],
            async run(message, args) {
                const level = Number(t.digits(args[0] || ''));
                const role = r.role(message, args.slice(1).join(' '));
                if (!level || level < 1 || !role) return e.reply(message, e.err('الاستخدام: `رتبة_لفل 10 @رتبة`'));
                db.guild(message.guild.id).levelRoles[level] = role.id;
                db.save();
                return e.reply(message, e.ok(`من يوصل المستوى **${level}** ياخذ رتبة ${role}`));
            }
        },
        {
            name: 'حذف_رتبة_لفل',
            aliases: ['ازالة_رتبة_لفل'],
            desc: 'حذف ربط رتبة بمستوى',
            usage: 'حذف_رتبة_لفل <المستوى>',
            perms: ['ManageRoles'],
            async run(message, args) {
                const level = Number(t.digits(args[0] || ''));
                const roles = db.guild(message.guild.id).levelRoles;
                if (!roles[level]) return e.reply(message, e.err('ما فيه رتبة مربوطة بهذا المستوى.'));
                delete roles[level];
                db.save();
                return e.reply(message, e.ok(`تم حذف رتبة المستوى **${level}**`));
            }
        },
        {
            name: 'رتب_المستويات',
            aliases: ['رتب_لفل'],
            desc: 'عرض الرتب المربوطة بالمستويات',
            usage: 'رتب_المستويات',
            async run(message) {
                const roles = Object.entries(db.guild(message.guild.id).levelRoles).sort((a, b) => a[0] - b[0]);
                if (!roles.length) return e.reply(message, e.info('🎖️ رتب المستويات', 'ما فيه رتب مربوطة.'));
                return e.reply(message, e.info('🎖️ رتب المستويات', roles.map(([lvl, id]) => `مستوى **${lvl}** ← <@&${id}>`).join('\n')));
            }
        },
        {
            name: 'اعطاء_خبرة',
            aliases: ['اضف_خبرة'],
            desc: 'إعطاء خبرة لعضو (للإدارة)',
            usage: 'اعطاء_خبرة @العضو <الكمية>',
            perms: ['Administrator'],
            async run(message, args) {
                const member = await r.member(message, args[0]);
                const amount = Number(t.digits(args[1] || ''));
                if (!member || !amount || amount < 1) return e.reply(message, e.err('الاستخدام: `اعطاء_خبرة @العضو 500`'));
                const p = db.user(message.guild.id, member.id);
                p.xp += amount;
                while (p.xp >= xp.need(p.level)) {
                    p.xp -= xp.need(p.level);
                    p.level += 1;
                }
                db.save();
                xp.applyRoles(member);
                return e.reply(message, e.ok(`تم إعطاء ${member} **${t.num(amount)}** خبرة\nمستواه الآن **${p.level}**`));
            }
        },
        {
            name: 'تصفير_لفل',
            aliases: ['اصفر_لفل'],
            desc: 'تصفير مستوى وخبرة عضو (للإدارة)',
            usage: 'تصفير_لفل @العضو',
            perms: ['Administrator'],
            async run(message, args) {
                const member = await r.member(message, args[0]);
                if (!member) return e.reply(message, e.err('منشن العضو.'));
                const p = db.user(message.guild.id, member.id);
                p.xp = 0;
                p.level = 0;
                db.save();
                return e.reply(message, e.ok(`تم تصفير مستوى ${member}`));
            }
        }
    ]
};
