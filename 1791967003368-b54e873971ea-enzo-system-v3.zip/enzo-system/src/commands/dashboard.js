// الداشبورد داخل البوت: لوحة تحكم تفاعلية بالقوائم والأزرار بدل أي موقع خارجي
const fs = require('fs');
const {
    ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, ChannelSelectMenuBuilder,
    RoleSelectMenuBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ChannelType, MessageFlags
} = require('discord.js');
const config = require('../../config');
const db = require('../utils/db');
const extDb = require('../ext/database/db');
const e = require('../utils/embeds');
const t = require('../utils/time');
const { isBotOwner } = require('../utils/owner');
const backup = require('../utils/backup');
const welcome = require('../core/welcome');
const more = require('../dashboard/more');
const tickets = require('../core/tickets');

const kit = require('../dashboard/kit');
const { eph, TEXT, VOICE, CATEGORY, clip, ch, role, onoff, row, btn, ask, fail, findRole, channelPicker, rolePicker } = kit;

// ───────── الرومات: كل إعداد روم في السيرفر ─────────
const targets = [
    { key: 'logs', label: 'روم السجلات', emoji: '📜', types: TEXT, get: g => g.logs, set: (g, id) => { g.logs = id; } },
    { key: 'welcome', label: 'روم الترحيب', emoji: '👋', types: TEXT, get: g => g.welcome.channel, set: (g, id) => { g.welcome.channel = id; } },
    { key: 'leave', label: 'روم المغادرة', emoji: '🚪', types: TEXT, get: g => g.welcome.leave, set: (g, id) => { g.welcome.leave = id; } },
    { key: 'suggestions', label: 'روم الاقتراحات', emoji: '💡', types: TEXT, get: g => g.suggestions, set: (g, id, guildId) => {
        g.suggestions = id;
        const cur = extDb.getSuggestionSettings(guildId);
        if (cur) extDb.setSuggestionSettings(guildId, { ...cur, channelId: id });
    } },
    { key: 'ticketLogs', label: 'سجلات التذاكر', emoji: '🧾', types: TEXT, get: g => g.tickets.logs, set: (g, id) => { g.tickets.logs = id; } },
    { key: 'ticketCategory', label: 'تصنيف التذاكر', emoji: '🗂️', types: CATEGORY, get: g => g.tickets.category, set: (g, id) => { g.tickets.category = id; } },
    { key: 'levelChannel', label: 'روم إعلان الترقيات', emoji: '🎉', types: TEXT, get: g => g.levels.channel, set: (g, id) => { g.levels.channel = id; } },
    { key: 'suggestionReview', label: 'روم مراجعة الاقتراحات', emoji: '🧐', types: TEXT, get: (g, id) => extDb.getSuggestionSettings(id)?.logChannelId || null, set: (g, id, guildId) => {
        const cur = extDb.getSuggestionSettings(guildId) || { channelId: g.suggestions, autoThread: true };
        extDb.setSuggestionSettings(guildId, { ...cur, logChannelId: id });
    } },
    { key: 'tempVoice', label: 'روم الرومات المؤقتة', emoji: '🎙️', types: VOICE, get: g => g.tempVoice.creator, set: (g, id) => { g.tempVoice.creator = id; } },
    { key: 'inviteLogs', label: 'سجل الدعوات', emoji: '📨', types: TEXT, get: (g, id) => extDb.getInviteLogs(id)?.channelId || null, set: (g, id, guildId) => extDb.setInviteLogs(guildId, id) },
    { key: 'starboard', label: 'روم الستاربورد', emoji: '⭐', types: TEXT, get: (g, id) => extDb.getStarboardSettings(id)?.channelId || null, set: (g, id, guildId) => {
        const cur = extDb.getStarboardSettings(guildId) || {};
        extDb.setStarboardSettings(guildId, { emoji: '⭐', threshold: 3, ...cur, channelId: id });
    } },
    { key: 'jailChannel', label: 'روم السجن', emoji: '⛓️', types: TEXT, get: (g, id) => extDb.getJailSettings(id).jailChannelId, set: (g, id, guildId) => {
        const j = extDb.getJailSettings(guildId);
        extDb.setJailSettings(guildId, j.jailRoleId, id, j.staffVoiceId, j.staffRoleId);
    } },
    { key: 'jailVoice', label: 'روم استدعاء السجن', emoji: '📞', types: VOICE, get: (g, id) => extDb.getJailSettings(id).staffVoiceId, set: (g, id, guildId) => {
        const j = extDb.getJailSettings(guildId);
        extDb.setJailSettings(guildId, j.jailRoleId, j.jailChannelId, id, j.staffRoleId);
    } }
];

const protections = [
    ['links', '🔗 الروابط'], ['invites', '📨 الدعوات'], ['spam', '💬 السبام'],
    ['mentions', '📢 المنشن'], ['badwords', '🚫 الكلمات الممنوعة'], ['raid', '🚨 الريد']
];

const sectionsList = [
    { key: 'home', label: 'الرئيسية', emoji: '🏠' },
    { key: 'protection', label: 'الحماية', emoji: '🛡️' },
    { key: 'channels', label: 'الرومات والسجلات', emoji: '📺' },
    { key: 'welcome', label: 'الترحيب', emoji: '👋' },
    { key: 'tickets', label: 'التذاكر', emoji: '🎫' },
    { key: 'levels', label: 'المستويات', emoji: '📈' },
    { key: 'economy', label: 'المتجر والاقتصاد', emoji: '🛒' },
    { key: 'replies', label: 'الردود التلقائية', emoji: '🤖' },
    { key: 'automation', label: 'الأتمتة', emoji: '⚡' },
    { key: 'extras', label: 'الستاربورد والسجن', emoji: '🧩' },
    { key: 'backup', label: 'النسخ الاحتياطي', emoji: '💾', ownerOnly: true }
];

const fileSize = p => { try { return `${(fs.statSync(p).size / 1024).toFixed(1)} KB`; } catch { return '-'; } };

// ───────── الأقسام: كل قسم له عرض (embed + components) ومعالج للتفاعلات ─────────
const sections = {
    // ═══ الرئيسية ═══
    home: {
        embed({ guild, client }) {
            const g = db.guild(guild.id);
            const active = protections.filter(([k]) => g.protection[k]).length;
            const profiles = Object.keys(db.users(guild.id)).length;
            return e.base().setTitle(`🏠 داشبورد ${guild.name}`).setThumbnail(guild.iconURL({ size: 256 }))
                .setDescription('اختر القسم من القائمة بالأسفل للتحكم بإعدادات البوت بدون أي أوامر.')
                .addFields(
                    { name: '🔣 البريفكس', value: `\`${(g.prefix ?? config.prefix) || 'بدون'}\``, inline: true },
                    { name: '🛡️ الحماية', value: `${active}/${protections.length} مفعلة`, inline: true },
                    { name: '🎫 تذاكر مفتوحة', value: `${Object.keys(g.tickets.open).length}`, inline: true },
                    { name: '👥 الأعضاء', value: t.num(guild.memberCount), inline: true },
                    { name: '📈 ملفات الأعضاء', value: t.num(profiles), inline: true },
                    { name: '🤖 الردود التلقائية', value: `${g.autoReply.length}`, inline: true },
                    { name: '🛒 منتجات المتجر', value: `${g.shop.length}`, inline: true },
                    { name: '⏱️ التشغيل', value: t.formatDuration(client.uptime), inline: true },
                    { name: '📡 البنق', value: `${client.ws.ping}ms`, inline: true },
                    { name: '💽 حجم البيانات', value: `${fileSize(db.file)} + ${fileSize(extDb.file)}`, inline: true },
                    { name: '🧩 الأوامر', value: `${client.commands.size}`, inline: true }
                );
        },
        components: () => [row(
            btn('dash:home:refresh', 'تحديث', '🔄'),
            btn('dash:home:prefix', 'تغيير البريفكس', '🔣'),
            btn('dash:close', 'إغلاق', '❌', ButtonStyle.Danger)
        )],
        async handle(i, ctx, state, redraw) {
            if (i.customId === 'dash:home:refresh') return redraw(i);
            if (i.customId === 'dash:home:prefix') {
                const cur = db.guild(ctx.guild.id).prefix ?? config.prefix;
                const s = await ask(i, 'تغيير البريفكس', [{ id: 'prefix', label: 'البريفكس الجديد (اكتب بدون لإلغائه)', value: cur || '', max: 3, required: false }]);
                if (!s) return;
                const raw = s.fields.getTextInputValue('prefix').trim();
                db.guild(ctx.guild.id).prefix = raw === 'بدون' ? '' : raw;
                db.save();
                return redraw(null);
            }
        }
    },

    // ═══ الحماية ═══
    protection: {
        embed({ guild }) {
            const p = db.guild(guild.id).protection;
            const lines = protections.map(([k, name]) => `${onoff(p[k])} **${name}**`).join('\n');
            return e.base().setTitle('🛡️ إعدادات الحماية').setDescription(lines).addFields(
                { name: '🚫 كلمات ممنوعة', value: `${p.words.length}`, inline: true },
                { name: '✅ رتب مستثناة', value: p.roles.length ? clip(p.roles.map(role).join(' ')) : 'لا يوجد', inline: true },
                { name: '👤 أعضاء مستثنون', value: `${p.users.length} (من أمر \`استثناء\`)`, inline: true },
                { name: '⚖️ العقوبة مع الحذف', value: { delete: 'حذف الرسالة فقط', timeout: 'حذف + إسكات 5 دقائق', warn: 'حذف + تحذير' }[p.action] || 'حذف الرسالة فقط', inline: false }
            );
        },
        components({ guild }) {
            const p = db.guild(guild.id).protection;
            const types = new StringSelectMenuBuilder().setCustomId('dash:prot:types').setPlaceholder('🛡️ حدد الحمايات المفعلة')
                .setMinValues(0).setMaxValues(protections.length)
                .addOptions(protections.map(([k, name]) => ({ label: name.replace(/^\S+\s/, ''), value: k, emoji: name.split(' ')[0], default: Boolean(p[k]) })));
            const action = new StringSelectMenuBuilder().setCustomId('dash:prot:action').setPlaceholder('⚖️ العقوبة عند المخالفة')
                .addOptions([['delete', 'حذف الرسالة فقط', '🗑️'], ['timeout', 'حذف + إسكات 5 دقائق', '🔇'], ['warn', 'حذف + تحذير', '⚠️']]
                    .map(([v, l, em]) => ({ label: l, value: v, emoji: em, default: (p.action || 'delete') === v })));
            return [
                row(types),
                row(action),
                rolePicker('dash:prot:roles', '✅ الرتب المستثناة من الحماية', p.roles, { max: 25, guild }),
                row(
                    btn('dash:prot:add', 'إضافة كلمة', '➕'),
                    btn('dash:prot:del', 'حذف كلمة', '➖'),
                    btn('dash:prot:all', 'تشغيل الكل', '🟢', ButtonStyle.Success),
                    btn('dash:prot:none', 'إيقاف الكل', '🔴', ButtonStyle.Danger)
                )
            ].slice(0, 4);
        },
        async handle(i, ctx, state, redraw) {
            const p = db.guild(ctx.guild.id).protection;
            if (i.customId === 'dash:prot:types') {
                protections.forEach(([k]) => { p[k] = i.values.includes(k); });
                db.save();
                return redraw(i);
            }
            if (i.customId === 'dash:prot:action') { p.action = i.values[0]; db.save(); return redraw(i); }
            if (i.customId === 'dash:prot:roles') {
                p.roles = [...i.values];
                db.save();
                return redraw(i);
            }
            if (i.customId === 'dash:prot:all' || i.customId === 'dash:prot:none') {
                protections.forEach(([k]) => { p[k] = i.customId === 'dash:prot:all'; });
                db.save();
                return redraw(i);
            }
            if (i.customId === 'dash:prot:add') {
                const s = await ask(i, 'إضافة كلمة ممنوعة', [{ id: 'word', label: 'الكلمة', max: 60 }]);
                if (!s) return;
                const word = s.fields.getTextInputValue('word').trim().toLowerCase();
                if (!word) return;
                if (p.words.includes(word)) return fail(s, 'الكلمة موجودة بالفعل.');
                if (p.words.length >= 500) return fail(s, 'وصلت الحد الأقصى 500 كلمة.');
                p.words.push(word);
                db.save();
                return redraw(null);
            }
            if (i.customId === 'dash:prot:del') {
                const s = await ask(i, 'حذف كلمة ممنوعة', [{ id: 'word', label: 'الكلمة', max: 60 }]);
                if (!s) return;
                const word = s.fields.getTextInputValue('word').trim().toLowerCase();
                const index = p.words.indexOf(word);
                if (index === -1) return fail(s, 'الكلمة مو موجودة في القائمة.');
                p.words.splice(index, 1);
                db.save();
                return redraw(null);
            }
        }
    },

    // ═══ الرومات والسجلات ═══
    channels: {
        embed({ guild }) {
            const g = db.guild(guild.id);
            const lines = targets.map(x => `${x.emoji} **${x.label}:** ${ch(x.get(g, guild.id))}`).join('\n');
            return e.base().setTitle('📺 الرومات والسجلات').setDescription(lines)
                .setFooter({ text: 'اختر الإعداد من القائمة الأولى ثم اختر الروم من القائمة الثانية (إلغاء الاختيار يمسح الإعداد)' });
        },
        components({ guild }, state) {
            const g = db.guild(guild.id);
            const target = targets.find(x => x.key === state.target) || targets[0];
            const menu = new StringSelectMenuBuilder().setCustomId('dash:ch:target').setPlaceholder('اختر الإعداد')
                .addOptions(targets.map(x => ({ label: x.label, value: x.key, emoji: x.emoji, default: x.key === target.key })));
            return [
                row(menu),
                channelPicker('dash:ch:value', `${target.emoji} اختر ${target.label}`, target.types, target.get(g, guild.id), { guild })
            ];
        },
        async handle(i, ctx, state, redraw) {
            if (i.customId === 'dash:ch:target') { state.target = i.values[0]; return redraw(i); }
            if (i.customId === 'dash:ch:value') {
                const target = targets.find(x => x.key === state.target) || targets[0];
                target.set(db.guild(ctx.guild.id), i.values[0] || null, ctx.guild.id);
                db.save();
                return redraw(i);
            }
        }
    },

    // ═══ الترحيب ═══
    welcome: {
        embed({ guild }) {
            const w = db.guild(guild.id).welcome;
            return e.base().setTitle('👋 الترحيب').addFields(
                { name: '📥 روم الترحيب', value: ch(w.channel), inline: true },
                { name: '📤 روم المغادرة', value: ch(w.leave), inline: true },
                { name: '🎭 الرتبة التلقائية', value: role(w.autoRole), inline: true },
                { name: '✏️ رسالة الترحيب', value: `${clip(w.message)}\n\nالمتغيرات: \`{user}\` \`{name}\` \`{server}\` \`{count}\``, inline: false }
            ).setFooter({ text: 'روم الترحيب والمغادرة من قسم الرومات والسجلات' });
        },
        components({ guild }) {
            const w = db.guild(guild.id).welcome;
            return [
                rolePicker('dash:wel:role', '🎭 الرتبة التلقائية للأعضاء الجدد', w.autoRole, { guild }),
                row(btn('dash:wel:msg', 'تعديل رسالة الترحيب', '✏️'), btn('dash:wel:test', 'تجربة الترحيب', '👁️'))
            ];
        },
        async handle(i, ctx, state, redraw) {
            const g = db.guild(ctx.guild.id);
            if (i.customId === 'dash:wel:role') {
                const id = i.values[0] || null;
                if (id) {
                    const picked = ctx.guild.roles.cache.get(id);
                    if (!picked || picked.managed || picked.position >= ctx.guild.members.me.roles.highest.position) {
                        return i.reply({ embeds: [e.err('هذي الرتبة أعلى من رتبة البوت أو رتبة نظام، اختر غيرها.')], ...eph });
                    }
                }
                g.welcome.autoRole = id;
                db.save();
                return redraw(i);
            }
            if (i.customId === 'dash:wel:msg') {
                const s = await ask(i, 'رسالة الترحيب', [{ id: 'text', label: 'النص', long: true, max: 800, value: g.welcome.message }]);
                if (!s) return;
                const text = s.fields.getTextInputValue('text').trim();
                if (!text) return fail(s, 'اكتب نص الرسالة.');
                g.welcome.message = text;
                db.save();
                return redraw(null);
            }
            if (i.customId === 'dash:wel:test') {
                return i.reply({ embeds: [welcome.joinEmbed(i.member)], ...eph });
            }
        }
    },

    // ═══ التذاكر ═══
    tickets: {
        embed({ guild }) {
            const tk = db.guild(guild.id).tickets;
            return e.base().setTitle('🎫 التذاكر').addFields(
                { name: '🛟 رتبة الدعم', value: role(tk.role), inline: true },
                { name: '🗂️ التصنيف', value: ch(tk.category), inline: true },
                { name: '🧾 السجلات', value: ch(tk.logs), inline: true },
                { name: '🔢 عدد التذاكر', value: `${tk.counter}`, inline: true },
                { name: '📂 المفتوحة', value: `${Object.keys(tk.open).length}`, inline: true }
            ).setFooter({ text: 'التصنيف وسجلات التذاكر من قسم الرومات والسجلات' });
        },
        components({ guild }) {
            return [
                rolePicker('dash:tk:role', '🛟 رتبة فريق الدعم', db.guild(guild.id).tickets.role, { guild }),
                row(btn('dash:tk:panel', 'إرسال لوحة التذاكر هنا', '📨', ButtonStyle.Primary), btn('dash:tk:list', 'التذاكر المفتوحة', '📋'))
            ];
        },
        async handle(i, ctx, state, redraw) {
            const tk = db.guild(ctx.guild.id).tickets;
            if (i.customId === 'dash:tk:role') { tk.role = i.values[0] || null; db.save(); return redraw(i); }
            if (i.customId === 'dash:tk:panel') {
                await ctx.message.channel.send({ embeds: [tickets.panel()], components: [tickets.panelRow()] }).catch(() => null);
                return i.reply({ embeds: [e.ok(`تم إرسال لوحة التذاكر في ${ctx.message.channel}`)], ...eph });
            }
            if (i.customId === 'dash:tk:list') {
                const open = Object.entries(tk.open);
                const text = open.length
                    ? clip(open.map(([id, x]) => `<#${id}> • <@${x.owner}> • ${x.claimed ? `✋ <@${x.claimed}>` : '⏳ بدون مستلم'}`).join('\n'), 3900)
                    : 'ما فيه تذاكر مفتوحة.';
                return i.reply({ embeds: [e.info(`🎫 التذاكر المفتوحة (${open.length})`, text)], ...eph });
            }
        }
    },

    // ═══ المستويات ═══
    levels: {
        embed({ guild }) {
            const entries = Object.entries(db.guild(guild.id).levelRoles).sort((a, b) => a[0] - b[0]);
            const text = entries.length ? clip(entries.map(([lvl, id]) => `مستوى **${lvl}** ← ${role(id)}`).join('\n'), 3500) : 'ما فيه رتب مربوطة بالمستويات.';
            const c = db.guild(guild.id).levels;
            return e.base().setTitle('📈 المستويات').setDescription(text).addFields(
                { name: '⚙️ النظام', value: c.enabled ? '🟢 مفعل' : '🔴 متوقف', inline: true },
                { name: '💬 خبرة الرسائل', value: `${c.xpMin} - ${c.xpMax} (مرة بالدقيقة)`, inline: true },
                { name: '🎙️ خبرة الصوت', value: c.voiceEnabled ? `🟢 ${c.voiceMin} - ${c.voiceMax} بالدقيقة` : '🔴 متوقفة', inline: true },
                { name: '🎉 روم الترقيات', value: ch(c.channel), inline: true }
            ).setFooter({ text: 'مكافأة الترقية = المستوى × 50 عملة، وروم الترقيات من قسم الرومات والسجلات' });
        },
        components({ guild }) {
            const entries = Object.entries(db.guild(guild.id).levelRoles).sort((a, b) => a[0] - b[0]).slice(0, 25);
            const rows = [];
            if (entries.length) {
                rows.push(row(new StringSelectMenuBuilder().setCustomId('dash:lvl:remove').setPlaceholder('🗑️ اختر ربط لحذفه')
                    .addOptions(entries.map(([lvl, id]) => ({ label: `مستوى ${lvl}`, description: (guild.roles.cache.get(id)?.name || 'رتبة محذوفة').slice(0, 90), value: String(lvl) })))));
            }
            rows.push(row(btn('dash:lvl:add', 'ربط رتبة بمستوى', '➕', ButtonStyle.Primary), btn('dash:lvl:cfg', 'إعدادات الخبرة', '⚙️')));
            return rows;
        },
        async handle(i, ctx, state, redraw) {
            const levelRoles = db.guild(ctx.guild.id).levelRoles;
            if (i.customId === 'dash:lvl:remove') { delete levelRoles[i.values[0]]; db.save(); return redraw(i); }
            if (i.customId === 'dash:lvl:cfg') {
                const c = db.guild(ctx.guild.id).levels;
                const s = await ask(i, 'إعدادات الخبرة', [
                    { id: 'enabled', label: 'نظام المستويات (نعم/لا)', max: 3, value: c.enabled ? 'نعم' : 'لا' },
                    { id: 'xp', label: 'خبرة الرسائل (الأقل-الأعلى)', max: 11, value: `${c.xpMin}-${c.xpMax}` },
                    { id: 'voice', label: 'خبرة الصوت (نعم/لا)', max: 3, value: c.voiceEnabled ? 'نعم' : 'لا' },
                    { id: 'voicexp', label: 'خبرة الصوت بالدقيقة (الأقل-الأعلى)', max: 11, value: `${c.voiceMin}-${c.voiceMax}` }
                ]);
                if (!s) return;
                const range = raw => {
                    const m = t.digits(raw).match(/^\s*(\d{1,4})\s*[-–]\s*(\d{1,4})\s*$/);
                    return m && Number(m[2]) >= Number(m[1]) ? [Number(m[1]), Number(m[2])] : null;
                };
                const xpR = range(s.fields.getTextInputValue('xp'));
                const voR = range(s.fields.getTextInputValue('voicexp'));
                if (!xpR || !voR) return fail(s, 'اكتب المدى بالشكل `15-25` (الأقل ثم الأعلى).');
                c.enabled = s.fields.getTextInputValue('enabled').trim() !== 'لا';
                c.voiceEnabled = s.fields.getTextInputValue('voice').trim() === 'نعم';
                [c.xpMin, c.xpMax] = xpR;
                [c.voiceMin, c.voiceMax] = voR;
                db.save();
                return redraw(null);
            }
            if (i.customId === 'dash:lvl:add') {
                const s = await ask(i, 'ربط رتبة بمستوى', [{ id: 'level', label: 'رقم المستوى', max: 4, placeholder: '10' }]);
                if (!s) return;
                const level = Number(t.digits(s.fields.getTextInputValue('level')));
                if (!Number.isInteger(level) || level < 1 || level > 1000) return fail(s, 'اكتب رقم مستوى صحيح من 1 إلى 1000.');
                const pick = await s.followUp({
                    content: `اختر الرتبة اللي ياخذها من يوصل المستوى **${level}**`,
                    components: [rolePicker('dash:lvl:role', 'اختر الرتبة', null, { guild: ctx.guild })],
                    ...eph
                }).catch(() => null);
                if (!pick) return;
                const chosen = await pick.awaitMessageComponent({ time: 60000, filter: x => x.user.id === i.user.id }).catch(() => null);
                if (!chosen) return s.editReply({ content: 'انتهى الوقت.', components: [] }).catch(() => {});
                const picked = ctx.guild.roles.cache.get(chosen.values[0]);
                if (!picked || picked.managed || picked.position >= ctx.guild.members.me.roles.highest.position) {
                    return chosen.update({ content: '❌ هذي الرتبة أعلى من رتبة البوت أو رتبة نظام.', components: [] });
                }
                levelRoles[level] = picked.id;
                db.save();
                await chosen.update({ content: `✅ من يوصل المستوى **${level}** ياخذ ${picked}`, components: [] });
                return redraw(null);
            }
        }
    },

    // ═══ المتجر والاقتصاد ═══
    economy: {
        embed({ guild }) {
            const shop = db.guild(guild.id).shop;
            const text = shop.length
                ? clip(shop.map((x, n) => `**${n + 1}.** ${x.name} • **${t.num(x.price)}** ${config.coin}${x.role ? ` • ${role(x.role)}` : ''}`).join('\n'), 3800)
                : 'المتجر فاضي.';
            const b = db.guild(guild.id).bank;
            return e.base(e.colors.gold).setTitle('🛒 المتجر والاقتصاد').setDescription(text).addFields({
                name: '⏳ فترات الانتظار',
                value: `راتب: **${t.formatDuration(b.daily * 60000)}** • عمل: **${t.formatDuration(b.work * 60000)}**\nجريمة: **${t.formatDuration(b.crime * 60000)}** • سرقة: **${t.formatDuration(b.rob * 60000)}**`,
                inline: false
            });
        },
        components({ guild }) {
            const shop = db.guild(guild.id).shop.slice(0, 25);
            const rows = [];
            if (shop.length) {
                rows.push(row(new StringSelectMenuBuilder().setCustomId('dash:eco:remove').setPlaceholder('🗑️ اختر منتج لحذفه')
                    .addOptions(shop.map((x, n) => ({ label: `${n + 1}. ${x.name}`.slice(0, 100), description: `${t.num(x.price)} عملة`, value: String(n) })))));
            }
            rows.push(row(btn('dash:eco:add', 'إضافة منتج', '➕', ButtonStyle.Primary), btn('dash:eco:cd', 'فترات الانتظار', '⏳')));
            return rows;
        },
        async handle(i, ctx, state, redraw) {
            const g = db.guild(ctx.guild.id);
            if (i.customId === 'dash:eco:remove') { g.shop.splice(Number(i.values[0]), 1); db.save(); return redraw(i); }
            if (i.customId === 'dash:eco:cd') {
                const b = g.bank;
                const s = await ask(i, 'فترات الانتظار بالدقائق', [
                    { id: 'daily', label: 'الراتب', max: 6, value: String(b.daily) },
                    { id: 'work', label: 'العمل', max: 6, value: String(b.work) },
                    { id: 'crime', label: 'الجريمة', max: 6, value: String(b.crime) },
                    { id: 'rob', label: 'السرقة', max: 6, value: String(b.rob) }
                ]);
                if (!s) return;
                const vals = ['daily', 'work', 'crime', 'rob'].map(k => Number(t.digits(s.fields.getTextInputValue(k))));
                if (vals.some(v => !Number.isInteger(v) || v < 0 || v > 43200)) return fail(s, 'اكتب أرقام صحيحة بالدقائق (من 0 إلى 43200).');
                [b.daily, b.work, b.crime, b.rob] = vals;
                db.save();
                return redraw(null);
            }
            if (i.customId === 'dash:eco:add') {
                const s = await ask(i, 'إضافة منتج للمتجر', [
                    { id: 'name', label: 'اسم المنتج', max: 80 },
                    { id: 'price', label: 'السعر', max: 12, placeholder: '5000' },
                    { id: 'role', label: 'ايدي أو اسم رتبة (اختياري)', required: false, max: 100 }
                ]);
                if (!s) return;
                const name = s.fields.getTextInputValue('name').trim();
                const price = Number(t.digits(s.fields.getTextInputValue('price')).replace(/,/g, ''));
                const roleArg = s.fields.getTextInputValue('role').trim();
                if (!name || !Number.isInteger(price) || price < 1 || price > 1e12) return fail(s, 'اكتب اسم وسعر صحيح.');
                if (g.shop.length >= 100) return fail(s, 'وصلت الحد الأقصى 100 منتج.');
                let roleId = null;
                if (roleArg) {
                    const found = findRole(ctx.guild, roleArg);
                    if (!found) return fail(s, 'ما لقيت هذي الرتبة.');
                    if (found.managed || found.position >= ctx.guild.members.me.roles.highest.position) return fail(s, 'الرتبة أعلى من رتبة البوت.');
                    roleId = found.id;
                }
                g.shop.push({ name, price, role: roleId });
                db.save();
                return redraw(null);
            }
        }
    },

    // ═══ الردود التلقائية ═══
    replies: {
        embed({ guild }) {
            const list = db.guild(guild.id).autoReply;
            const text = list.length ? clip(list.map((x, n) => `**${n + 1}.** \`${x.trigger}\` ← ${clip(x.response, 60)}`).join('\n'), 3800) : 'ما فيه ردود مسجلة.';
            return e.base().setTitle(`🤖 الردود التلقائية (${list.length}/50)`).setDescription(text);
        },
        components({ guild }) {
            const list = db.guild(guild.id).autoReply.slice(0, 25);
            const rows = [];
            if (list.length) {
                rows.push(row(new StringSelectMenuBuilder().setCustomId('dash:rep:remove').setPlaceholder('🗑️ اختر رد لحذفه')
                    .addOptions(list.map((x, n) => ({ label: `${n + 1}. ${x.trigger}`.slice(0, 100), description: clip(x.response, 90), value: String(n) })))));
            }
            rows.push(row(btn('dash:rep:add', 'إضافة رد', '➕', ButtonStyle.Primary)));
            return rows;
        },
        async handle(i, ctx, state, redraw) {
            const g = db.guild(ctx.guild.id);
            if (i.customId === 'dash:rep:remove') { g.autoReply.splice(Number(i.values[0]), 1); db.save(); return redraw(i); }
            if (i.customId === 'dash:rep:add') {
                const s = await ask(i, 'إضافة رد تلقائي', [
                    { id: 'trigger', label: 'الكلمة', max: 100 },
                    { id: 'response', label: 'الرد', long: true, max: 1500 }
                ]);
                if (!s) return;
                const trigger = s.fields.getTextInputValue('trigger').trim().toLowerCase();
                const response = s.fields.getTextInputValue('response').trim();
                if (!trigger || !response) return fail(s, 'اكتب الكلمة والرد.');
                if (g.autoReply.length >= 50 && !g.autoReply.some(x => x.trigger === trigger)) return fail(s, 'وصلت الحد الأقصى 50 رد.');
                g.autoReply = g.autoReply.filter(x => x.trigger !== trigger);
                g.autoReply.push({ trigger, response });
                db.save();
                return redraw(null);
            }
        }
    },

    // ═══ الأتمتة ═══
    automation: {
        features: [
            { key: 'tax', label: 'الضريبة التلقائية', emoji: '💳', multi: true },
            { key: 'images', label: 'رومات الصور فقط', emoji: '🖼️', multi: true },
            { key: 'youtube', label: 'رومات اليوتيوب فقط', emoji: '▶️', multi: true },
            { key: 'line', label: 'الخط التلقائي', emoji: '➖', multi: true },
            { key: 'feelings', label: 'روم المشاعر', emoji: '💭', multi: false },
            { key: 'boost', label: 'روم شكر البوست', emoji: '💜', multi: false }
        ],
        read(g, key) {
            const a = g.automation;
            return { tax: a.tax, images: a.images, youtube: a.youtube, line: g.autoLine.channels, feelings: a.feelings.channel, boost: a.boost.channel }[key];
        },
        write(g, key, ids) {
            const a = g.automation;
            if (key === 'tax') a.tax = ids;
            else if (key === 'images') a.images = ids;
            else if (key === 'youtube') a.youtube = ids;
            else if (key === 'line') g.autoLine.channels = ids;
            else if (key === 'feelings') a.feelings.channel = ids[0] || null;
            else if (key === 'boost') a.boost.channel = ids[0] || null;
        },
        embed({ guild }) {
            const g = db.guild(guild.id);
            const a = g.automation;
            const list = ids => (ids.length ? clip(ids.map(ch).join(' '), 900) : 'لا يوجد');
            return e.base().setTitle('⚡ الأتمتة').addFields(
                { name: '💳 الضريبة التلقائية', value: list(a.tax), inline: false },
                { name: '🖼️ الصور فقط', value: list(a.images), inline: false },
                { name: '▶️ اليوتيوب فقط', value: list(a.youtube), inline: false },
                { name: `➖ الخط التلقائي ${g.autoLine.image ? '' : '(بدون صورة)'}`, value: list(g.autoLine.channels), inline: false },
                { name: '💭 المشاعر', value: `${ch(a.feelings.channel)}${a.feelings.anonymous ? ' • مجهول' : ''}`, inline: true },
                { name: '💜 شكر البوست', value: `${ch(a.boost.channel)}${a.boost.embed ? ' • امبد' : ''}`, inline: true },
                { name: '😀 التفاعل التلقائي', value: `${Object.keys(a.react).length} روم (من أمر \`تفاعل_تلقائي\`)`, inline: true }
            );
        },
        components({ guild }, state) {
            const g = db.guild(guild.id);
            const feature = this.features.find(x => x.key === state.feature) || this.features[0];
            const menu = new StringSelectMenuBuilder().setCustomId('dash:aut:feature').setPlaceholder('اختر الميزة')
                .addOptions(this.features.map(x => ({ label: x.label, value: x.key, emoji: x.emoji, default: x.key === feature.key })));
            return [
                row(menu),
                channelPicker('dash:aut:value', `${feature.emoji} ${feature.label}`, TEXT, this.read(g, feature.key), { max: feature.multi ? 25 : 1, guild }),
                row(
                    btn('dash:aut:boostmsg', 'رسالة البوست', '💜'),
                    btn('dash:aut:line', 'صورة الخط', '➖'),
                    btn('dash:aut:taxline', 'خط الضريبة', '💳'),
                    btn('dash:aut:anon', 'مشاعر مجهول', '🕶️')
                )
            ];
        },
        async handle(i, ctx, state, redraw) {
            const g = db.guild(ctx.guild.id);
            const a = g.automation;
            if (i.customId === 'dash:aut:feature') { state.feature = i.values[0]; return redraw(i); }
            if (i.customId === 'dash:aut:value') {
                const key = (this.features.find(x => x.key === state.feature) || this.features[0]).key;
                this.write(g, key, [...i.values]);
                db.save();
                return redraw(i);
            }
            if (i.customId === 'dash:aut:anon') { a.feelings.anonymous = !a.feelings.anonymous; db.save(); return redraw(i); }
            if (i.customId === 'dash:aut:boostmsg') {
                const s = await ask(i, 'رسالة شكر البوست', [
                    { id: 'text', label: 'الرسالة ({user} {server})', long: true, max: 1500, value: a.boost.message },
                    { id: 'embed', label: 'كامبد؟ اكتب نعم أو لا', max: 3, value: a.boost.embed ? 'نعم' : 'لا' }
                ]);
                if (!s) return;
                const text = s.fields.getTextInputValue('text').trim();
                if (!text) return fail(s, 'اكتب نص الرسالة.');
                a.boost.message = text;
                a.boost.embed = s.fields.getTextInputValue('embed').trim() === 'نعم';
                db.save();
                return redraw(null);
            }
            if (i.customId === 'dash:aut:line' || i.customId === 'dash:aut:taxline') {
                const isTax = i.customId === 'dash:aut:taxline';
                const s = await ask(i, isTax ? 'خط الضريبة' : 'صورة الخط التلقائي', [
                    { id: 'url', label: 'الرابط (اتركه فاضي للحذف)', required: false, max: 500, value: isTax ? a.taxLine : g.autoLine.image }
                ]);
                if (!s) return;
                const url = s.fields.getTextInputValue('url').trim();
                if (url && !/^https?:\/\//i.test(url)) return fail(s, 'اكتب رابط صحيح يبدأ بـ http.');
                if (isTax) a.taxLine = url || null; else g.autoLine.image = url || null;
                db.save();
                return redraw(null);
            }
        }
    },

    // ═══ الستاربورد والسجن ═══
    extras: {
        embed({ guild }) {
            const raw = extDb.raw();
            const star = extDb.getStarboardSettings(guild.id);
            const jail = extDb.getJailSettings(guild.id);
            const sug = extDb.getSuggestionSettings(guild.id);
            const count = obj => Object.values(obj).filter(x => x.guildId === guild.id).length;
            return e.base().setTitle('🧩 الستاربورد والسجن والإضافات').addFields(
                { name: '⭐ الستاربورد', value: star?.channelId ? `${ch(star.channelId)} • ${star.emoji || '⭐'} × **${star.threshold || 3}**` : 'غير مفعل', inline: false },
                { name: '⛓️ السجن', value: jail.jailRoleId ? `الرتبة ${role(jail.jailRoleId)}\nالروم ${ch(jail.jailChannelId)}\nالاستدعاء ${ch(jail.staffVoiceId)}` : 'غير مفعل', inline: false },
                { name: '💡 الاقتراحات المتقدمة', value: sug?.logChannelId ? `مراجعة: ${ch(sug.logChannelId)}${sug.autoThread ? ' • خيط تلقائي' : ''}` : 'استخدم أمر `اقتراحات_متقدم` لإعداد روم المراجعة', inline: false },
                { name: '📨 رتب الدعوات', value: `${raw.inviteRanks.filter(x => x.guildId === guild.id).length}`, inline: true },
                { name: '📌 رسائل مثبتة', value: `${count(raw.sticky)}`, inline: true },
                { name: '🎭 رتب التفاعل', value: `${raw.reactroles.filter(x => x.guildId === guild.id).length}`, inline: true },
                { name: '🎁 قيف أواي شغال', value: `${extDb.getActiveGiveaways(guild.id).length}`, inline: true }
            ).setFooter({ text: 'روم الستاربورد والسجن من قسم الرومات والسجلات' });
        },
        components({ guild }) {
            const jail = extDb.getJailSettings(guild.id);
            return [
                rolePicker('dash:ext:jailrole', '⛓️ رتبة السجن', jail.jailRoleId, { guild }),
                row(btn('dash:ext:star', 'إعداد الستاربورد (ايموجي/عدد)', '⭐'), btn('dash:ext:thread', 'خيط الاقتراحات التلقائي', '🧵'))
            ];
        },
        async handle(i, ctx, state, redraw) {
            if (i.customId === 'dash:ext:jailrole') {
                const j = extDb.getJailSettings(ctx.guild.id);
                const id = i.values[0] || null;
                if (id) {
                    const picked = ctx.guild.roles.cache.get(id);
                    if (!picked || picked.managed || picked.position >= ctx.guild.members.me.roles.highest.position) {
                        return i.reply({ embeds: [e.err('هذي الرتبة أعلى من رتبة البوت أو رتبة نظام.')], ...eph });
                    }
                }
                extDb.setJailSettings(ctx.guild.id, id, j.jailChannelId, j.staffVoiceId, j.staffRoleId);
                return redraw(i);
            }
            if (i.customId === 'dash:ext:thread') {
                const cur = extDb.getSuggestionSettings(ctx.guild.id);
                if (!cur) return i.reply({ embeds: [e.err('حدد روم الاقتراحات وروم المراجعة أول من قسم الرومات والسجلات.')], ...eph });
                extDb.setSuggestionSettings(ctx.guild.id, { ...cur, autoThread: !cur.autoThread });
                return redraw(i);
            }
            if (i.customId === 'dash:ext:star') {
                const cur = extDb.getStarboardSettings(ctx.guild.id) || {};
                const s = await ask(i, 'إعداد الستاربورد', [
                    { id: 'emoji', label: 'الايموجي', max: 60, value: cur.emoji || '⭐' },
                    { id: 'threshold', label: 'عدد التفاعلات المطلوبة', max: 3, value: String(cur.threshold || 3) }
                ]);
                if (!s) return;
                const threshold = Number(t.digits(s.fields.getTextInputValue('threshold')));
                const emoji = s.fields.getTextInputValue('emoji').trim();
                if (!emoji || !Number.isInteger(threshold) || threshold < 1 || threshold > 100) return fail(s, 'اكتب ايموجي وعدد من 1 إلى 100.');
                extDb.setStarboardSettings(ctx.guild.id, { ...cur, emoji, threshold });
                if (!cur.channelId) await s.followUp({ embeds: [e.warn('حدد روم الستاربورد من قسم الرومات والسجلات عشان يشتغل.')], ...eph }).catch(() => {});
                return redraw(null);
            }
        }
    },

    // ═══ النسخ الاحتياطي (لمالك البوت) ═══
    backup: {
        embed() {
            const b = db.meta().backup;
            return e.base(b.enabled ? e.colors.ok : e.colors.warn).setTitle('💾 النسخ الاحتياطي').addFields(
                { name: '🔁 النسخ اليومي', value: b.enabled ? '🟢 مفعل' : '🔴 متوقف', inline: true },
                { name: '📺 روم النسخ', value: ch(b.channelId), inline: true },
                { name: '🕐 آخر نسخة', value: b.last ? `${t.stamp(b.last, 'F')}\n${t.stamp(b.last, 'R')}` : 'لا يوجد', inline: false },
                { name: '📦 الحجم', value: b.lastSize ? `${(b.lastSize / 1024).toFixed(1)} KB` : '-', inline: true },
                { name: '⚠️ آخر خطأ', value: b.lastError || 'لا يوجد', inline: true }
            ).setFooter({ text: 'تنحفظ آخر 14 نسخة محلياً في مجلد backups، وللاستعادة استخدم الأمر استعادة مع ملف النسخة' });
        },
        components({ guild }) {
            const b = db.meta().backup;
            return [
                channelPicker('dash:bak:room', '📺 روم إرسال النسخة اليومية', TEXT, b.channelId, { guild }),
                row(btn('dash:bak:now', 'نسخة الآن', '💾', ButtonStyle.Primary), btn('dash:bak:toggle', b.enabled ? 'إيقاف اليومي' : 'تشغيل اليومي', '🔁'))
            ];
        },
        async handle(i, ctx, state, redraw) {
            const b = db.meta().backup;
            if (i.customId === 'dash:bak:room') {
                const id = i.values[0] || null;
                if (id) {
                    const channel = ctx.guild.channels.cache.get(id);
                    if (!channel?.permissionsFor(ctx.guild.members.me)?.has(['ViewChannel', 'SendMessages', 'AttachFiles'])) {
                        return i.reply({ embeds: [e.err('ما عندي صلاحية إرسال الملفات في هذا الروم.')], ...eph });
                    }
                }
                b.channelId = id;
                db.save();
                return redraw(i);
            }
            if (i.customId === 'dash:bak:toggle') { b.enabled = !b.enabled; db.save(); return redraw(i); }
            if (i.customId === 'dash:bak:now') {
                await i.deferUpdate();
                const res = await backup.run(ctx.client, `يدوي من الداشبورد بواسطة ${i.user.tag}`);
                await i.followUp({ embeds: [res.ok
                    ? e.ok(`تم إنشاء \`${res.name}\`\n${res.sent ? 'وأرسلت لروم النسخ ✅' : `محلية فقط: ${res.note}`}`, '💾 تم النسخ')
                    : e.err(`فشل النسخ: ${res.error}`)], ...eph }).catch(() => {});
                return redraw(null);
            }
        }
    }
};

Object.assign(sections, more.sections);
{
    const backupEntry = sectionsList.pop();
    sectionsList.push(...more.list, backupEntry);
}

module.exports = {
    category: 'الداشبورد',
    icon: '🗂️',
    commands: [
        {
            name: 'داشبورد',
            aliases: ['لوحة', 'لوحة_التحكم', 'dashboard', 'اعدادات', 'الاعدادات', 'اعدادات_السيرفر', 'بانل'],
            desc: 'لوحة تحكم كاملة داخل ديسكورد: الحماية، الرومات، الترحيب، التذاكر، المستويات، المتجر، الأتمتة، النسخ الاحتياطي',
            usage: 'داشبورد',
            perms: ['Administrator'],
            async run(message) {
                const ctx = { client: message.client, guild: message.guild, message, owner: isBotOwner(message.client, message.author.id, message.guild) };
                const state = { section: 'home', target: targets[0].key, feature: 'tax' };
                const visible = () => sectionsList.filter(s => !s.ownerOnly || ctx.owner);

                const view = () => {
                    if (!visible().some(s => s.key === state.section)) state.section = 'home';
                    const section = sections[state.section];
                    const menu = new StringSelectMenuBuilder().setCustomId('dash:section').setPlaceholder('📂 اختر القسم')
                        .addOptions(visible().map(s => ({ label: s.label, value: s.key, emoji: s.emoji, default: s.key === state.section })));
                    const embeds = [].concat(section.embed(ctx, state));
                    return {
                        embeds,
                        components: [row(menu), ...section.components(ctx, state).slice(0, 4)],
                        ...e.opts
                    };
                };

                const sent = await message.reply(view());
                const collector = sent.createMessageComponentCollector({ idle: 5 * 60000 });

                // i = التفاعل (لتحديث الرسالة مباشرة)، أو null بعد النوافذ فنحدث الرسالة نفسها
                const redraw = i => (i ? i.update(view()) : sent.edit(view()).catch(() => {}));

                collector.on('collect', async i => {
                    if (i.user.id !== message.author.id) {
                        return i.reply({ embeds: [e.err('هذي اللوحة مو لك، اكتب `داشبورد` بنفسك.')], ...eph }).catch(() => {});
                    }
                    try {
                        if (i.customId === 'dash:close') {
                            collector.stop('closed');
                            return i.update({ embeds: [e.info('🗂️ الداشبورد', 'تم إغلاق اللوحة.')], components: [] });
                        }
                        if (i.customId === 'dash:section') {
                            state.section = i.values[0];
                            return redraw(i);
                        }
                        const section = sections[state.section];
                        const pickup = sectionsList.find(s => s.key === state.section);
                        if (pickup?.ownerOnly && !ctx.owner) return;
                        await section.handle(i, ctx, state, redraw);
                    } catch (error) {
                        console.error('خطأ في الداشبورد:', error);
                        const payload = { embeds: [e.err('صار خطأ أثناء تنفيذ هذا الإجراء، حاول مرة ثانية.')], ...eph };
                        if (i.replied || i.deferred) i.followUp(payload).catch(() => {});
                        else i.reply(payload).catch(() => {});
                    }
                });

                collector.on('end', (_, reason) => {
                    if (reason !== 'closed') sent.edit({ components: [] }).catch(() => {});
                });
            }
        }
    ]
};
