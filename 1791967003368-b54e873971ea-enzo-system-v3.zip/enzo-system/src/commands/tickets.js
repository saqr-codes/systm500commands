const { ChannelType, PermissionFlagsBits: P } = require('discord.js');
const db = require('../utils/db');
const e = require('../utils/embeds');
const r = require('../utils/resolve');
const tickets = require('../core/tickets');

const staff = (message) => {
    const g = db.guild(message.guild.id);
    return message.member.permissions.has(P.ManageMessages) || (g.tickets.role && message.member.roles.cache.has(g.tickets.role));
};

const inTicket = async message => {
    if (!tickets.isTicket(message.channel)) {
        await e.reply(message, e.err('هذا الأمر يشتغل داخل روم تذكرة فقط.'));
        return false;
    }
    if (!staff(message)) {
        await e.reply(message, e.err('هذا الأمر لفريق الإدارة فقط.'));
        return false;
    }
    return true;
};

module.exports = {
    category: 'التذاكر',
    icon: '🎫',
    commands: [
        {
            name: 'تذكرة_اعداد',
            aliases: ['بانل_تذاكر', 'اعداد_تذاكر'],
            desc: 'إرسال لوحة فتح التذاكر في الروم',
            usage: 'تذكرة_اعداد',
            perms: ['Administrator'],
            async run(message) {
                await message.delete().catch(() => {});
                await message.channel.send({ embeds: [tickets.panel()], components: [tickets.panelRow()] });
            }
        },
        {
            name: 'تذكرة_رتبة',
            aliases: ['رتبة_الدعم'],
            desc: 'تحديد رتبة فريق الدعم',
            usage: 'تذكرة_رتبة @الرتبة',
            perms: ['Administrator'],
            async run(message, args) {
                const role = r.role(message, args.join(' '));
                if (!role) return e.reply(message, e.err('منشن الرتبة أو اكتب اسمها.'));
                db.guild(message.guild.id).tickets.role = role.id;
                db.save();
                return e.reply(message, e.ok(`رتبة الدعم الفني الآن ${role}`));
            }
        },
        {
            name: 'تذكرة_تصنيف',
            aliases: ['كاتجوري_التذاكر'],
            desc: 'تحديد تصنيف (كاتجوري) التذاكر',
            usage: 'تذكرة_تصنيف <ايدي التصنيف>',
            perms: ['Administrator'],
            async run(message, args) {
                const category = r.channel(message, args.join(' '));
                if (!category || category.type !== ChannelType.GuildCategory) {
                    return e.reply(message, e.err('اكتب ايدي التصنيف (الكاتجوري).'));
                }
                db.guild(message.guild.id).tickets.category = category.id;
                db.save();
                return e.reply(message, e.ok(`التذاكر الجديدة تنفتح داخل **${category.name}**`));
            }
        },
        {
            name: 'تذكرة_لوق',
            aliases: ['لوق_التذاكر'],
            desc: 'تحديد روم سجلات التذاكر',
            usage: 'تذكرة_لوق #الروم',
            perms: ['Administrator'],
            async run(message, args) {
                const channel = r.channel(message, args[0]);
                if (!channel || !channel.isTextBased()) return e.reply(message, e.err('منشن الروم.'));
                db.guild(message.guild.id).tickets.logs = channel.id;
                db.save();
                return e.reply(message, e.ok(`سجلات التذاكر راح تنرسل إلى ${channel}`));
            }
        },
        {
            name: 'اغلاق',
            aliases: ['سكر_تذكرة', 'اقفل_تذكرة'],
            desc: 'إغلاق التذكرة الحالية',
            usage: 'اغلاق',
            async run(message) {
                if (!tickets.isTicket(message.channel)) return e.reply(message, e.err('هذا الأمر يشتغل داخل روم تذكرة فقط.'));
                const ticket = db.guild(message.guild.id).tickets.open[message.channel.id];
                if (!staff(message) && ticket.owner !== message.author.id) return e.reply(message, e.err('ما عندك صلاحية إغلاق هذي التذكرة.'));
                await tickets.close(message.channel, message.author, payload => message.channel.send(payload));
            }
        },
        {
            name: 'استلام',
            aliases: ['استلم'],
            desc: 'استلام التذكرة',
            usage: 'استلام',
            async run(message) {
                if (!(await inTicket(message))) return;
                await tickets.claim(message.channel, message.member);
                return e.reply(message, e.ok(`${message.member} استلم التذكرة ✋`));
            }
        },
        {
            name: 'اضافة',
            aliases: ['ضيف_للتذكرة'],
            desc: 'إضافة عضو للتذكرة',
            usage: 'اضافة @العضو',
            async run(message, args) {
                if (!(await inTicket(message))) return;
                const member = await r.member(message, args[0]);
                if (!member) return e.reply(message, e.err('منشن العضو.'));
                await message.channel.permissionOverwrites.edit(member.id, { ViewChannel: true, SendMessages: true, ReadMessageHistory: true });
                return e.reply(message, e.ok(`تمت إضافة ${member} للتذكرة`));
            }
        },
        {
            name: 'ازالة',
            aliases: ['شيل_من_التذكرة'],
            desc: 'إزالة عضو من التذكرة',
            usage: 'ازالة @العضو',
            async run(message, args) {
                if (!(await inTicket(message))) return;
                const member = await r.member(message, args[0]);
                if (!member) return e.reply(message, e.err('منشن العضو.'));
                await message.channel.permissionOverwrites.delete(member.id);
                return e.reply(message, e.ok(`تمت إزالة ${member} من التذكرة`));
            }
        },
        {
            name: 'تسمية',
            aliases: ['غير_اسم_التذكرة'],
            desc: 'تغيير اسم روم التذكرة',
            usage: 'تسمية <الاسم>',
            async run(message, args) {
                if (!(await inTicket(message))) return;
                const name = args.join('-').slice(0, 90);
                if (!name) return e.reply(message, e.err('اكتب الاسم الجديد.'));
                await message.channel.setName(name);
                return e.reply(message, e.ok(`تم تغيير الاسم إلى **${name}**`));
            }
        },
        {
            name: 'نسخة',
            aliases: ['حفظ_التذكرة', 'ترانسكربت'],
            desc: 'حفظ نسخة نصية من محادثة التذكرة',
            usage: 'نسخة',
            async run(message) {
                if (!(await inTicket(message))) return;
                const file = await tickets.transcript(message.channel);
                return message.reply({ embeds: [e.ok('هذي نسخة من محادثة التذكرة 📄')], files: [file], ...e.opts });
            }
        },
        {
            name: 'التذاكر',
            aliases: ['التذاكر_المفتوحة'],
            desc: 'عرض التذاكر المفتوحة',
            usage: 'التذاكر',
            perms: ['ManageMessages'],
            async run(message) {
                const open = Object.entries(db.guild(message.guild.id).tickets.open);
                if (!open.length) return e.reply(message, e.info('🎫 التذاكر المفتوحة', 'ما فيه تذاكر مفتوحة.'));
                const lines = open.map(([id, tk]) =>
                    `<#${id}> • <@${tk.owner}> • ${tk.claimed ? `✋ <@${tk.claimed}>` : '⏳ بدون مستلم'}`
                ).join('\n');
                return e.reply(message, e.info(`🎫 التذاكر المفتوحة (${open.length})`, lines));
            }
        }
    ]
};
