const { ActionRowBuilder, StringSelectMenuBuilder, ComponentType, MessageFlags } = require('discord.js');
const config = require('../../config');
const db = require('../utils/db');
const e = require('../utils/embeds');
const { permNames } = require('../utils/mod');
const { norm } = require('../utils/text');

const prefixOf = message => (db.guild(message.guild.id).prefix ?? config.prefix);

const home = (message, categories) => {
    const prefix = prefixOf(message);
    const total = [...categories.values()].reduce((a, c) => a + c.commands.length, 0);
    const lines = [...categories.entries()]
        .map(([name, c]) => `${c.icon} **${name}** • ${c.commands.length} أمر`)
        .join('\n');
    return e.base()
        .setTitle(`📚 قائمة أوامر ${message.client.user.username}`)
        .setThumbnail(message.client.user.displayAvatarURL({ size: 256 }))
        .setDescription(
            `البريفكس: \`${prefix || 'بدون'}\` • عدد الأوامر: **${total}**\n\n${lines}\n\n` +
            `اختر قسم من القائمة بالأسفل، أو اكتب \`${prefix}اوامر <اسم الأمر>\` لتفاصيل أمر معين\n` +
            `💡 كل الأوامر تشتغل أيضاً بالسلاش: اكتب \`/\` واختر القسم (مثل \`/عقوبات حظر\` أو \`/اقتصاد رصيد\`)`
        );
};

const section = (message, name, category) => {
    const prefix = prefixOf(message);
    const lines = category.commands.map(c => `**${prefix}${c.name}**\n╰ ${c.desc}`).join('\n');
    return e.base()
        .setTitle(`${category.icon} ${name}`)
        .setDescription(lines.length > 4000 ? lines.slice(0, 3990) + '…' : lines);
};

const detail = (message, cmd) => {
    const prefix = prefixOf(message);
    const embed = e.base()
        .setTitle(`📖 أمر ${cmd.name}`)
        .setDescription(cmd.desc)
        .addFields(
            { name: '🧩 الاستخدام', value: `\`${prefix}${cmd.usage || cmd.name}\``, inline: false },
            { name: '🔁 الأسماء البديلة', value: cmd.aliases?.length ? cmd.aliases.map(a => `\`${a}\``).join(' • ') : 'لا يوجد', inline: false },
            { name: '🔐 الصلاحيات', value: cmd.perms?.length ? cmd.perms.map(p => permNames[p] || p).join(' • ') : 'للجميع', inline: false },
            { name: '📂 القسم', value: cmd.category, inline: false }
        );
    return embed;
};

module.exports = {
    category: 'المساعدة',
    icon: '📚',
    commands: [
        {
            name: 'اوامر',
            aliases: ['مساعدة', 'الاوامر', 'هيلب', 'قائمة'],
            desc: 'عرض قائمة الأوامر أو تفاصيل أمر معين',
            usage: 'اوامر [اسم الأمر]',
            async run(message, args) {
                const client = message.client;
                const categories = client.categories;

                if (args.length) {
                    const cmd = client.commands.get(norm(args[0]));
                    if (!cmd) return e.reply(message, e.err('ما لقيت هذا الأمر، اكتب `اوامر` لعرض القائمة.'));
                    return e.reply(message, detail(message, cmd));
                }

                const menu = disabled => new ActionRowBuilder().addComponents(
                    new StringSelectMenuBuilder()
                        .setCustomId('help:menu')
                        .setPlaceholder('اختر قسم الأوامر')
                        .setDisabled(disabled)
                        .addOptions([
                            { label: 'الرئيسية', value: '__home', emoji: '🏠' },
                            ...[...categories.entries()].map(([name, c]) => ({
                                label: name,
                                value: name,
                                description: `${c.commands.length} أمر`,
                                emoji: c.icon
                            }))
                        ])
                );

                const sent = await e.reply(message, home(message, categories), { components: [menu(false)] });
                const collector = sent.createMessageComponentCollector({
                    componentType: ComponentType.StringSelect,
                    time: 120000
                });

                collector.on('collect', async i => {
                    if (i.user.id !== message.author.id) {
                        return i.reply({ embeds: [e.err('هذي القائمة مو لك، اكتب الأمر بنفسك.')], flags: MessageFlags.Ephemeral });
                    }
                    const choice = i.values[0];
                    const embed = choice === '__home' ? home(message, categories) : section(message, choice, categories.get(choice));
                    return i.update({ embeds: [embed], components: [menu(false)] });
                });

                collector.on('end', () => {
                    sent.edit({ components: [menu(true)] }).catch(() => {});
                });
            }
        }
    ]
};
