// الجسر: يحمّل الأوامر الإضافية (سلاش) ويعرضها كأوامر عربية بالبريفكس + كأوامر سلاش حقيقية
const fs = require('fs');
const path = require('path');
const { PermissionsBitField } = require('discord.js');
const { norm } = require('../utils/text');
const { createFakeInteraction } = require('./utils/fakeInteraction');
const e = require('../utils/embeds');

const commandsDir = path.join(__dirname, 'commands');

// اسم الأمر الإنجليزي => [الاسم العربي، أسماء بديلة، القسم]
const names = {
    // الألعاب
    game: ['لعبة', ['العاب', 'games', 'game'], 'الألعاب'],
    // الموسيقى
    play: ['اغنية', ['play', 'p', 'شغل_اغنية'], 'الموسيقى'],
    skip: ['تخطي', ['skip', 'التالي'], 'الموسيقى'],
    stop: ['وقف_الموسيقى', ['stop', 'ايقاف_الموسيقى'], 'الموسيقى'],
    pause: ['ايقاف_مؤقت', ['pause'], 'الموسيقى'],
    resume: ['استكمال', ['resume', 'كمل'], 'الموسيقى'],
    queue: ['قائمة_التشغيل', ['queue', 'الطابور'], 'الموسيقى'],
    nowplaying: ['الان', ['nowplaying', 'np', 'الحين'], 'الموسيقى'],
    volume: ['مستوى_الصوت', ['volume', 'vol'], 'الموسيقى'],
    loop: ['تكرار', ['loop'], 'الموسيقى'],
    '247': ['247', ['24/7', 'بقاء'], 'الموسيقى'],
    // مسابقات
    box: ['صندوق', ['box', 'صندوق_الجائزة'], 'المسابقات'],
    final: ['اخر_رسالة', ['final', 'فاينل'], 'المسابقات'],
    gemoji: ['ايموجي_قيف', ['gemoji'], 'المسابقات'],
    giveaway: ['قيف', ['giveaway', 'قيف_اواي', 'جيف_اواي'], 'المسابقات'],
    // الدعوات
    invites: ['دعوات', ['invites', 'دعواتي'], 'الدعوات'],
    info: ['معلومات_دعوات', ['info', 'انفو_دعوات'], 'الدعوات'],
    addrank: ['رتبة_دعوات', ['addrank'], 'الدعوات'],
    resetinvites: ['تصفير_دعوات', ['resetinvites'], 'الدعوات'],
    setlogs: ['لوق_دعوات', ['setlogs'], 'الدعوات'],
    // إدارة إضافية
    jail: ['سجن', ['jail'], 'إدارة إضافية'],
    sticky: ['تثبيت_رسالة', ['sticky', 'ستيكي'], 'إدارة إضافية'],
    starboard: ['ستاربورد', ['starboard'], 'إدارة إضافية'],
    'suggestion-setup': ['اقتراحات_متقدم', ['suggestion-setup', 'suggestion_setup', 'اعداد_اقتراحات_متقدم'], 'إدارة إضافية'],
    reactrole: ['رتبة_تفاعل', ['reactrole', 'رياكشن_رول'], 'إدارة إضافية'],
    topchannel: ['رفع_روم', ['topchannel'], 'إدارة إضافية'],
    // عامة
    afk: ['خمول', ['afk'], 'خدمات إضافية'],
    snipe: ['سنايب', ['snipe', 'المحذوف'], 'خدمات إضافية'],
    suggest: ['اقتراح', ['suggest', 'اقترح'], 'خدمات إضافية']
};

// اختصارات عربية مباشرة لكل لعبة: -قنبلة => -لعبة bomb
const gamePresets = {
    bomb: ['قنبلة', ['bomb']],
    chairs: ['كراسي', ['chairs']],
    faster: ['اسرع', ['faster']],
    mafia: ['مافيا', ['mafia']],
    button: ['زر', ['button']],
    roulette: ['روليت', ['roulette']],
    flags: ['اعلام', ['flags']],
    colors: ['الوان', ['colors']],
    salfa: ['سالفة', ['salfa']]
};

const icons = {
    'الألعاب': '🎮', 'الموسيقى': '🎵', 'المسابقات': '🎁', 'الدعوات': '📨',
    'إدارة إضافية': '🧩', 'خدمات إضافية': '✨'
};

const permsOf = cmd => {
    const raw = cmd.data.toJSON().default_member_permissions;
    return raw ? new PermissionsBitField(BigInt(raw)).toArray() : [];
};

const optionSummary = json => {
    const subs = (json.options || []).filter(o => o.type === 1);
    if (subs.length) return `<${subs.map(s => s.name).join('|')}>`;
    return (json.options || []).map(o => (o.required ? `<${o.name}>` : `[${o.name}]`)).join(' ');
};

const needsArgs = (json, args) => {
    const opts = json.options || [];
    if (opts.some(o => o.type === 1)) return args.length === 0;
    return args.length === 0 && opts.some(o => o.required);
};

const makeRun = (cmd, presetArgs = [], category = '') => async (message, args) => {
    const json = cmd.data.toJSON();
    if (category === 'الموسيقى' && !message.client.manager) {
        return e.reply(message, e.err('الموسيقى غير مفعلة، المالك لازم يضيف `LAVALINK_NODES` في ملف `.env`.'));
    }
    const full = [...presetArgs, ...args];
    if (needsArgs(json, full)) {
        const subs = (json.options || []).filter(o => o.type === 1);
        const lines = subs.length
            ? subs.map(s => `• \`${s.name}\` — ${s.description}`).join('\n')
            : (json.options || []).map(o => `• \`${o.name}\`${o.required ? ' (مطلوب)' : ''} — ${o.description}`).join('\n');
        return e.reply(message, e.info(`📖 ${json.description}`, `الاستخدام: \`${message.content.split(/\s+/)[0]} ${optionSummary(json)}\`\n\n${lines}`));
    }
    const fake = await createFakeInteraction(message, cmd, full);
    try {
        await cmd.execute(fake);
    } catch (err) {
        console.error(`خطأ في الأمر ${json.name}:`, err);
        const payload = { embeds: [e.err('صار خطأ غير متوقع أثناء تنفيذ الأمر.')] };
        (fake.replied || fake.deferred ? fake.editReply(payload) : message.reply(payload)).catch(() => null);
    }
};

const loadFiles = () => {
    const list = [];
    for (const dir of fs.readdirSync(commandsDir)) {
        const full = path.join(commandsDir, dir);
        if (!fs.statSync(full).isDirectory()) continue;
        for (const file of fs.readdirSync(full).filter(f => f.endsWith('.js'))) {
            try {
                const mod = require(path.join(full, file));
                if (mod.data && mod.execute) list.push(mod);
            } catch (err) {
                console.error(`تعذر تحميل ${dir}/${file}:`, err.message);
            }
        }
    }
    return list;
};

const load = client => {
    client.extSlash = new Map();
    const mods = loadFiles();
    const extraCategories = new Map();

    const register = (def, category) => {
        const keys = [def.name, ...(def.aliases || [])];
        const free = keys.filter(k => !client.commands.has(norm(k)));
        const skipped = keys.filter(k => !free.includes(k));
        if (skipped.length) console.warn(`[ext] أسماء محجوزة سابقاً وتم تخطيها للأمر ${def.name}: ${skipped.join(', ')}`);
        if (!free.length) return false;
        for (const k of free) client.commands.set(norm(k), def);
        def.category = category;
        if (!extraCategories.has(category)) extraCategories.set(category, { icon: icons[category] || '🧩', commands: [] });
        extraCategories.get(category).commands.push(def);
        return true;
    };

    for (const cmd of mods) {
        const json = cmd.data.toJSON();
        client.extSlash.set(json.name, cmd);
        const [ar, aliases, category] = names[json.name] || [json.name, [], 'خدمات إضافية'];
        register({
            name: ar,
            aliases: aliases.filter(a => a !== ar),
            desc: json.description,
            usage: `${ar} ${optionSummary(json)}`.trim(),
            perms: permsOf(cmd),
            run: makeRun(cmd, [], category)
        }, category);

        if (json.name === 'game') {
            for (const sub of (json.options || []).filter(o => o.type === 1)) {
                const preset = gamePresets[sub.name];
                if (!preset) continue;
                register({
                    name: preset[0],
                    aliases: preset[1],
                    desc: sub.description,
                    usage: preset[0],
                    perms: [],
                    run: makeRun(cmd, [sub.name])
                }, 'الألعاب');
            }
        }
    }

    for (const [name, cat] of extraCategories) client.categories.set(name, cat);
    return mods.length;
};

module.exports = { load };
