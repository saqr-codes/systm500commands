// معالجة أزرار ونوافذ الميزات الإضافية (اقتراحات + صندوق الجائزة)
const {
    EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder,
    TextInputBuilder, TextInputStyle, PermissionsBitField, MessageFlags
} = require('discord.js');
const db = require('./database/db');

const eph = { flags: MessageFlags.Ephemeral };

const voteRow = (up, down) => new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('suggest_vote_up').setLabel(`موافق 👍 (${up})`).setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('suggest_vote_down').setLabel(`معارض 👎 (${down})`).setStyle(ButtonStyle.Danger)
);

const button = async interaction => {
    const id = interaction.customId;

    if (id === 'suggest_vote_up' || id === 'suggest_vote_down') {
        await interaction.deferReply(eph).catch(() => null);
        const s = db.getSuggestion(interaction.message.id);
        if (!s) return interaction.editReply({ content: '{emoji:circlex} لم يتم العثور على بيانات هذا الاقتراح' });
        s.upvoters ||= [];
        s.downvoters ||= [];
        const uid = interaction.user.id;
        const [mine, other] = id === 'suggest_vote_up' ? ['upvoters', 'downvoters'] : ['downvoters', 'upvoters'];
        if (s[mine].includes(uid)) s[mine] = s[mine].filter(x => x !== uid);
        else { s[mine].push(uid); s[other] = s[other].filter(x => x !== uid); }
        db.updateSuggestionVotes(s.messageId, s.upvoters, s.downvoters);
        await interaction.message.edit({ components: [voteRow(s.upvoters.length, s.downvoters.length)] }).catch(() => null);
        return interaction.editReply({ content: '{emoji:circlecheck} تم تسجيل صوتك بنجاح' });
    }

    if (id.startsWith('suggest_accept_') || id.startsWith('suggest_reject_')) {
        const accept = id.startsWith('suggest_accept_');
        const msgId = id.replace(accept ? 'suggest_accept_' : 'suggest_reject_', '');
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
            return interaction.reply({ content: '{emoji:circlex} ليس لديك صلاحية لإدارة الاقتراحات.', ...eph });
        }
        const modal = new ModalBuilder()
            .setCustomId(`suggest_modal_${accept ? 'accept' : 'reject'}_${msgId}`)
            .setTitle(accept ? 'قبول الاقتراح' : 'رفض الاقتراح');
        modal.addComponents(new ActionRowBuilder().addComponents(
            new TextInputBuilder()
                .setCustomId('reason')
                .setLabel(accept ? 'ملاحظة القبول (اختياري)' : 'سبب الرفض (إجباري)')
                .setStyle(TextInputStyle.Paragraph)
                .setRequired(!accept)
        ));
        return interaction.showModal(modal);
    }

    if (id.startsWith('box_')) {
        if (id === 'box_claimed') return;
        const prize = decodeURIComponent(id.split('_').slice(3).join('_'));
        const disabled = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('box_claimed').setLabel('تم الاستلام').setEmoji('🎁').setStyle(ButtonStyle.Secondary).setDisabled(true)
        );
        const win = new EmbedBuilder().setColor(0x57f287).setTitle('{emoji:gift} تم الاستلام')
            .setDescription(`${interaction.user} استلم صندوق الغموض\n**الجائزة** ${prize}`).setTimestamp();
        return interaction.update({ embeds: [win], components: [disabled] });
    }
};

const modal = async interaction => {
    const id = interaction.customId;
    if (!id.startsWith('suggest_modal_accept_') && !id.startsWith('suggest_modal_reject_')) return;

    await interaction.deferReply(eph).catch(() => null);
    const accept = id.startsWith('suggest_modal_accept_');
    const msgId = id.replace(accept ? 'suggest_modal_accept_' : 'suggest_modal_reject_', '');
    const note = interaction.fields.getTextInputValue('reason') || (accept ? 'لا توجد ملاحظات' : 'بدون سبب');

    const s = db.getSuggestion(msgId);
    if (!s) return interaction.editReply({ content: '{emoji:circlex} لم يتم العثور على بيانات هذا الاقتراح' });
    db.updateSuggestionStatus(msgId, accept ? 'accepted' : 'rejected', interaction.user.id, note);

    const settings = db.getSuggestionSettings(interaction.guildId);
    const publicChan = settings?.channelId && interaction.guild.channels.cache.get(settings.channelId);
    const publicMsg = publicChan && await publicChan.messages.fetch(msgId).catch(() => null);
    if (publicMsg?.embeds[0]) {
        const e = EmbedBuilder.from(publicMsg.embeds[0]).setColor(accept ? 0x57f287 : 0xed4245);
        const fields = e.data.fields || [];
        const value = accept
            ? `{emoji:circlecheck} **تم القبول**\n- **المشرف:** <@${interaction.user.id}>\n- **ملاحظة:** '${note}'`
            : `{emoji:circlex} **تم الرفض**\n- **المشرف:** <@${interaction.user.id}>\n- **السبب:** '${note}'`;
        const i = fields.findIndex(f => f.name.includes('الحالة'));
        if (i !== -1) fields[i].value = value; else fields.push({ name: '**الحالة:**', value, inline: true });
        e.setFields(fields);
        await publicMsg.edit({ embeds: [e], components: [] }).catch(() => null);
    }

    if (interaction.message?.embeds[0]) {
        const e = EmbedBuilder.from(interaction.message.embeds[0]).setColor(accept ? 0x57f287 : 0xed4245)
            .addFields({
                name: accept ? '**حالة المراجعة: مقبول ✅**' : '**حالة المراجعة: مرفوض ❌**',
                value: `- **المراجع:** <@${interaction.user.id}>\n- **السبب/الملاحظة:** '${note}'`
            });
        await interaction.message.edit({ embeds: [e], components: [] }).catch(() => null);
    }

    return interaction.editReply({ content: `{emoji:circlecheck} تم معالجة الاقتراح بنجاح كـ ${accept ? 'مقبول' : 'مرفوض'}` });
};

// يرجع true إذا تعامل مع التفاعل
module.exports = async (client, interaction) => {
    if (interaction.isChatInputCommand()) {
        const cmd = client.extSlash?.get(interaction.commandName);
        if (!cmd) return false;
        try {
            await cmd.execute(interaction);
        } catch (err) {
            console.error(`خطأ في أمر السلاش ${interaction.commandName}:`, err);
            const payload = { content: '❌ حدث خطأ أثناء تنفيذ الأمر.', ...eph };
            (interaction.deferred || interaction.replied ? interaction.editReply(payload) : interaction.reply(payload)).catch(() => null);
        }
        return true;
    }
    if (interaction.isButton() && /^(suggest_|box_)/.test(interaction.customId)) { await button(interaction); return true; }
    if (interaction.isModalSubmit() && interaction.customId.startsWith('suggest_modal_')) { await modal(interaction); return true; }
    return false;
};
