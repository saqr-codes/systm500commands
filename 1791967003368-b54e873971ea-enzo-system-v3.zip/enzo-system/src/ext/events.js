// أحداث الميزات الإضافية: AFK, ستيكي, سنايب, ستاربورد, رتب التفاعل, تتبع الدعوات, قيف أواي
const { EmbedBuilder, PermissionFlagsBits, Events } = require('discord.js');
const db = require('./database/db');
const { later } = require('../utils/timers');

const safe = fn => (...args) => Promise.resolve(fn(...args)).catch(err => console.error('[ext]', err));

const install = client => {
    client.inviteCache = new Map();
    client.stickyTimeouts = new Map();

    // ═══ الرسائل: AFK + رسالة مثبتة ═══
    client.on('messageCreate', safe(async message => {
        if (!message.guild) return;

        if (message.author.id !== client.user.id) {
            const sticky = db.getStickyMessage(message.channelId);
            if (sticky?.enabled) {
                clearTimeout(client.stickyTimeouts.get(message.channelId));
                client.stickyTimeouts.set(message.channelId, setTimeout(async () => {
                    client.stickyTimeouts.delete(message.channelId);
                    const cur = db.getStickyMessage(message.channelId);
                    if (!cur?.enabled) return;
                    if (cur.lastMessageId) {
                        const old = await message.channel.messages.fetch(cur.lastMessageId).catch(() => null);
                        if (old) await old.delete().catch(() => null);
                    }
                    const sent = await message.channel.send({ content: `__**رسالة مثبتة**__\n\n${cur.content}` }).catch(() => null);
                    if (sent) db.updateStickyMessageId(message.channelId, sent.id);
                }, 3000));
            }
        }

        if (message.author.bot || !message.member) return;

        if (db.getAFK(message.guild.id, message.author.id)) {
            db.removeAFK(message.guild.id, message.author.id);
            const name = message.member.displayName;
            if (name.startsWith('[AFK] ')) await message.member.setNickname(name.slice(6)).catch(() => null);
            message.reply({ content: `{emoji:circlecheck} مرحباً بعودتك <@${message.author.id}>، تم إيقاف وضع الـ **AFK** تلقائياً`, allowedMentions: { parse: [], repliedUser: false } })
                .then(m => setTimeout(() => m.delete().catch(() => null), 5000)).catch(() => null);
        }

        for (const [id, member] of message.mentions.members ?? []) {
            if (id === message.author.id) continue;
            const afk = db.getAFK(message.guild.id, id);
            if (afk) {
                message.reply({
                    content: `{emoji:clock} **${member.displayName}** في وضع الخمول حالياً\n- **السبب:** '${afk.reason}'\n- **منذ:** <t:${Math.floor(afk.timestamp / 1000)}:R>`,
                    allowedMentions: { parse: [], repliedUser: false }
                }).catch(() => null);
            }
        }
    }));

    // ═══ سنايب ═══
    client.on('messageDelete', safe(async message => {
        if (!message.guild || !message.author || message.author.bot || !message.content) return;
        db.setSnipe(message.channelId, message.content, message.author.id, message.author.tag, message.author.displayAvatarURL());
    }));

    // ═══ ستاربورد + رتب التفاعل ═══
    const fetchReaction = async reaction => {
        if (reaction.partial) await reaction.fetch();
        if (reaction.message.partial) await reaction.message.fetch();
    };

    const starboard = async reaction => {
        const guildId = reaction.message.guildId;
        const settings = db.getStarboardSettings(guildId);
        if (!settings?.channelId || reaction.emoji.name !== settings.emoji) return;
        const stars = reaction.count;
        const channel = reaction.message.guild.channels.cache.get(settings.channelId);
        if (!channel) return;
        const post = db.getStarboardPost(reaction.message.id);

        if (stars < settings.threshold) {
            if (post) {
                const m = await channel.messages.fetch(post.starboardMessageId).catch(() => null);
                if (m) await m.delete().catch(() => null);
                db.removeStarboardPost(reaction.message.id);
            }
            return;
        }

        const msg = reaction.message;
        const embed = new EmbedBuilder().setColor(0xffd700)
            .setAuthor({ name: msg.author.tag, iconURL: msg.author.displayAvatarURL() })
            .setDescription(msg.content || '_رسالة فارغة (صورة أو ملف)_')
            .addFields({ name: 'المصدر', value: `[انتقال للرسالة](${msg.url}) في <#${msg.channelId}>` })
            .setTimestamp(msg.createdAt);
        const img = msg.attachments?.first();
        if (img?.contentType?.startsWith('image/')) embed.setImage(img.url);
        const content = `${settings.emoji} **${stars}** | <#${msg.channelId}>`;

        if (post) {
            const m = await channel.messages.fetch(post.starboardMessageId).catch(() => null);
            if (m) { await m.edit({ content, embeds: [embed] }).catch(() => null); db.updateStarboardPost(msg.id, stars); }
        } else {
            const sent = await channel.send({ content, embeds: [embed] }).catch(() => null);
            if (sent) db.addStarboardPost(guildId, msg.id, sent.id, stars);
        }
    };

    client.on('messageReactionAdd', safe(async (reaction, user) => {
        if (user.bot) return;
        await fetchReaction(reaction);
        if (!reaction.message.guildId) return;
        await starboard(reaction);
        const rr = db.getReactRole(reaction.message.id, reaction.emoji.id || reaction.emoji.name);
        if (rr) {
            const member = await reaction.message.guild.members.fetch(user.id).catch(() => null);
            if (member) await member.roles.add(rr.roleId).catch(() => null);
        }
    }));

    client.on('messageReactionRemove', safe(async (reaction, user) => {
        if (user.bot) return;
        await fetchReaction(reaction);
        if (!reaction.message.guildId) return;
        await starboard(reaction);
        const rr = db.getReactRole(reaction.message.id, reaction.emoji.id || reaction.emoji.name);
        if (rr) {
            const member = await reaction.message.guild.members.fetch(user.id).catch(() => null);
            if (member) await member.roles.remove(rr.roleId).catch(() => null);
        }
    }));

    // ═══ تتبع الدعوات ═══
    client.on('guildMemberAdd', safe(async member => {
        const { guild } = member;
        if (member.user.bot || !guild.members.me?.permissions.has(PermissionFlagsBits.ManageGuild)) return;
        const cached = client.inviteCache.get(guild.id) || new Map();
        const current = await guild.invites.fetch().catch(() => null);
        if (!current) return;
        const used = current.find(i => i.uses > (cached.get(i.code) || 0));
        client.inviteCache.set(guild.id, new Map(current.map(i => [i.code, i.uses])));
        if (!used?.inviter) return;

        const inviterId = used.inviter.id;
        db.setInviter(member.id, guild.id, inviterId);
        db.updateInvites(inviterId, guild.id, 'total', 1);
        if (Date.now() - member.user.createdTimestamp < 7 * 86400000) db.updateInvites(inviterId, guild.id, 'fake', 1);

        const d = db.getInvites(inviterId, guild.id);
        const real = d.total - d.fake - d.left;
        for (const rank of db.getInviteRanks(guild.id)) {
            if (real >= rank.count) {
                const inviter = await guild.members.fetch(inviterId).catch(() => null);
                if (inviter && !inviter.roles.cache.has(rank.roleId)) inviter.roles.add(rank.roleId).catch(() => null);
            }
        }

        const logs = db.getInviteLogs(guild.id);
        const ch = logs?.channelId && await client.channels.fetch(logs.channelId).catch(() => null);
        if (ch) {
            ch.send({
                embeds: [new EmbedBuilder().setColor(0x57f287).setTitle('{emoji:mail} انضمام عضو')
                    .setThumbnail(member.user.displayAvatarURL())
                    .setDescription(`${member} انضم\n**تمت دعوته بواسطة** <@${inviterId}> (${real} دعوات حقيقية)\n**كود الدعوة** \`${used.code}\``)
                    .setTimestamp()],
                allowedMentions: { parse: [] }
            }).catch(() => null);
        }
    }));

    client.on('guildMemberRemove', safe(async member => {
        const inviterOf = db.takeInviter(member.id, member.guild.id);
        if (inviterOf) db.updateInvites(inviterOf, member.guild.id, 'left', 1);

        const logs = db.getInviteLogs(member.guild.id);
        const ch = logs?.channelId && await client.channels.fetch(logs.channelId).catch(() => null);
        if (ch) {
            ch.send({
                embeds: [new EmbedBuilder().setColor(0xed4245).setTitle('{emoji:mail} مغادرة عضو')
                    .setThumbnail(member.user?.displayAvatarURL() ?? null)
                    .setDescription(`${member.user?.tag ?? 'عضو غير معروف'} غادر السيرفر\n**عدد الأعضاء** ${member.guild.memberCount}`)
                    .setTimestamp()]
            }).catch(() => null);
        }
    }));

    client.on('inviteCreate', safe(async invite => {
        const map = client.inviteCache.get(invite.guild.id) || new Map();
        map.set(invite.code, invite.uses || 0);
        client.inviteCache.set(invite.guild.id, map);
    }));

    // ═══ عند التشغيل ═══
    client.once(Events.ClientReady, safe(async () => {
        for (const guild of client.guilds.cache.values()) {
            const invites = await guild.invites.fetch().catch(() => null);
            if (invites) client.inviteCache.set(guild.id, new Map(invites.map(i => [i.code, i.uses])));
        }

        if (client.manager) {
            client.manager.init({ id: client.user.id, username: client.user.username });
            client.on('raw', d => client.manager.sendRawData(d));
        }

        const { endGiveawayTimer } = require('./utils/giveaway');
        for (const g of db.getAllActiveGiveaways()) {
            const remaining = g.endTime * 1000 - Date.now();
            later(() => endGiveawayTimer(client, g).catch(() => null), remaining);
        }

        require('../utils/backup').start(client);
    }));
};

module.exports = { install };
