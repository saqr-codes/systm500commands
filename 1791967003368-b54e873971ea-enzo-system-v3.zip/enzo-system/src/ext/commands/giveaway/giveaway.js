const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const db = require('../../database/db');
const { later } = require('../../../utils/timers');
const { parseDuration, formatDuration, endGiveawayTimer } = require('../../utils/giveaway');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('giveaway')
    .setDescription('نظام القيف أواي')
    .addSubcommand((s) =>
      s
        .setName('start')
        .setDescription('بدء قيف أواي')
        .addStringOption((o) => o.setName('duration').setDescription('المدة مثل 10m أو 2h أو 1d').setRequired(true))
        .addIntegerOption((o) =>
          o.setName('winners').setDescription('عدد الفائزين').setRequired(true).setMinValue(1).setMaxValue(20)
        )
        .addStringOption((o) => o.setName('prize').setDescription('الجائزة').setRequired(true))
    )
    .addSubcommand((s) =>
      s
        .setName('end')
        .setDescription('إنهاء قيف أواي الآن')
        .addStringOption((o) => o.setName('message_id').setDescription('ايدي رسالة القيف أواي').setRequired(true))
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'start') {
      const seconds = parseDuration(interaction.options.getString('duration'));
      if (!seconds) return interaction.reply({ content: '❌ مدة غير صحيحة، مثال: `10m` أو `2h` أو `1d`', flags: ['Ephemeral'] });
      const winners = interaction.options.getInteger('winners');
      const prize = interaction.options.getString('prize');
      const emoji = db.getGuildSettings(interaction.guildId).giveaway_emoji || '🎉';
      const endTime = Math.floor(Date.now() / 1000) + seconds;

      const embed = new EmbedBuilder()
        .setColor(0xff73fa)
        .setTitle('{emoji:gift} قيف أواي')
        .setDescription(
          `**الجائزة** ${prize}\n**الفائزين** ${winners}\n**المدة** ${formatDuration(seconds)}\n**ينتهي** <t:${endTime}:R>\n\nتفاعل بـ ${emoji} للمشاركة`
        )
        .setFooter({ text: `بواسطة ${interaction.user.tag}` })
        .setTimestamp(endTime * 1000);

      const msg = await interaction.channel.send({ embeds: [embed] });
      await msg.react(emoji).catch(() => null);
      db.createGiveaway(msg.id, interaction.channelId, interaction.guildId, prize, winners, interaction.user.id, endTime, emoji);

      const giveaway = db.getGiveaway(msg.id);
      later(() => endGiveawayTimer(interaction.client, giveaway).catch(() => null), seconds * 1000);
      return interaction.reply({ content: '✅ تم بدء القيف أواي', flags: ['Ephemeral'] });
    }

    if (sub === 'end') {
      const g = db.getGiveaway(interaction.options.getString('message_id'));
      if (!g || g.ended || g.guildId !== interaction.guildId) {
        return interaction.reply({ content: '❌ ما لقيت قيف أواي شغال بهذا الايدي', flags: ['Ephemeral'] });
      }
      await endGiveawayTimer(interaction.client, g);
      return interaction.reply({ content: '✅ تم إنهاء القيف أواي', flags: ['Ephemeral'] });
    }
  }
};
