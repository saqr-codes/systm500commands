const logger = require('../../utils/logger');
const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder
} = require('discord.js');
const locale = require('../../utils/locale');
const { success } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('box')
    .setDescription('إرسال صندوق الجائزة')
    .addStringOption((o) => o.setName('prize').setDescription('الجائزة').setRequired(true))
    .addChannelOption((o) => o.setName('channel').setDescription('روم صندوق الجائزة'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    try {
      const prize = interaction.options.getString('prize');
      const channel = interaction.options.getChannel('channel') || interaction.channel;

      const embed = new EmbedBuilder()
        .setColor(0xff73fa)
        .setTitle('{emoji:gift} صندوق الغموض')
        .setDescription(`**${interaction.user.tag}** أرسل صندوق الغموض\nالجائزة: **${prize}**\n\nأول من يضغط الزر يفوز`)
        .setTimestamp();

            const button = new ButtonBuilder()
        .setCustomId(`box_${interaction.user.id}_${Date.now()}_${encodeURIComponent(prize)}`)
        .setLabel('اضغط للفوز')
        .setEmoji('🎁')
        .setStyle(ButtonStyle.Success);

      const row = new ActionRowBuilder().addComponents(button);

      await channel.send({ embeds: [embed], components: [row] });
      return interaction.reply({ embeds: [success(locale.get('giveaway.boxSent'))], flags: ['Ephemeral'] });
    } catch (err) {
      logger.error('[Command Error - box.js]:', err);
      if (interaction && typeof interaction.reply === 'function') {
        await interaction
          .reply({ content: '❌ حدث خطأ أثناء تنفيذ هذا الأمر.', flags: ['Ephemeral'] })
          .catch(() => null);
      }
    }
  }
};
