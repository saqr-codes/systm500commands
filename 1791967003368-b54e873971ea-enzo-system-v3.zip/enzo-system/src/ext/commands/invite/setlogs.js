const locale = require('../../utils/locale');
const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { success } = require('../../utils/embeds');
const db = require('../../database/db');
const logger = require('../../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setlogs')
    .setDescription('سجلات دخول وخروج')
    .addChannelOption((o) =>
      o
        .setName('channel')
        .setDescription('روم الدخول والخروج')
        .setRequired(true)
        .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    try {
      const ch = interaction.options.getChannel('channel');
      db.setInviteLogs(interaction.guildId, ch.id);
      return interaction.reply({ embeds: [success(locale.get('invites.logsSet', { channel: ch }))] });
    } catch (err) {
      logger.error('[Command Error - setlogs.js]:', err);
      if (interaction && typeof interaction.reply === 'function') {
        await interaction
          .reply({ content: '❌ حدث خطأ أثناء تنفيذ هذا الأمر.', flags: ['Ephemeral'] })
          .catch(() => null);
      }
    }
  }
};
