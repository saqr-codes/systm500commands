const { EmbedBuilder } = require('discord.js');

const colors = { success: 0x57f287, error: 0xed4245, warning: 0xfee75c, info: 0x5865f2, primary: 0x5865f2, moderation: 0xff6b6b, level: 0xffd700, giveaway: 0xff73fa, ticket: 0x00b0f4 };

const embed = (type = 'info') => new EmbedBuilder().setColor(colors[type] || colors.info).setTimestamp();

const make = (type, icon) => (title, description) => {
    const e = embed(type);
    if (description) return e.setTitle(`${icon} __${title}__`).setDescription(String(description).includes('**') ? description : `**${description}**`);
    return e.setDescription(String(title).includes('**') ? title : `**${title}**`);
};

module.exports = {
    embed, colors,
    success: make('success', '{emoji:circlecheck}'),
    error: make('error', '{emoji:circlex}'),
    warn: make('warning', '{emoji:alerttriangle}'),
    info: make('info', '{emoji:infocircle}')
};
