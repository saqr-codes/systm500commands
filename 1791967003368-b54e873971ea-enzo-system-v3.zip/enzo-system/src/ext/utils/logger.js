const fmt = (lvl, args) => console[lvl === 'error' ? 'error' : lvl === 'warn' ? 'warn' : 'log'](`[${lvl.toUpperCase()}]`, ...args);
const logger = {
    info: (...a) => fmt('info', a),
    warn: (...a) => fmt('warn', a),
    error: (...a) => fmt('error', a),
    debug: () => {}
};
logger.logger = logger;
logger.sendLog = async () => {};
module.exports = logger;
