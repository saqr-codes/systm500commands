// يحول {emoji:اسم} إلى إيموجي عادي على كل رسائل البوت (بدون الحاجة لإيموجيات مخصصة)
const { EmbedBuilder, MessagePayload, ModalBuilder } = require('discord.js');

const map = {
    user: '👤', circlecheck: '✅', circlex: '❌', mail: '✉️', trash: '🗑️', lock: '🔒', clock: '🕒', shield: '🛡️',
    shieldlock: '🔐', shieldcheck: '🛡️', list: '📋', alerttriangle: '⚠️', confetti: '🎉', message: '💬', mic: '🎙️',
    settings: '⚙️', chartpie: '📊', star: '⭐', crown: '👑', ticket: '🎫', adjustments: '🛠️', folderopen: '📂',
    folder: '📁', gift: '🎁', infocircle: 'ℹ️', trophy: '🏆', bell: '🔔', bellringing: '🔔', flag: '🚩', bolt: '⚡',
    flame: '🔥', heart: '❤️', thumbup: '👍', thumbdown: '👎', bookmark: '🔖', briefcase: '💼', photo: '🖼️',
    moodsmile: '😄', playerplay: '▶️', playerpause: '⏸️', playerstop: '⏹️', stop: '⏹️', music_play: '▶️',
    music_next: '⏭️', music_loop_track: '🔂', music_replay: '🔁', layoutdashboard: '🗂️', brandyoutube: '▶️'
};

const replaceEmojis = text => typeof text !== 'string' ? text
    : text.replace(/{emoji:(\w+)}/g, (m, name) => map[name] || m);

const deep = obj => {
    if (typeof obj === 'string') return replaceEmojis(obj);
    if (Array.isArray(obj)) return obj.map(deep);
    if (obj && typeof obj === 'object') {
        const proto = Object.getPrototypeOf(obj);
        if (proto !== null && proto !== Object.prototype) return obj;
        const out = {};
        for (const key of Object.keys(obj)) out[key] = deep(obj[key]);
        return out;
    }
    return obj;
};

let patched = false;
const patch = () => {
    if (patched) return;
    patched = true;
    const embedJSON = EmbedBuilder.prototype.toJSON;
    EmbedBuilder.prototype.toJSON = function () { return deep(embedJSON.call(this)); };
    const modalJSON = ModalBuilder.prototype.toJSON;
    ModalBuilder.prototype.toJSON = function () { return deep(modalJSON.call(this)); };
    const resolveBody = MessagePayload.prototype.resolveBody;
    MessagePayload.prototype.resolveBody = function () {
        resolveBody.call(this);
        if (this.body) this.body = deep(this.body);
        return this;
    };
};

patch();
module.exports = { replaceEmojis, deep, patch, map };
