// طبقة تخزين محلية (ملف JSON) للميزات الإضافية
const fs = require('fs');
const path = require('path');

const dir = path.join(__dirname, '..', '..', '..', 'data');
const file = path.join(dir, 'ext.json');

const empty = () => ({
    kv: {}, guildSettings: {}, giveaways: {}, reactroles: [], jailSettings: {}, jailed: {},
    modActions: [], suggestionSettings: {}, suggestions: {}, afk: {}, starboardSettings: {},
    starboardPosts: {}, sticky: {}, invites: {}, inviteRanks: [], inviteLogs: {}, snipe: {}, inviteJoin: {}
});

const loadStore = () => {
    fs.mkdirSync(dir, { recursive: true });
    for (const candidate of [file, file + '.bak']) {
        if (!fs.existsSync(candidate)) continue;
        try {
            return Object.assign(empty(), JSON.parse(fs.readFileSync(candidate, 'utf8')));
        } catch {
            try { fs.renameSync(candidate, path.join(dir, `ext.corrupt-${Date.now()}.json`)); } catch {}
        }
    }
    return empty();
};

let store = loadStore();

let timer = null;
let lastBak = 0;
const flush = () => {
    if (timer) clearTimeout(timer);
    timer = null;
    try {
        fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(file + '.tmp', JSON.stringify(store));
        if (fs.existsSync(file) && Date.now() - lastBak > 10 * 60000) {
            fs.copyFileSync(file, file + '.bak');
            lastBak = Date.now();
        }
        fs.renameSync(file + '.tmp', file);
    } catch (e) { console.error('فشل حفظ بيانات الإضافات', e.message); }
};
const save = () => { if (!timer) timer = setTimeout(flush, 2000); };
process.on('exit', flush);
process.on('SIGINT', () => { flush(); process.exit(0); });
process.on('SIGTERM', () => { flush(); process.exit(0); });

const k = (a, b) => `${a}_${b}`;

module.exports = {
    flush,
    file,
    raw: () => store,
    snapshot: () => structuredClone(store),
    replaceAll(data) {
        if (!data || typeof data !== 'object' || Array.isArray(data)) throw new Error('بيانات الإضافات غير صالحة');
        store = Object.assign(empty(), data);
        flush();
    },

    // KV
    getKV: async key => store.kv[key] ?? null,
    setKV: async (key, value) => { store.kv[key] = value; save(); },
    deleteKV: async key => { delete store.kv[key]; save(); },

    // إعدادات عامة للسيرفر
    getGuildSettings: guildId => store.guildSettings[guildId] || {},
    setGuildSetting(guildId, key, value) {
        (store.guildSettings[guildId] ||= {})[key] = value; save();
    },

    // قيف أواي
    createGiveaway(messageId, channelId, guildId, prize, winners, host, endTime, emoji) {
        store.giveaways[messageId] = { messageId, channelId, guildId, prize, winners, host, endTime, emoji, ended: 0, paused: 0 };
        save();
        return { changes: 1 };
    },
    getGiveaway: id => store.giveaways[id],
    getActiveGiveaways: guildId => Object.values(store.giveaways).filter(g => g.guildId === guildId && !g.ended),
    getAllActiveGiveaways: () => Object.values(store.giveaways).filter(g => !g.ended && !g.paused),
    endGiveaway(id) { if (store.giveaways[id]) { store.giveaways[id].ended = 1; save(); } },

    // رتب التفاعل
    addReactRole(messageId, guildId, emoji, roleId) {
        store.reactroles = store.reactroles.filter(r => !(r.messageId === messageId && r.emoji === emoji));
        store.reactroles.push({ messageId, guildId, emoji, roleId });
        save();
    },
    listReactRoles: guildId => store.reactroles.filter(r => r.guildId === guildId),
    removeReactRole(messageId, emoji) {
        store.reactroles = store.reactroles.filter(r => !(r.messageId === messageId && r.emoji === emoji));
        save();
    },
    listSticky: guildId => Object.values(store.sticky).filter(s => s.guildId === guildId),
    listModActions: (guildId, limit = 10) => store.modActions.filter(a => a.guildId === guildId).slice(-limit).reverse(),
    clearModActions(guildId) {
        const before = store.modActions.length;
        store.modActions = store.modActions.filter(a => a.guildId !== guildId);
        save();
        return before - store.modActions.length;
    },
    getReactRole: (messageId, emoji) => store.reactroles.find(r => r.messageId === messageId && r.emoji === emoji),

    // السجن
    getJailSettings: guildId => store.jailSettings[guildId] || { guildId, jailRoleId: null, jailChannelId: null, staffVoiceId: null },
    setJailSettings(guildId, roleId, channelId, staffVoiceId, staffRoleId) {
        store.jailSettings[guildId] = { guildId, jailRoleId: roleId, jailChannelId: channelId, staffVoiceId, staffRoleId };
        save();
    },
    getJailedUser: (userId, guildId) => store.jailed[k(userId, guildId)],
    addJailedUser(userId, guildId, oldRoles) {
        store.jailed[k(userId, guildId)] = { userId, guildId, oldRoles, jailedAt: Math.floor(Date.now() / 1000) };
        save();
    },
    removeJailedUser(userId, guildId) { delete store.jailed[k(userId, guildId)]; save(); },
    addModAction(guildId, targetId, targetTag, moderatorId, moderatorTag, action, reason, duration) {
        store.modActions.push({ guildId, targetId, targetTag, moderatorId, moderatorTag, action, reason, duration: duration || null, timestamp: Date.now() });
        if (store.modActions.length > 5000) store.modActions.splice(0, store.modActions.length - 5000);
        save();
    },
    getModHistory: (guildId, targetId, limit = 50) => store.modActions
        .filter(a => a.guildId === guildId && a.targetId === targetId)
        .sort((a, b) => b.timestamp - a.timestamp).slice(0, limit),

    // الاقتراحات
    getSuggestionSettings: guildId => store.suggestionSettings[guildId] || null,
    setSuggestionSettings(guildId, data) {
        store.suggestionSettings[guildId] = { guildId, ...data };
        try { require('../../utils/db').guild(guildId).suggestions = data.channelId; require('../../utils/db').save(); } catch {}
        save();
    },
    addSuggestion(guildId, messageId, userId, userTag, content) {
        store.suggestions[messageId] = { guildId, messageId, userId, userTag, content, status: 'pending', reviewedBy: null, reviewNote: null, timestamp: Date.now() };
        save();
    },
    getSuggestion: messageId => store.suggestions[messageId] || null,
    updateSuggestionStatus(messageId, status, reviewedBy, reviewNote) {
        const d = store.suggestions[messageId];
        if (d) { Object.assign(d, { status, reviewedBy, reviewNote: reviewNote || null }); save(); }
    },
    updateSuggestionVotes(messageId, upvoters, downvoters) {
        const d = store.suggestions[messageId];
        if (d) { d.upvoters = upvoters; d.downvoters = downvoters; save(); }
    },

    // AFK
    setAFK(guildId, userId, reason) {
        store.afk[k(userId, guildId)] = { guildId, userId, reason, timestamp: Date.now() };
        save();
    },
    getAFK: (guildId, userId) => store.afk[k(userId, guildId)] || null,
    removeAFK(guildId, userId) { delete store.afk[k(userId, guildId)]; save(); },

    // ستاربورد
    getStarboardSettings: guildId => store.starboardSettings[guildId] || null,
    setStarboardSettings(guildId, data) { store.starboardSettings[guildId] = { guildId, ...data }; save(); },
    getStarboardPost: id => store.starboardPosts[id] || null,
    addStarboardPost(guildId, originalMessageId, starboardMessageId, stars) {
        store.starboardPosts[originalMessageId] = { guildId, originalMessageId, starboardMessageId, stars }; save();
    },
    updateStarboardPost(originalMessageId, stars, starboardMessageId) {
        const d = store.starboardPosts[originalMessageId];
        if (d) { d.stars = stars; if (starboardMessageId) d.starboardMessageId = starboardMessageId; save(); }
    },
    removeStarboardPost(id) { delete store.starboardPosts[id]; save(); },

    // الرسالة المثبتة
    getStickyMessage: channelId => store.sticky[channelId] || null,
    setStickyMessage(guildId, channelId, content) {
        store.sticky[channelId] = { guildId, channelId, content, lastMessageId: null, enabled: true }; save();
    },
    updateStickyMessageId(channelId, messageId) {
        if (store.sticky[channelId]) { store.sticky[channelId].lastMessageId = messageId; save(); }
    },
    removeStickyMessage(channelId) { delete store.sticky[channelId]; save(); },

    // الدعوات
    getInvites(userId, guildId) {
        return store.invites[k(userId, guildId)] ||= { userId, guildId, total: 0, fake: 0, left: 0, bonus: 0 };
    },
    updateInvites(userId, guildId, field, value) {
        if (!['total', 'fake', 'left', 'bonus'].includes(field)) throw new Error(`Invalid invite field: ${field}`);
        const d = this.getInvites(userId, guildId);
        d[field] = (d[field] || 0) + value;
        save();
    },
    setInviter(memberId, guildId, inviterId) { store.inviteJoin[k(memberId, guildId)] = inviterId; save(); },
    takeInviter(memberId, guildId) {
        const key = k(memberId, guildId);
        const id = store.inviteJoin[key];
        if (id) { delete store.inviteJoin[key]; save(); }
        return id || null;
    },
    resetInvites(userId, guildId) {
        const d = store.invites[k(userId, guildId)];
        if (d) Object.assign(d, { total: 0, fake: 0, left: 0, bonus: 0 });
        save();
    },
    resetAllInvites(guildId) {
        for (const d of Object.values(store.invites)) if (d.guildId === guildId) Object.assign(d, { total: 0, fake: 0, left: 0, bonus: 0 });
        save();
    },
    getInviteRanks: guildId => store.inviteRanks.filter(r => r.guildId === guildId).sort((a, b) => a.count - b.count),
    addInviteRank(guildId, count, roleId) {
        store.inviteRanks = store.inviteRanks.filter(r => !(r.guildId === guildId && r.count === count));
        store.inviteRanks.push({ guildId, count, roleId });
        save();
    },
    getInviteLogs: guildId => store.inviteLogs[guildId],
    setInviteLogs(guildId, channelId) { store.inviteLogs[guildId] = { guildId, channelId }; save(); },

    // سنايب
    setSnipe(channelId, content, authorId, authorTag, authorAvatar) {
        store.snipe[channelId] = { channelId, content, authorId, authorTag, authorAvatar, timestamp: Math.floor(Date.now() / 1000) };
        save();
    },
    getSnipe: channelId => store.snipe[channelId],

    // ألعاب
    deleteActiveGame() {}
};
